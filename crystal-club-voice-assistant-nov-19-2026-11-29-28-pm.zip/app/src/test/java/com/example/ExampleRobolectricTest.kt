package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasScrollToKeyAction
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToKey
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CustomVoiceCommandEntity
import com.example.data.model.GameSystemEntity
import com.example.data.model.SnackItemEntity
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CrystalGameClubTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("مدیریت گیم‌نت", appName)
  }

  @Test
  fun `settings screen scrolls cleanly with overlapping system snack and command ids`() {
    val systems = (1..14).map { idx ->
      GameSystemEntity(
        id = idx,
        code = idx.toString(),
        displayName = "سیستم $idx",
        systemType = if (idx <= 6) "PS4" else "PC",
        hourlyRatePerPlayer = 60000L,
        sortOrder = idx
      )
    }
    val snacks = (1L..10L).map { idx ->
      SnackItemEntity(
        id = idx,
        name = "خوراکی $idx",
        priceTomans = 20000L,
        category = "نوشیدنی"
      )
    }
    val customCommands = (1L..5L).map { idx ->
      CustomVoiceCommandEntity(
        id = idx,
        commandPhrase = "دستور $idx",
        targetSystemId = idx.toInt(),
        targetSystemName = "سیستم $idx",
        playerCount = 2,
        durationMinutes = 60
      )
    }

    composeTestRule.setContent {
      CrystalGameClubTheme {
        SettingsScreen(
          systems = systems,
          snacks = snacks,
          customCommands = customCommands,
          onUpdateSystemRate = {},
          onAddSnack = { _, _, _ -> },
          onUpdateSnack = {},
          onDeleteSnack = {},
          onRequestBatteryOptimization = {},
          onRequestCleanExit = {}
        )
      }
    }

    composeTestRule.onNodeWithText("سیستم 1").assertIsDisplayed()
    val lazyList = composeTestRule.onNode(hasScrollToKeyAction())
    lazyList.performScrollToKey("snack_2")
    composeTestRule.onNodeWithText("خوراکی 2").assertIsDisplayed()
    lazyList.performScrollToKey("cmd_2")
    composeTestRule.onNodeWithText("«دستور 2»").assertIsDisplayed()
    lazyList.performScrollToKey("card_exit")
    composeTestRule.onNodeWithTag("app_exit_button").assertIsDisplayed()
  }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MainNavigationRobolectricTest {

  @get:Rule
  val activityRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `bottom navigation includes customers tab settings omits it and calculator opens globally`() {
    activityRule.waitForIdle()
    // Bottom nav has all 5 items: سیستم‌ها, حسابداری, آمار فروش, مشتریان, تنظیمات
    activityRule.onNodeWithText("سیستم‌ها").assertIsDisplayed()
    activityRule.onNodeWithText("حسابداری").assertIsDisplayed()
    activityRule.onNodeWithText("آمار فروش").assertIsDisplayed()
    activityRule.onNodeWithText("مشتریان").assertIsDisplayed()
    activityRule.onNodeWithText("تنظیمات").assertIsDisplayed()

    // Navigate directly to Customers via bottom bar
    activityRule.onNodeWithText("مشتریان").performClick()
    activityRule.waitForIdle()
    activityRule.onNodeWithTag("add_customer_manual_btn").assertIsDisplayed()

    // Navigate to Settings -> Customers shortcut is removed from SettingsScreen
    activityRule.onNodeWithText("تنظیمات").performClick()
    activityRule.waitForIdle()
    assertEquals(0, activityRule.onAllNodesWithText("مدیریت باشگاه مشتریان").fetchSemanticsNodes().size)

    // Global calculator button opens MiniCalculatorOverlay on top and closes cleanly
    activityRule.onNodeWithTag("header_calculator_btn").performClick()
    activityRule.waitForIdle()
    activityRule.onNodeWithTag("mini_calculator_dialog").assertIsDisplayed()
    activityRule.onNodeWithTag("calc_display_text").assertIsDisplayed()
    activityRule.onNodeWithTag("close_calculator_btn").performClick()
    activityRule.waitForIdle()
  }
}

