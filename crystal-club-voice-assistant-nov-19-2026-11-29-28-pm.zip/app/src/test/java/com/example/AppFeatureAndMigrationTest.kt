package com.example

import android.content.Context
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasScrollToKeyAction
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToKey
import androidx.compose.ui.test.performTextReplacement
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.GameNetRepository
import com.example.data.repository.SessionCostCalculator
import com.example.ui.components.FinishedReceiptDialog
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.DebtsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.theme.CrystalGameClubTheme
import com.example.util.PersianDateUtils
import com.example.voice.PersianVoiceParser
import com.example.voice.VoiceCommandResult
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w420dp-h1000dp")
class AppFeatureAndMigrationTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `room migration 3 to 4 preserves all user records and adds new tables cleanly`() = runBlocking<Unit> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbName = "migration_test_v3_v4.db"
        context.deleteDatabase(dbName)

        // Create genuine SQLite DB with exact Room v3 schema and populate sample rows
        val config = SupportSQLiteOpenHelper.Configuration.builder(context)
            .name(dbName)
            .callback(object : SupportSQLiteOpenHelper.Callback(3) {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `game_systems` (
                            `id` INTEGER NOT NULL,
                            `code` TEXT NOT NULL,
                            `displayName` TEXT NOT NULL,
                            `systemType` TEXT NOT NULL,
                            `hourlyRatePerPlayer` INTEGER NOT NULL,
                            `flatRatePerHour` INTEGER NOT NULL,
                            `iconType` TEXT NOT NULL,
                            `sortOrder` INTEGER NOT NULL,
                            PRIMARY KEY(`id`)
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `active_sessions` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `systemId` INTEGER NOT NULL,
                            `systemDisplayName` TEXT NOT NULL,
                            `playerCount` INTEGER NOT NULL,
                            `startTimeMillis` INTEGER NOT NULL,
                            `durationMinutes` INTEGER NOT NULL,
                            `expectedEndTimeMillis` INTEGER NOT NULL,
                            `isCountDown` INTEGER NOT NULL,
                            `hourlyRateApplied` INTEGER NOT NULL,
                            `snacksCost` INTEGER NOT NULL,
                            `snacksDetail` TEXT NOT NULL,
                            `targetAmountTomans` INTEGER NOT NULL,
                            `customerName` TEXT NOT NULL,
                            `isAlarmDismissed` INTEGER NOT NULL,
                            `discountPercent` INTEGER NOT NULL,
                            `isPaused` INTEGER NOT NULL,
                            `pausedAtMillis` INTEGER NOT NULL
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `game_history` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `systemId` INTEGER NOT NULL,
                            `systemDisplayName` TEXT NOT NULL,
                            `playerCount` INTEGER NOT NULL,
                            `startTimeMillis` INTEGER NOT NULL,
                            `endTimeMillis` INTEGER NOT NULL,
                            `playedMinutes` INTEGER NOT NULL,
                            `gameFee` INTEGER NOT NULL,
                            `snacksFee` INTEGER NOT NULL,
                            `totalFee` INTEGER NOT NULL,
                            `snacksDetail` TEXT NOT NULL,
                            `customerName` TEXT NOT NULL,
                            `dateIso` TEXT NOT NULL,
                            `createdAtMillis` INTEGER NOT NULL,
                            `discountPercent` INTEGER NOT NULL,
                            `discountAmount` INTEGER NOT NULL
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `snack_items` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `name` TEXT NOT NULL,
                            `priceTomans` INTEGER NOT NULL,
                            `category` TEXT NOT NULL,
                            `icon` TEXT NOT NULL
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `customer_debts` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `customerName` TEXT NOT NULL,
                            `amountTomans` INTEGER NOT NULL,
                            `note` TEXT NOT NULL,
                            `createdAtMillis` INTEGER NOT NULL,
                            `isSettled` INTEGER NOT NULL,
                            `settledAtMillis` INTEGER NOT NULL,
                            `customerCode` TEXT NOT NULL
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `customers` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `customerCode` TEXT NOT NULL,
                            `name` TEXT NOT NULL,
                            `phone` TEXT NOT NULL,
                            `nationalId` TEXT NOT NULL,
                            `discountPercent` INTEGER NOT NULL,
                            `createdAtMillis` INTEGER NOT NULL
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `club_profile` (
                            `id` INTEGER NOT NULL,
                            `clubName` TEXT NOT NULL,
                            `managerName` TEXT NOT NULL,
                            `phoneNumber` TEXT NOT NULL,
                            `avatarUri` TEXT NOT NULL,
                            PRIMARY KEY(`id`)
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `custom_voice_commands` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `commandPhrase` TEXT NOT NULL,
                            `targetSystemId` INTEGER NOT NULL,
                            `targetSystemName` TEXT NOT NULL,
                            `playerCount` INTEGER NOT NULL,
                            `durationMinutes` INTEGER NOT NULL,
                            `isCountDown` INTEGER NOT NULL,
                            `mode` TEXT NOT NULL,
                            `amountTomans` INTEGER NOT NULL,
                            `createdAtMillis` INTEGER NOT NULL
                        )
                        """.trimIndent()
                    )
                    db.execSQL(
                        """
                        CREATE TABLE IF NOT EXISTS `bank_cards` (
                            `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            `bankName` TEXT NOT NULL,
                            `cardNumber` TEXT NOT NULL,
                            `cardHolder` TEXT NOT NULL,
                            `createdAtMillis` INTEGER NOT NULL
                        )
                        """.trimIndent()
                    )

                    // Insert sample v3 records that must survive migration
                    db.execSQL("INSERT INTO game_systems VALUES (1, '1', 'پی اس فور ۱', 'PS4', 60000, 120000, 'gamepad', 1)")
                    db.execSQL("INSERT INTO customers VALUES (1, '101', 'علی رضایی', '09123456789', '0011223344', 15, 1700000000000)")
                    db.execSQL("INSERT INTO customer_debts VALUES (1, 'علی رضایی', 180000, 'بدهی قبلی', 1700000000000, 0, 0, '101')")
                    db.execSQL("INSERT INTO game_history VALUES (1, 1, 'پی اس فور ۱', 2, 1700000000000, 1700003600000, 60, 120000, 0, 120000, '', 'علی رضایی', '1404/01/01', 1700003600000, 0, 0)")
                    db.execSQL("INSERT INTO custom_voice_commands VALUES (1, 'فیفا یک ساعت', 1, 'پی اس فور ۱', 2, 60, 1, 'TIME', 0, 1700000000000)")
                }

                override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
            })
            .build()

        FrameworkSQLiteOpenHelperFactory().create(config).writableDatabase.close()

        val migratedDb = Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .addMigrations(
                AppDatabase.MIGRATION_2_3,
                AppDatabase.MIGRATION_3_4,
                AppDatabase.MIGRATION_4_5,
                AppDatabase.MIGRATION_5_6
            )
            .allowMainThreadQueries()
            .build()

        val dao = migratedDb.gameNetDao()
        val customers = dao.getAllCustomersList()
        val debts = dao.getAllDebtsList()
        val history = dao.getAllHistoryList()
        val commands = dao.getAllCustomVoiceCommandsList()

        assertEquals(1, customers.size)
        assertEquals("علی رضایی", customers.first().name)
        assertEquals(15, customers.first().discountPercent)

        assertEquals(1, debts.size)
        assertEquals(180000L, debts.first().amountTomans)
        assertFalse(debts.first().transferredToStats)
        assertEquals("[]", debts.first().debtItemsJson)

        assertEquals(1, history.size)
        assertEquals("GAME", history.first().entryType)
        assertEquals(0L, history.first().cardPaidTomans)

        assertEquals(1, commands.size)
        assertEquals("فیفا یک ساعت", commands.first().commandPhrase)

        // New v4/v6 tables work immediately after migration
        dao.insertCashEntry(CashEntryEntity(amountTomans = 50000L, note = "تست", createdAtMillis = System.currentTimeMillis()))
        assertEquals(1, dao.getAllCashEntriesList().size)
        dao.insertCredit(CustomerCreditEntity(customerName = "علی رضایی", customerCode = "101", amountTomans = 25000L, note = "طلب"))
        assertEquals(1, dao.getAllCreditsList().size)

        migratedDb.close()
        context.deleteDatabase(dbName)
    }

    @Test
    fun `segmented billing tracks player changes and system transfers plus cancel restore`() = runBlocking<Unit> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.gameNetDao()
        val repo = GameNetRepository(dao)

        val ps4 = GameSystemEntity(1, "1", "پی اس فور ۱", "PS4", 60000L, sortOrder = 1)
        val ps5 = GameSystemEntity(7, "7", "پی اس فایو ۱", "PS5", 80000L, sortOrder = 7)
        dao.insertSystems(listOf(ps4, ps5))

        val t0 = System.currentTimeMillis() - 60 * 60_000L // 60 min ago
        dao.insertSession(
            ActiveSessionEntity(
                systemId = ps4.id,
                systemDisplayName = ps4.displayName,
                playerCount = 2,
                startTimeMillis = t0,
                durationMinutes = 0,
                expectedEndTimeMillis = 0L,
                isCountDown = false,
                hourlyRateApplied = ps4.hourlyRatePerPlayer,
                segmentsJson = "[]",
                currentSegmentStartMillis = t0
            )
        )

        // After 30 mins: change player count from 2 -> 4
        val t1 = t0 + 30 * 60_000L
        assertTrue(repo.updateSessionPlayers(ps4.id, 4, changeTimeMillis = t1))

        // After another 15 mins: transfer to PS5
        val t2 = t1 + 15 * 60_000L
        assertTrue(repo.transferSessionToSystem(ps4.id, ps5, transferTimeMillis = t2))
        assertFalse(repo.isSystemBusy(ps4.id))
        assertTrue(repo.isSystemBusy(ps5.id))

        // Finish after another 15 mins on PS5
        val t3 = t2 + 15 * 60_000L
        val prepared = repo.prepareFinishSession(ps5.id, endTimeMillis = t3)
        assertNotNull(prepared)
        val (receipt, snapshot) = prepared!!

        val segments = SessionSegmentCodec.decode(receipt.segmentsDetailJson)
        assertEquals(3, segments.size)
        // Seg 1: PS4 2 players 30m @ 60k = 60,000
        assertEquals(60000L, segments[0].costTomans)
        // Seg 2: PS4 4 players 15m @ 60k = 60,000
        assertEquals(60000L, segments[1].costTomans)
        // Seg 3: PS5 4 players 15m @ 80k = 80,000
        assertEquals(80000L, segments[2].costTomans)
        assertEquals(200000L, receipt.totalFee)

        // Cancel checkout and resume active session
        assertFalse(repo.isSystemBusy(ps5.id))
        repo.restoreCancelledSession(snapshot)
        assertTrue(repo.isSystemBusy(ps5.id))

        db.close()
    }

    @Test
    fun `debt isolation adds invoice to stats only when settled and guards double credit`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.gameNetDao()
        val repo = GameNetRepository(dao)

        repo.addCustomer("202", "رضا محمدی", "09120000000", "111", 0)

        val now = System.currentTimeMillis()
        val receipt = GameHistoryEntity(
            systemId = 4,
            systemDisplayName = "پی اس فور ۴",
            playerCount = 2,
            startTimeMillis = now - 3600_000L,
            endTimeMillis = now,
            playedMinutes = 60,
            gameFee = 120000L,
            snacksFee = 20000L,
            totalFee = 140000L,
            snacksDetail = "نوشابه ×1",
            customerName = "202",
            dateIso = PersianDateUtils.formatJalaliDateTime(now),
            createdAtMillis = now
        )

        // Send to Debts with 40,000 cash paid and 100,000 deferred to debt
        repo.registerReceiptAsDebt(
            editedHistory = receipt,
            customerInput = "202",
            cashPaidTomans = 40000L,
            debtSettlementAmountTomans = 0L
        )

        // Verify cash entry logged and unpaid 100k is NOT in game_history as unsettled debt
        val cashAfterDefer = dao.getAllCashEntriesList()
        assertEquals(1, cashAfterDefer.size)
        assertEquals(40000L, cashAfterDefer.first().amountTomans)

        val debtsAfterDefer = dao.getAllDebtsList()
        assertEquals(1, debtsAfterDefer.size)
        assertEquals(100000L, debtsAfterDefer.first().amountTomans)
        assertFalse(debtsAfterDefer.first().isSettled)

        // Only cash portion (40,000) is in history so far; 100,000 debt is NOT in stats yet
        assertEquals(40000L, dao.getAllHistoryList().sumOf { it.totalFee })

        // Now settle the 100,000 debt via «تسویه شد» -> transfers to Stats and cleanly deletes from customer_debts
        val firstDebt = debtsAfterDefer.first()
        repo.settleDebtAndTransferToStats(firstDebt)
        assertTrue(dao.getAllDebtsList().isEmpty())

        // Call a second time with stale reference to verify double-credit guard
        repo.settleDebtAndTransferToStats(firstDebt)

        val finalHistory = dao.getAllHistoryList()
        assertEquals(140000L, finalHistory.sumOf { it.totalFee })
        assertTrue(finalHistory.any { it.entryType == "DEBT_SETTLEMENT" && it.totalFee == 100000L })

        // Test Backup v3 export/import preserves everything including cashEntries & customer
        val json = repo.exportBackupJson()
        dao.clearAllHistory()
        assertEquals(0, dao.getAllHistoryList().size)
        assertTrue(repo.importBackupJson(json))
        assertEquals(2, dao.getAllHistoryList().size)
        assertEquals(1, dao.getAllCashEntriesList().size)
        assertEquals(1, dao.getAllCustomersList().size)

        db.close()
    }

    @Test
    fun `voice parser matches custom fuzzy and standard persian commands cleanly`() {
        val systems = listOf(
            GameSystemEntity(1, "1", "پی اس فور ۱", "PS4", 60000L, sortOrder = 1),
            GameSystemEntity(4, "4", "پی اس فور ۴", "PS4", 60000L, sortOrder = 4),
            GameSystemEntity(9, "9", "کامپیوتر ۱", "PC", 60000L, sortOrder = 9)
        )
        val customCmds = listOf(
            CustomVoiceCommandEntity(
                id = 1,
                commandPhrase = "بسته طلایی فیفا",
                targetSystemId = 4,
                targetSystemName = "پی اس فور ۴",
                playerCount = 2,
                durationMinutes = 90,
                mode = "TIME"
            )
        )

        val customRes = PersianVoiceParser.parse("بسته طلایی فیفا", customCmds, systems)
        assertTrue(customRes is VoiceCommandResult.CustomAction)
        customRes as VoiceCommandResult.CustomAction
        assertEquals(4, customRes.systemId)
        assertEquals(90, customRes.durationMinutes)

        val stdRes = PersianVoiceParser.parse("پی اس فور ۴ دو نفره یک ساعت", emptyList(), systems)
        assertTrue(stdRes is VoiceCommandResult.StartCountdownTime)
        stdRes as VoiceCommandResult.StartCountdownTime
        assertEquals(4, stdRes.systemId)
        assertEquals(2, stdRes.playerCount)
        assertEquals(60, stdRes.durationMinutes)

        val openRes = PersianVoiceParser.parse("کامپیوتر ۱ آزاد", emptyList(), systems)
        assertTrue(openRes is VoiceCommandResult.StartOpenTime)
        assertEquals(9, (openRes as VoiceCommandResult.StartOpenTime).systemId)
    }

    @Test
    fun `customers screen asks delete confirmation allows discount reset and opens debt popup`() {
        val sampleCustomer = CustomerEntity(
            id = 1L,
            customerCode = "101",
            name = "مهدی کریمی",
            phone = "09121112233",
            nationalId = "1234567890",
            discountPercent = 20
        )
        val sampleDebt = CustomerDebtEntity(
            id = 10L,
            customerName = "مهدی کریمی",
            customerCode = "101",
            amountTomans = 150000L,
            note = "بدهی تست",
            createdAtMillis = System.currentTimeMillis(),
            isSettled = false
        )

        var updatedCustomer: CustomerEntity? = null
        var deletedCustomer: CustomerEntity? = null

        composeRule.setContent {
            CrystalGameClubTheme {
                CustomersScreen(
                    customers = listOf(sampleCustomer),
                    debts = listOf(sampleDebt),
                    bankCards = emptyList(),
                    clubName = "گیم‌نت تست",
                    onAddCustomer = { _, _, _, _, _ -> },
                    onUpdateCustomer = { updatedCustomer = it },
                    onDeleteCustomer = { deletedCustomer = it },
                    onAddBankCard = { _, _, _ -> },
                    onDeleteBankCard = {}
                )
            }
        }

        // Click cumulative debt badge -> opens breakdown dialog
        composeRule.onNodeWithTag("customer_debt_badge_1").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("جزئیات زمانی بدهی‌های مهدی کریمی").assertIsDisplayed()
        composeRule.onNodeWithText("بستن").performClick()
        composeRule.waitForIdle()

        // Delete click must NOT delete immediately; requires confirmation dialog
        composeRule.onNodeWithTag("delete_customer_btn_1").performClick()
        composeRule.waitForIdle()
        assertNull(deletedCustomer)
        composeRule.onNodeWithTag("confirm_action_button").performClick()
        composeRule.waitForIdle()
        assertEquals(1L, deletedCustomer?.id)

        // Edit click allows clearing discount to 0% and saving
        composeRule.onNodeWithTag("edit_customer_btn_1").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("clear_customer_discount_btn").performScrollTo().performClick()
        composeRule.onNodeWithTag("save_customer_edit_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals(0, updatedCustomer?.discountPercent)
    }

    @Test
    fun `debts screen renders settle button and stats full report dialog searches date`() {
        val now = System.currentTimeMillis()
        val debt = CustomerDebtEntity(
            id = 5L,
            customerName = "حسین نوری",
            customerCode = "303",
            amountTomans = 90000L,
            note = "فاکتور تست",
            createdAtMillis = now,
            isSettled = false
        )
        var settledDebt: CustomerDebtEntity? = null

        composeRule.setContent {
            CrystalGameClubTheme {
                DebtsScreen(
                    debts = listOf(debt),
                    onAddDebt = { _, _, _ -> },
                    onAddCustomer = { _, _, _, _ -> },
                    onSettleDebt = { settledDebt = it },
                    onDeleteDebt = {}
                )
            }
        }

        // Settle button shows «تسویه شد» and asks confirmation before settling
        composeRule.onNodeWithTag("settle_debt_button_5").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        assertNull(settledDebt)
        composeRule.onNodeWithTag("confirm_action_button").performClick()
        composeRule.waitForIdle()
        assertEquals(5L, settledDebt?.id)
    }

    @Test
    fun `finished receipt dialog supports cancel resume and cash deduction`() {
        val now = System.currentTimeMillis()
        val history = GameHistoryEntity(
            id = 1L,
            systemId = 2,
            systemDisplayName = "پی اس فور ۲",
            playerCount = 2,
            startTimeMillis = now - 3600_000L,
            endTimeMillis = now,
            playedMinutes = 60,
            gameFee = 120000L,
            snacksFee = 0L,
            totalFee = 120000L,
            snacksDetail = "",
            customerName = "101",
            dateIso = PersianDateUtils.formatJalaliDateTime(now),
            createdAtMillis = now
        )
        val customer = CustomerEntity(id = 1L, customerCode = "101", name = "مهدی")
        val oldDebt = CustomerDebtEntity(
            id = 2L,
            customerName = "مهدی",
            customerCode = "101",
            amountTomans = 50000L,
            createdAtMillis = now - 86400_000L,
            isSettled = false
        )

        var cancelled = false
        var savedCash = -1L

        composeRule.setContent {
            CrystalGameClubTheme {
                FinishedReceiptDialog(
                    history = history,
                    customers = listOf(customer),
                    debts = listOf(oldDebt),
                    onConfirmSave = { _, cashPaid, _, _, _, _ -> savedCash = cashPaid },
                    onCancelAndResume = { cancelled = true },
                    onDiscard = {},
                    onRegisterAsDebt = { _, _, _, _, _, _ -> }
                )
            }
        }

        // Automatic past debt detection appears for customer 101
        composeRule.onNodeWithText("بدهی قبلی تسویه‌نشده: 50,000 تومان (1 مورد)")
            .performScrollTo()
            .assertIsDisplayed()

        // Enter POS card 80000 + cash 40000 -> total 120000 -> button updates to «بستن فاکتور»
        composeRule.onNodeWithTag("pos_paid_input").performScrollTo().performTextReplacement("80000")
        composeRule.onNodeWithTag("cash_paid_input").performScrollTo().performTextReplacement("40000")
        composeRule.waitForIdle()
        composeRule.onNodeWithText("بستن فاکتور").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("dismiss_receipt_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals(40000L, savedCash)

        // Click "انصراف و ادامه بازی"
        composeRule.onNodeWithTag("cancel_checkout_resume_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertTrue(cancelled)
    }

    @Test
    fun `stats screen displays daily cash card services and cash entries with edit and delete`() {
        val now = System.currentTimeMillis()
        val historyItem = GameHistoryEntity(
            id = 1L,
            systemId = 1,
            systemDisplayName = "پی اس فور ۱",
            playerCount = 2,
            startTimeMillis = now - 3600_000L,
            endTimeMillis = now,
            playedMinutes = 60,
            gameFee = 120000L,
            snacksFee = 0L,
            totalFee = 120000L,
            snacksDetail = "",
            customerName = "کاربر تست",
            dateIso = PersianDateUtils.formatJalaliDateTime(now),
            createdAtMillis = now
        )
        val serviceItem = GameHistoryEntity(
            id = 2L,
            systemId = 0,
            systemDisplayName = "نصب بازی PS5",
            playerCount = 1,
            startTimeMillis = now - 1000L,
            endTimeMillis = now - 1000L,
            playedMinutes = 0,
            gameFee = 90000L,
            snacksFee = 0L,
            totalFee = 90000L,
            snacksDetail = "سرویس کامل",
            customerName = "خدمات",
            dateIso = PersianDateUtils.formatJalaliDateTime(now),
            createdAtMillis = now - 1000L,
            entryType = "SERVICE",
            cardPaidTomans = 90000L,
            sessionNote = "سرویس کامل"
        )
        val cashEntry = CashEntryEntity(
            id = 7L,
            amountTomans = 55000L,
            note = "پرداخت نقدی دستی",
            customerName = "علی",
            source = "MANUAL",
            createdAtMillis = now - 2000L
        )

        var editedCashAmount = -1L
        var deletedCashId = -1L
        var editedServiceAmount = -1L

        composeRule.setContent {
            CrystalGameClubTheme {
                StatsScreen(
                    historyList = listOf(historyItem, serviceItem),
                    cashEntries = listOf(cashEntry),
                    onUpdateHistory = { if (it.entryType == "SERVICE") editedServiceAmount = it.totalFee },
                    onUpdateCashEntry = { editedCashAmount = it.amountTomans },
                    onDeleteCashEntry = { deletedCashId = it.id }
                )
            }
        }

        composeRule.onNodeWithText("مبلغ نقدی روزانه", substring = true).assertIsDisplayed()
        composeRule.onNodeWithText("گزارش کلی").assertIsDisplayed()
        composeRule.onNodeWithTag("open_add_service_btn").assertIsDisplayed()

        // Verify both Service and Cash appear in the recorded list
        composeRule.onNodeWithText("نصب بازی PS5", substring = true).assertIsDisplayed()
        composeRule.onNodeWithTag("cash_item_card_7").assertIsDisplayed()

        // Edit Service item
        composeRule.onNodeWithTag("edit_history_btn_2").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("edit_service_amount_input").performTextReplacement("115000")
        composeRule.onNodeWithTag("save_edit_history_btn").performClick()
        composeRule.waitForIdle()
        assertEquals(115000L, editedServiceAmount)

        // Edit Cash item
        composeRule.onNodeWithTag("edit_cash_btn_7").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("edit_cash_amount_input").performTextReplacement("75000")
        composeRule.onNodeWithTag("save_edit_cash_btn").performClick()
        composeRule.waitForIdle()
        assertEquals(75000L, editedCashAmount)

        // Delete Cash item
        composeRule.onNodeWithTag("delete_cash_btn_7").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("بله، حذف شود").performClick()
        composeRule.waitForIdle()
        assertEquals(7L, deletedCashId)

        // Verify charts and full report dialogs
        composeRule.onNodeWithTag("hourly_chart_button").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("ظهر").assertIsDisplayed()
        composeRule.onNodeWithText("بستن").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("open_full_report_btn").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("full_report_date_input").assertIsDisplayed()
        composeRule.onNodeWithText("نمودار فروش روزانه کل دوره", substring = true).assertIsDisplayed()
    }

    @Test
    fun `multi-system merge transfer anonymous naming and departing mini checkout deduct correctly`() = runBlocking<Unit> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.gameNetDao()
        val repo = GameNetRepository(dao)

        val sys1 = GameSystemEntity(1, "1", "پی اس فور ۱", "PS4", 60000L, sortOrder = 1)
        val sys2 = GameSystemEntity(2, "2", "پی اس فور ۲", "PS4", 60000L, sortOrder = 2)
        val sys3 = GameSystemEntity(7, "7", "پی اس فایو ۱", "PS5", 80000L, sortOrder = 7)
        dao.insertSystems(listOf(sys1, sys2, sys3))

        val t0 = System.currentTimeMillis() - 60 * 60_000L
        // Start sys1 (1 player, 60k/hr) & sys2 (1 player, 60k/hr) & sys3 (busy target, 1 player, 80k/hr)
        repo.startOpenEndedSession(sys1, 1, startTimeMillis = t0, customerName = "رضا")
        repo.startOpenEndedSession(sys2, 1, startTimeMillis = t0, customerName = "")
        repo.startOpenEndedSession(sys3, 1, startTimeMillis = t0, customerName = "امیر")

        val tTransfer = t0 + 30 * 60_000L
        // Transfer sys1 ("رضا") and sys2 (anonymous -> "ناشناس") into ALREADY BUSY sys3
        val r1 = repo.transferOrMergePlayers(sys1.id, null, "رضا", sys3, transferTimeMillis = tTransfer)
        assertTrue(r1.success)
        assertFalse(repo.isSystemBusy(sys1.id))

        val r2 = repo.transferOrMergePlayers(sys2.id, null, "", sys3, transferTimeMillis = tTransfer)
        assertTrue(r2.success)
        assertFalse(repo.isSystemBusy(sys2.id))

        val mergedSession = dao.getSessionBySystemId(sys3.id)!!
        assertEquals(3, mergedSession.playerCount)
        val mergedSeats = PlayerSeatCodec.decode(mergedSession.playerSeatsJson)
        assertEquals(3, mergedSeats.size)
        assertTrue(mergedSeats.any { it.displayName == "رضا" && it.priorSegments.isNotEmpty() })
        assertTrue(mergedSeats.any { it.displayName.startsWith("ناشناس") && it.priorSegments.isNotEmpty() })

        // Departing mini checkout for رضا 30 mins later -> settles his slice cleanly and removes him
        val tDepart = tTransfer + 30 * 60_000L
        val rezaSeat = mergedSeats.first { it.displayName == "رضا" }
        val miniData = repo.prepareMiniCheckoutForSeat(sys3.id, rezaSeat.seatId, nowMillis = tDepart)!!
        assertTrue(miniData.previewHistory.totalFee > 0L)
        assertTrue(
            repo.finalizeDepartingPlayerCheckout(
                checkout = miniData,
                editedHistory = miniData.previewHistory,
                settleAsDebt = false,
                customerInput = "رضا",
                cashPaidTomans = 0L,
                cardPaidTomans = miniData.previewHistory.totalFee
            )
        )
        // POS card payment must NOT create cash entry
        assertEquals(0, dao.getAllCashEntriesList().size)
        // Remaining session continues with 2 players
        val afterDepart = dao.getSessionBySystemId(sys3.id)!!
        assertEquals(2, afterDepart.playerCount)

        db.close()
    }

    @Test
    fun `voice parser and repository handle mode conversions accurately`() = runBlocking<Unit> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.gameNetDao()
        val repo = GameNetRepository(dao)

        val sys4 = GameSystemEntity(4, "4", "پی اس فور ۴", "PS4", 60000L, sortOrder = 4)
        dao.insertSystems(listOf(sys4))

        val pOpenToCd = PersianVoiceParser.parse("کد ۴ آزاد به معکوس ۶۰ دقیقه", emptyList(), listOf(sys4))
        assertTrue(pOpenToCd is VoiceCommandResult.ConvertOpenToCountdown)
        assertEquals(4, (pOpenToCd as VoiceCommandResult.ConvertOpenToCountdown).systemId)
        assertEquals(60, pOpenToCd.durationMinutes)

        val pCdToOpen = PersianVoiceParser.parse("کد ۴ معکوس به آزاد", emptyList(), listOf(sys4))
        assertTrue(pCdToOpen is VoiceCommandResult.ConvertCountdownToOpen)
        assertEquals(4, (pCdToOpen as VoiceCommandResult.ConvertCountdownToOpen).systemId)

        val pAmtToTime = PersianVoiceParser.parse("کد ۴ ؛ ۱۲۰ هزار تومن به تایم", emptyList(), listOf(sys4))
        assertTrue(pAmtToTime is VoiceCommandResult.ConvertAmountToTime)
        assertEquals(120000L, (pAmtToTime as VoiceCommandResult.ConvertAmountToTime).amountTomans)

        val now = System.currentTimeMillis()
        repo.startOpenEndedSession(sys4, 1, startTimeMillis = now - 20 * 60_000L)
        val (ok1, _) = repo.convertOpenToCountdown(4, 60, effectiveNowMillis = now)
        assertTrue(ok1)
        val afterConv = dao.getSessionBySystemId(4)!!
        assertTrue(afterConv.isCountDown)
        // Remaining should be ~40 minutes
        val remMin = (afterConv.expectedEndTimeMillis - now) / 60_000L
        assertTrue(remMin in 39..41)

        assertTrue(repo.convertCountdownToOpen(4))
        assertFalse(dao.getSessionBySystemId(4)!!.isCountDown)

        val (ok2, _) = repo.convertAmountToTime(4, 60000L, effectiveNowMillis = now)
        assertTrue(ok2)
        assertTrue(dao.getSessionBySystemId(4)!!.isCountDown)

        db.close()
    }

    @Test
    fun `debts screen supports edit button and settings opens help guide dialog`() {
        val now = System.currentTimeMillis()
        val lineItems = listOf(
            DebtLineItem(id = "d1", title = "پی اس فور ۱", amountTomans = 60000L, createdAtMillis = now),
            DebtLineItem(id = "d2", title = "نوشابه", amountTomans = 30000L, createdAtMillis = now)
        )
        val debt = CustomerDebtEntity(
            id = 9L,
            customerName = "جواد اصغری",
            customerCode = "404",
            amountTomans = 90000L,
            note = "تجمیعی",
            createdAtMillis = now,
            isSettled = false,
            debtItemsJson = DebtItemCodec.encode(lineItems)
        )

        var updatedTotal = -1L
        composeRule.setContent {
            CrystalGameClubTheme {
                DebtsScreen(
                    debts = listOf(debt),
                    onAddDebt = { _, _, _ -> },
                    onAddCustomer = { _, _, _, _ -> },
                    onSettleDebt = {},
                    onDeleteDebt = {},
                    onUpdateDebtLineItems = { _, items, _ -> updatedTotal = items.sumOf { it.amountTomans } }
                )
            }
        }

        composeRule.onNodeWithTag("edit_debt_button_9").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("toggle_add_debt_line_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("new_debt_line_title_input").performScrollTo().performTextReplacement("کیک")
        composeRule.onNodeWithTag("new_debt_line_amount_input").performScrollTo().performTextReplacement("20000")
        composeRule.onNodeWithTag("confirm_add_debt_line_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("save_edit_debt_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals(110000L, updatedTotal)
    }

    @Test
    fun `settings screen opens help guide dialog with voice conversion docs`() {
        composeRule.setContent {
            CrystalGameClubTheme {
                SettingsScreen(
                    systems = emptyList(),
                    snacks = emptyList(),
                    onUpdateSystemRate = {},
                    onAddSnack = { _, _, _ -> },
                    onUpdateSnack = {},
                    onDeleteSnack = {},
                    onRequestBatteryOptimization = {},
                    onRequestCleanExit = {}
                )
            }
        }

        composeRule.onNodeWithTag("open_help_guide_btn").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("راهنمای کامل برنامه و دستورات صوتی").assertIsDisplayed()
        composeRule.onNodeWithText("کد ۴ آزاد به معکوس ۶۰ دقیقه", substring = true).assertIsDisplayed()
    }

    @Test
    fun `proportional rate conversion on idle transfer and unified live vs final billing`() = runBlocking<Unit> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.gameNetDao()
        val repo = GameNetRepository(dao)

        val pc = GameSystemEntity(9, "9", "کامپیوتر ۱", "PC", 60000L, sortOrder = 9)
        val vr = GameSystemEntity(11, "11", "عینک مجازی ۱", "VR", 120000L, sortOrder = 11)
        dao.insertSystems(listOf(pc, vr))

        val t0 = System.currentTimeMillis()
        repo.startSessionWithDuration(pc, playerCount = 1, durationMinutes = 60, customerName = "رضا", startTimeMillis = t0)
        // Transfer immediately from 60k/hr PC (60m remaining) to 120k/hr idle VR -> must convert remaining to 30m
        val res = repo.transferOrMergePlayers(pc.id, null, "رضا", vr, transferTimeMillis = t0)
        assertTrue(res.success)
        val vrSess = dao.getSessionBySystemId(vr.id)!!
        assertTrue(vrSess.isCountDown)
        val remMin = (vrSess.expectedEndTimeMillis - t0) / 60_000L
        assertTrue("Expected ~30m after 60k->120k transfer, got $remMin", remMin in 29..31)

        // Verify live billing matches final receipt totalFee at the exact same timestamp
        val checkTime = t0 + (17 * 60_000L) + 30_000L
        val liveBilling = SessionCostCalculator.calculateLiveBilling(vrSess, checkTime, forFinalReceipt = false)
        val prepared = repo.prepareFinishSession(vr.id, endTimeMillis = checkTime)!!
        assertEquals(liveBilling.totalFeeWithSnacks, prepared.first.totalFee)

        db.close()
    }

    @Test
    fun `customer credit deducts cleanly services record and session snack note seat edits work`() = runBlocking<Unit> {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.gameNetDao()
        val repo = GameNetRepository(dao)

        val sys1 = GameSystemEntity(1, "1", "پی اس فور ۱", "PS4", 60000L, sortOrder = 1)
        dao.insertSystems(listOf(sys1))
        repo.addSnackItem("چای", 20000L, "نوشیدنی")
        repo.addCustomer("505", "مهدی احمدی", "09123334455", "", 0)
        repo.addCustomerCredit("مهدی احمدی", 50000L, "مانده اعتبار قبلی", "505")

        val t0 = System.currentTimeMillis() - 60 * 60_000L
        repo.startOpenEndedSession(sys1, 2, startTimeMillis = t0, customerName = "505")
        val sess0 = dao.getSessionBySystemId(sys1.id)!!

        // Update session note, rename second seat, add and remove snack line
        assertTrue(repo.updateSessionNote(sys1.id, "دسته اضافه نیاز دارد"))
        val secondSeat = SessionCostCalculator.ensureSeats(sess0)[1]
        assertTrue(repo.updateSeatCustomerInfo(sys1.id, secondSeat.seatId, "حسین"))
        assertTrue(repo.addSnackToSession(sys1.id, "چای", 2, secondSeat.seatId))

        val sessWithSnack = dao.getSessionBySystemId(sys1.id)!!
        assertEquals(40000L, sessWithSnack.snacksCost)
        assertEquals("دسته اضافه نیاز دارد", sessWithSnack.sessionNote)
        val lines = SessionSnackCodec.decode(sessWithSnack.snacksItemsJson)
        assertEquals(1, lines.size)
        assertTrue(repo.removeSnackLineFromSession(sys1.id, lines.first().id))
        val sessAfterRemove = dao.getSessionBySystemId(sys1.id)!!
        assertEquals(0L, sessAfterRemove.snacksCost)
        assertTrue(SessionCostCalculator.ensureSeats(sessAfterRemove).any { it.displayName == "حسین" })

        // Finish receipt using 50,000 credit + rest card -> credit is deducted cleanly
        val (receipt, _) = repo.prepareFinishSession(sys1.id, endTimeMillis = t0 + 60 * 60_000L)!!
        repo.completePaidReceipt(
            editedHistory = receipt,
            cashPaidTomans = 0L,
            debtSettlementAmountTomans = 0L,
            customerCodeOrName = "505",
            cardPaidTomans = (receipt.totalFee - 50000L).coerceAtLeast(0L),
            creditUsedTomans = 50000L
        )
        assertTrue(dao.getAllCreditsList().isEmpty())

        // Record a Club Service with mixed cash+card -> creates SERVICE history and cash ledger entry
        repo.addServiceEntry("کپی رنگی", 45000L, "۱۰ برگ", cashPaidTomans = 25000L, cardPaidTomans = 20000L)
        assertTrue(dao.getAllHistoryList().any { it.entryType == "SERVICE" && it.totalFee == 45000L })
        assertTrue(dao.getAllCashEntriesList().any { it.amountTomans == 25000L && it.source == "SERVICE" })

        db.close()
    }
}
