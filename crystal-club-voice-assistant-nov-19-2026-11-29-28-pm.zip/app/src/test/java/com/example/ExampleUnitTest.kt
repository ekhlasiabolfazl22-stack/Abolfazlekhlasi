package com.example

import com.example.data.model.GameSystemEntity
import com.example.voice.PersianVoiceParser
import com.example.voice.VoiceCommandResult
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    private val testSystems = listOf(
        GameSystemEntity(1, "1", "پی اس فور ۱", "PS4", 60000, iconType = "gamepad", sortOrder = 1),
        GameSystemEntity(4, "4", "پی اس فور ۴", "PS4", 60000, iconType = "gamepad", sortOrder = 4),
        GameSystemEntity(7, "7", "پی اس فایو ۱", "PS5", 70000, iconType = "gamepad", sortOrder = 7),
        GameSystemEntity(13, "13", "عینک مجازی", "VR", 120000, iconType = "headset", sortOrder = 13),
        GameSystemEntity(14, "14", "فرمان بازی", "WHEEL", 100000, iconType = "steering_wheel", sortOrder = 14)
    )

    @Test
    fun `voice parser handles system x customer code duration and players`() {
        val r = PersianVoiceParser.parse("سیستم ۴؛ کد مشتری ۱۰۵؛ یک ساعت ؛۲ نفره", systems = testSystems)
        assertTrue(r is VoiceCommandResult.StartCountdownTime)
        val cmd = r as VoiceCommandResult.StartCountdownTime
        assertEquals(4, cmd.systemId)
        assertEquals("105", cmd.customerCode)
        assertEquals(60, cmd.durationMinutes)
        assertEquals(2, cmd.playerCount)
    }

    @Test
    fun `voice parser handles system x players customer code open mode`() {
        val r = PersianVoiceParser.parse("سیستم ۷ ؛ ۳ نفره ؛ کد مشتری ۲۰۴ ؛ آزاد", systems = testSystems)
        assertTrue(r is VoiceCommandResult.StartOpenTime)
        val cmd = r as VoiceCommandResult.StartOpenTime
        assertEquals(7, cmd.systemId)
        assertEquals("204", cmd.customerCode)
        assertEquals(3, cmd.playerCount)
        assertTrue(cmd.useCurrentTime)
    }

    @Test
    fun `voice parser handles system x players customer code amount`() {
        val r = PersianVoiceParser.parse("سیستم ۴ ؛ ۲ نفره ؛ کد مشتری ۳۰۱ ؛ مبلغ ۱۵۰۰۰۰", systems = testSystems)
        assertTrue(r is VoiceCommandResult.StartCountdownAmount)
        val cmd = r as VoiceCommandResult.StartCountdownAmount
        assertEquals(4, cmd.systemId)
        assertEquals("301", cmd.customerCode)
        assertEquals(2, cmd.playerCount)
        assertEquals(150000L, cmd.amountTomans)
    }

    @Test
    fun `voice parser handles system x start and finish`() {
        val startRes = PersianVoiceParser.parse("سیستم ۱۳ شروع", systems = testSystems)
        assertTrue(startRes is VoiceCommandResult.StartCountdownTime)
        assertEquals(13, (startRes as VoiceCommandResult.StartCountdownTime).systemId)
        assertEquals(60, startRes.durationMinutes)

        val endRes = PersianVoiceParser.parse("سیستم ۱۳ پایان", systems = testSystems)
        assertTrue(endRes is VoiceCommandResult.FinishSession)
        assertEquals(13, (endRes as VoiceCommandResult.FinishSession).systemId)
    }

    @Test
    fun `voice parser handles ps4 4 start open, 1 hour, and finish`() {
        val openRes = PersianVoiceParser.parse("پی اس فور چهار شروع", systems = testSystems)
        assertTrue(openRes is VoiceCommandResult.StartOpenTime)
        assertEquals(4, (openRes as VoiceCommandResult.StartOpenTime).systemId)

        val oneHourRes = PersianVoiceParser.parse("پی اس فور چهار یک ساعت", systems = testSystems)
        assertTrue(oneHourRes is VoiceCommandResult.StartCountdownTime)
        assertEquals(4, (oneHourRes as VoiceCommandResult.StartCountdownTime).systemId)
        assertEquals(60, oneHourRes.durationMinutes)

        val endRes = PersianVoiceParser.parse("پی اس فور چهار پایان", systems = testSystems)
        assertTrue(endRes is VoiceCommandResult.FinishSession)
        assertEquals(4, (endRes as VoiceCommandResult.FinishSession).systemId)
    }

    @Test
    fun `voice parser handles pause and resume in both word orders`() {
        val p1 = PersianVoiceParser.parse("سیستم ۴ توقف موقت", systems = testSystems)
        assertTrue(p1 is VoiceCommandResult.PauseSession)
        assertEquals(4, (p1 as VoiceCommandResult.PauseSession).systemId)

        val p2 = PersianVoiceParser.parse("توقف موقت سیستم ۷", systems = testSystems)
        assertTrue(p2 is VoiceCommandResult.PauseSession)
        assertEquals(7, (p2 as VoiceCommandResult.PauseSession).systemId)

        val r1 = PersianVoiceParser.parse("سیستم ۴ شروع مجدد", systems = testSystems)
        assertTrue(r1 is VoiceCommandResult.ResumeSession)
        assertEquals(4, (r1 as VoiceCommandResult.ResumeSession).systemId)

        val r2 = PersianVoiceParser.parse("شروع مجدد سیستم ۷", systems = testSystems)
        assertTrue(r2 is VoiceCommandResult.ResumeSession)
        assertEquals(7, (r2 as VoiceCommandResult.ResumeSession).systemId)
    }
}
