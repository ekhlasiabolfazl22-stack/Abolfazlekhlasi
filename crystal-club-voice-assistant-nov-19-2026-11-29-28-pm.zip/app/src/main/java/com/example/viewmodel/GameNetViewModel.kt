package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AlarmAndTtsManager
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.GameNetRepository
import com.example.data.repository.MiniPlayerCheckoutData
import com.example.data.repository.SeatResolutionInput
import com.example.data.repository.SessionCostCalculator
import com.example.service.GameNetForegroundService
import com.example.voice.PersianVoiceParser
import com.example.voice.VoiceCommandResult
import com.example.voice.VoiceEngineMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.max

enum class NavTab {
    SYSTEMS,
    CUSTOMERS,
    DEBTS,
    STATS,
    SETTINGS
}

enum class VoiceStartMode {
    TIME,
    AMOUNT,
    OPEN
}

data class PendingVoiceStartCommand(
    val systemId: Int,
    val systemDisplayName: String,
    val playerCount: Int,
    val mode: VoiceStartMode,
    val durationMinutes: Int = 60,
    val amountTomans: Long = 0L,
    val customerCode: String = "",
    val customStartHour: Int? = null,
    val customStartMinute: Int? = null,
    val rawTranscript: String = ""
)

data class SystemWithSession(
    val system: GameSystemEntity,
    val session: ActiveSessionEntity?,
    val remainingSeconds: Long,
    val elapsedSeconds: Long,
    val currentCostTomans: Long,
    val isExpired: Boolean
)

class GameNetViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("gamenet_prefs", Context.MODE_PRIVATE)
    private val repository: GameNetRepository
    private val ttsManager: AlarmAndTtsManager = AlarmAndTtsManager(application)

    val systems: StateFlow<List<GameSystemEntity>>
    val activeSessions: StateFlow<List<ActiveSessionEntity>>
    val snacks: StateFlow<List<SnackItemEntity>>
    val debts: StateFlow<List<CustomerDebtEntity>>
    val customerCredits: StateFlow<List<CustomerCreditEntity>>
    val history: StateFlow<List<GameHistoryEntity>>
    val cashEntries: StateFlow<List<CashEntryEntity>>
    val customers: StateFlow<List<CustomerEntity>>
    val profile: StateFlow<ClubProfileEntity?>
    val clubProfile: StateFlow<ClubProfileEntity?> get() = profile
    val customVoiceCommands: StateFlow<List<CustomVoiceCommandEntity>>
    val bankCards: StateFlow<List<BankCardEntity>>

    private val _currentNavTab = MutableStateFlow(NavTab.SYSTEMS)
    val currentNavTab: StateFlow<NavTab> = _currentNavTab.asStateFlow()

    private val _currentTimeMillis = MutableStateFlow(System.currentTimeMillis())
    val currentTimeMillis: StateFlow<Long> = _currentTimeMillis.asStateFlow()

    // Dialog & Popup states
    private val _selectedSystemForPopup = MutableStateFlow<GameSystemEntity?>(null)
    val selectedSystemForPopup: StateFlow<GameSystemEntity?> = _selectedSystemForPopup.asStateFlow()

    private val _selectedSystemForStart = MutableStateFlow<GameSystemEntity?>(null)
    val selectedSystemForStart: StateFlow<GameSystemEntity?> = _selectedSystemForStart.asStateFlow()

    // Voice engine & feedback
    private val _voiceEngineMode = MutableStateFlow(loadSavedVoiceEngineMode())
    val voiceEngineMode: StateFlow<VoiceEngineMode> = _voiceEngineMode.asStateFlow()

    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    private val _voiceTranscript = MutableStateFlow("")
    val voiceTranscript: StateFlow<String> = _voiceTranscript.asStateFlow()

    private val _voiceFeedbackMessage = MutableStateFlow<String?>(null)
    val voiceFeedbackMessage: StateFlow<String?> = _voiceFeedbackMessage.asStateFlow()

    private val _pendingVoiceStartCommand = MutableStateFlow<PendingVoiceStartCommand?>(null)
    val pendingVoiceStartCommand: StateFlow<PendingVoiceStartCommand?> = _pendingVoiceStartCommand.asStateFlow()

    private val _lastFinishedSession = MutableStateFlow<GameHistoryEntity?>(null)
    val lastFinishedSession: StateFlow<GameHistoryEntity?> = _lastFinishedSession.asStateFlow()

    private val _miniPlayerCheckoutState = MutableStateFlow<MiniPlayerCheckoutData?>(null)
    val miniPlayerCheckoutState: StateFlow<MiniPlayerCheckoutData?> = _miniPlayerCheckoutState.asStateFlow()

    private val _transferCandidateSystem = MutableStateFlow<GameSystemEntity?>(null)
    val transferCandidateSystem: StateFlow<GameSystemEntity?> = _transferCandidateSystem.asStateFlow()

    private var pendingReceiptSnapshot: ActiveSessionEntity? = null

    init {
        val db = AppDatabase.getDatabase(application)
        repository = GameNetRepository(db.gameNetDao())

        systems = repository.systems.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        activeSessions = repository.activeSessions.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        snacks = repository.snacks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        debts = repository.debts.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        customerCredits = repository.credits.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        history = repository.gameHistory.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        cashEntries = repository.cashEntries.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        customers = repository.customers.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        profile = repository.profile.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            null
        )

        customVoiceCommands = repository.customVoiceCommands.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        bankCards = repository.bankCards.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Real-time 1-second ticker for clock and live countdowns
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                _currentTimeMillis.value = System.currentTimeMillis()
                delay(1000)
            }
        }
    }

    private fun loadSavedVoiceEngineMode(): VoiceEngineMode {
        val saved = prefs.getString("voice_engine_mode", VoiceEngineMode.HYBRID.name)
        return try {
            VoiceEngineMode.valueOf(saved ?: VoiceEngineMode.HYBRID.name)
        } catch (_: Exception) {
            VoiceEngineMode.HYBRID
        }
    }

    fun setVoiceEngineMode(mode: VoiceEngineMode) {
        _voiceEngineMode.value = mode
        prefs.edit().putString("voice_engine_mode", mode.name).apply()
    }

    val systemsWithSessions: StateFlow<List<SystemWithSession>> = combine(
        systems,
        activeSessions,
        currentTimeMillis
    ) { sysList, sessionList, now ->
        val sessionMap = sessionList.associateBy { it.systemId }
        sysList.map { sys ->
            val session = sessionMap[sys.id]
            val effectiveNow = if (session != null && session.isPaused && session.pausedAtMillis > 0L) {
                session.pausedAtMillis
            } else {
                now
            }

            val remainingSec = if (session != null && session.isCountDown) {
                max(0L, (session.expectedEndTimeMillis - effectiveNow) / 1000L)
            } else 0L

            val elapsedSec = if (session != null) {
                max(0L, (effectiveNow - session.startTimeMillis) / 1000L)
            } else 0L

            val currentCost = if (session != null) {
                SessionCostCalculator.calculateLiveBilling(
                    session = session,
                    effectiveNowMillis = effectiveNow,
                    forFinalReceipt = false
                ).totalFeeWithSnacks
            } else 0L

            val isExpired = session != null && session.isCountDown && !session.isPaused &&
                session.expectedEndTimeMillis in 1..now &&
                !session.isAlarmDismissed

            SystemWithSession(
                system = sys,
                session = session,
                remainingSeconds = remainingSec,
                elapsedSeconds = elapsedSec,
                currentCostTomans = currentCost,
                isExpired = isExpired
            )
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun setNavTab(tab: NavTab) {
        _currentNavTab.value = tab
    }

    fun openSystemPopup(system: GameSystemEntity) {
        _selectedSystemForPopup.value = system
    }

    fun closeSystemPopup() {
        _selectedSystemForPopup.value = null
    }

    fun openStartDialog(system: GameSystemEntity) {
        _selectedSystemForStart.value = system
    }

    fun closeStartDialog() {
        _selectedSystemForStart.value = null
    }

    fun openTransferDialogForSystem(system: GameSystemEntity) {
        _transferCandidateSystem.value = system
    }

    fun closeTransferDialogForSystem() {
        _transferCandidateSystem.value = null
    }

    fun setVoiceListening(listening: Boolean) {
        _isVoiceListening.value = listening
        if (listening) {
            _voiceTranscript.value = ""
        }
    }

    fun setVoiceTranscript(text: String) {
        _voiceTranscript.value = text
    }

    fun clearVoiceFeedback() {
        _voiceFeedbackMessage.value = null
    }

    fun stopAudioBeforeListening() {
        ttsManager.stopSpeakingOnly()
    }

    fun speakReadyPrompt() {
        val msg = "مدیریت گیم‌نت آماده دریافت دستور صوتی است."
        _voiceFeedbackMessage.value = msg
        ttsManager.speakPersian(msg)
    }

    fun dismissLastFinishedReceipt() {
        pendingReceiptSnapshot = null
        _lastFinishedSession.value = null
    }

    fun cancelFinishAndResumeSession() {
        val snapshot = pendingReceiptSnapshot
        viewModelScope.launch {
            if (snapshot != null) {
                repository.restoreCancelledSession(snapshot)
                _voiceFeedbackMessage.value = "تسویه لغو شد و بازی ${snapshot.systemDisplayName} ادامه یافت."
            }
            pendingReceiptSnapshot = null
            _lastFinishedSession.value = null
        }
    }

    fun confirmSaveReceipt(editedHistory: GameHistoryEntity) {
        completePaidReceipt(
            editedHistory = editedHistory,
            cashPaidTomans = 0L,
            debtSettlementAmountTomans = 0L,
            customerCodeOrName = editedHistory.customerName
        )
    }

    fun completePaidReceipt(
        editedHistory: GameHistoryEntity,
        cashPaidTomans: Long = 0L,
        debtSettlementAmountTomans: Long = 0L,
        customerCodeOrName: String = editedHistory.customerName,
        cardPaidTomans: Long = 0L,
        seatResolutions: List<SeatResolutionInput> = emptyList(),
        creditUsedTomans: Long = 0L
    ) {
        viewModelScope.launch {
            repository.completePaidReceipt(
                editedHistory = editedHistory,
                cashPaidTomans = cashPaidTomans,
                debtSettlementAmountTomans = debtSettlementAmountTomans,
                customerCodeOrName = customerCodeOrName,
                cardPaidTomans = cardPaidTomans,
                seatResolutions = seatResolutions,
                creditUsedTomans = creditUsedTomans
            )
            pendingReceiptSnapshot = null
            _lastFinishedSession.value = null
            val parts = mutableListOf("فاکتور ${editedHistory.systemDisplayName} ثبت شد")
            if (creditUsedTomans > 0L) parts.add("کسر طلب: ${creditUsedTomans} ت")
            if (cardPaidTomans > 0L) parts.add("کارتخوان: ${cardPaidTomans} ت")
            if (cashPaidTomans > 0L) parts.add("نقدی: ${cashPaidTomans} ت")
            if (debtSettlementAmountTomans > 0L) parts.add("تسویه بدهی قبلی: ${debtSettlementAmountTomans} ت")
            _voiceFeedbackMessage.value = parts.joinToString(" | ")
        }
    }

    fun confirmDebtFromReceipt(editedHistory: GameHistoryEntity, customerInput: String) {
        registerReceiptAsDebt(
            editedHistory = editedHistory,
            customerInput = customerInput,
            cashPaidTomans = 0L,
            debtSettlementAmountTomans = 0L
        )
    }

    fun registerReceiptAsDebt(
        editedHistory: GameHistoryEntity,
        customerInput: String,
        cashPaidTomans: Long = 0L,
        debtSettlementAmountTomans: Long = 0L,
        cardPaidTomans: Long = 0L,
        seatResolutions: List<SeatResolutionInput> = emptyList(),
        creditUsedTomans: Long = 0L
    ) {
        viewModelScope.launch {
            val trimmed = customerInput.trim()
            if (trimmed.isNotBlank()) {
                repository.registerReceiptAsDebt(
                    editedHistory = editedHistory,
                    customerInput = trimmed,
                    cashPaidTomans = cashPaidTomans,
                    debtSettlementAmountTomans = debtSettlementAmountTomans,
                    cardPaidTomans = cardPaidTomans,
                    seatResolutions = seatResolutions,
                    creditUsedTomans = creditUsedTomans
                )
                pendingReceiptSnapshot = null
                _lastFinishedSession.value = null
                val rem = max(0L, editedHistory.totalFee - creditUsedTomans - cashPaidTomans - cardPaidTomans)
                _voiceFeedbackMessage.value = "مبلغ ${rem} تومان به حساب بدهی «$trimmed» منتقل شد (پس از تسویه به آمار فروش افزوده می‌شود)."
            }
        }
    }

    fun discardReceipt() {
        pendingReceiptSnapshot = null
        _lastFinishedSession.value = null
        _voiceFeedbackMessage.value = "فاکتور بازی ثبت نشد و در تاریخچه ذخیره نگردید."
    }

    fun startSessionWithDuration(
        system: GameSystemEntity,
        playerCount: Int,
        durationMinutes: Int,
        customerName: String = "",
        startTimeMillis: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            if (repository.isSystemBusy(system.id)) {
                val warn = "⚠️ ${system.displayName} فعال است و امکان ثبت مجدد وجود ندارد."
                _voiceFeedbackMessage.value = warn
                ttsManager.speakPersian(warn)
                return@launch
            }
            repository.startSessionWithDuration(system, playerCount, durationMinutes, customerName, startTimeMillis)
            closeStartDialog()
            _voiceFeedbackMessage.value = "تایمر ${system.displayName} با موفقیت شروع شد."
        }
    }

    fun startSessionWithAmount(
        system: GameSystemEntity,
        playerCount: Int,
        amountTomans: Long,
        customerName: String = "",
        startTimeMillis: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            if (repository.isSystemBusy(system.id)) {
                val warn = "⚠️ ${system.displayName} فعال است و امکان ثبت مجدد وجود ندارد."
                _voiceFeedbackMessage.value = warn
                ttsManager.speakPersian(warn)
                return@launch
            }
            repository.startSessionWithAmount(system, playerCount, amountTomans, customerName, startTimeMillis)
            closeStartDialog()
            _voiceFeedbackMessage.value = "تایمر ${system.displayName} به مبلغ $amountTomans تومان فعال شد."
        }
    }

    fun startOpenEnded(
        system: GameSystemEntity,
        playerCount: Int,
        customerName: String = "",
        startTimeMillis: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            if (repository.isSystemBusy(system.id)) {
                val warn = "⚠️ ${system.displayName} فعال است و امکان ثبت مجدد وجود ندارد."
                _voiceFeedbackMessage.value = warn
                ttsManager.speakPersian(warn)
                return@launch
            }
            repository.startOpenEndedSession(system, playerCount, startTimeMillis = startTimeMillis, customerName = customerName)
            closeStartDialog()
            _voiceFeedbackMessage.value = "${system.displayName} به صورت زمان باز شروع شد."
        }
    }

    fun addSnackToSession(
        systemId: Int,
        snackName: String,
        count: Int = 1,
        targetSeatId: String? = null
    ) {
        viewModelScope.launch {
            val success = repository.addSnackToSession(systemId, snackName, count, targetSeatId)
            if (success) {
                _voiceFeedbackMessage.value = "$count عدد $snackName به سیستم اضافه شد."
            }
        }
    }

    fun removeSnackLine(systemId: Int, lineId: String) {
        viewModelScope.launch {
            val ok = repository.removeSnackLineFromSession(systemId, lineId)
            if (ok) {
                _voiceFeedbackMessage.value = "خوراکی از حساب سیستم حذف شد."
            }
        }
    }

    fun updateSessionNote(systemId: Int, note: String) {
        viewModelScope.launch {
            val ok = repository.updateSessionNote(systemId, note)
            if (ok) {
                _voiceFeedbackMessage.value = "یادداشت سیستم ذخیره شد."
            }
        }
    }

    fun updateSeatCustomerName(systemId: Int, seatId: String, newNameOrCode: String) {
        viewModelScope.launch {
            val ok = repository.updateSeatCustomerInfo(systemId, seatId, newNameOrCode)
            if (ok) {
                _voiceFeedbackMessage.value = "نام بازیکن ویرایش شد."
            }
        }
    }

    fun modifyTimer(systemId: Int, deltaMinutes: Int) {
        viewModelScope.launch {
            stopAlarm()
            repository.modifySessionTimer(systemId, deltaMinutes)
            _voiceFeedbackMessage.value = "تایمر با موفقیت $deltaMinutes دقیقه اصلاح شد."
        }
    }

    fun continueSessionOpenEnded(systemId: Int) {
        viewModelScope.launch {
            stopAlarm()
            val ok = repository.convertCountdownToOpen(systemId)
            if (ok) {
                repository.resumeSession(systemId)
                _voiceFeedbackMessage.value = "تایم معکوس به زمان آزاد تبدیل شد و بازی ادامه یافت."
            }
        }
    }

    fun convertCountdownToOpen(systemId: Int) {
        viewModelScope.launch {
            stopAlarm()
            val ok = repository.convertCountdownToOpen(systemId)
            if (ok) {
                val msg = "تایمر معکوس به ساعت آزاد تبدیل شد (از ساعت شروع اولیه)."
                _voiceFeedbackMessage.value = msg
                ttsManager.speakPersian(msg)
            }
        }
    }

    fun convertOpenToCountdown(systemId: Int, targetDurationMinutes: Int) {
        viewModelScope.launch {
            stopAlarm()
            val (ok, msg) = repository.convertOpenToCountdown(systemId, targetDurationMinutes)
            if (ok) {
                _voiceFeedbackMessage.value = msg
                ttsManager.speakPersian(msg)
            }
        }
    }

    fun convertAmountToTime(systemId: Int, amountTomans: Long) {
        viewModelScope.launch {
            stopAlarm()
            val (ok, msg) = repository.convertAmountToTime(systemId, amountTomans)
            if (ok) {
                _voiceFeedbackMessage.value = msg
                ttsManager.speakPersian(msg)
            }
        }
    }

    fun pauseSession(systemId: Int) {
        viewModelScope.launch {
            stopAlarm()
            val ok = repository.pauseSession(systemId)
            if (ok) {
                _voiceFeedbackMessage.value = "زمان سیستم به صورت موقت متوقف شد."
            }
        }
    }

    fun resumeSession(systemId: Int) {
        viewModelScope.launch {
            val ok = repository.resumeSession(systemId)
            if (ok) {
                _voiceFeedbackMessage.value = "زمان سیستم مجدداً شروع شد."
            }
        }
    }

    fun updatePlayers(systemId: Int, newCount: Int) {
        viewModelScope.launch {
            val ok = repository.updateSessionPlayers(systemId, newCount)
            if (ok) {
                _voiceFeedbackMessage.value = "تعداد نفرات به $newCount نفر تغییر یافت و زمان قبلی بصورت مجزا ثبت شد."
            }
        }
    }

    fun updatePlayersFromStart(systemId: Int, newCount: Int, addedNames: List<String> = emptyList()) {
        viewModelScope.launch {
            val ok = repository.updateSessionPlayersFromStart(systemId, newCount, addedNames)
            if (ok) {
                _voiceFeedbackMessage.value = "تعداد نفرات از ابتدای بازی به $newCount نفر اصلاح شد."
            }
        }
    }

    fun addPlayersFromNow(systemId: Int, addedNames: List<String>) {
        viewModelScope.launch {
            val ok = repository.addPlayersFromNow(systemId, addedNames)
            if (ok) {
                _voiceFeedbackMessage.value = "بازیکن جدید از همین لحظه به بازی اضافه شد."
            }
        }
    }

    fun requestMiniCheckoutForSeat(systemId: Int, departingSeatId: String) {
        viewModelScope.launch {
            val data = repository.prepareMiniCheckoutForSeat(systemId, departingSeatId)
            if (data != null) {
                _miniPlayerCheckoutState.value = data
            }
        }
    }

    fun finalizeDepartingPlayerCheckout(
        checkout: MiniPlayerCheckoutData,
        editedHistory: GameHistoryEntity,
        settleAsDebt: Boolean,
        customerInput: String,
        cashPaidTomans: Long = 0L,
        cardPaidTomans: Long = 0L
    ) {
        viewModelScope.launch {
            val ok = repository.finalizeDepartingPlayerCheckout(
                checkout = checkout,
                editedHistory = editedHistory,
                settleAsDebt = settleAsDebt,
                customerInput = customerInput,
                cashPaidTomans = cashPaidTomans,
                cardPaidTomans = cardPaidTomans
            )
            _miniPlayerCheckoutState.value = null
            if (ok) {
                _voiceFeedbackMessage.value = if (settleAsDebt) {
                    "سهم «${checkout.departingSeat.displayName}» به دفتر بدهی منتقل شد و بازی سایرین ادامه دارد."
                } else {
                    "سهم «${checkout.departingSeat.displayName}» تسویه و در آمار فروش ثبت شد."
                }
            }
        }
    }

    fun dismissMiniCheckout() {
        _miniPlayerCheckoutState.value = null
    }

    fun transferSessionToSystem(fromSystemId: Int, targetSystem: GameSystemEntity) {
        transferOrMergePlayers(fromSystemId, null, "", targetSystem)
    }

    fun transferOrMergePlayers(
        fromSystemId: Int,
        selectedSeatIdsOrNullForAll: List<String>?,
        customerNameOrCode: String,
        targetSystem: GameSystemEntity
    ) {
        viewModelScope.launch {
            val res = repository.transferOrMergePlayers(
                fromSystemId = fromSystemId,
                selectedSeatIdsOrNullForAll = selectedSeatIdsOrNullForAll,
                customerNameOrCode = customerNameOrCode,
                targetSystem = targetSystem
            )
            _transferCandidateSystem.value = null
            _selectedSystemForPopup.value = null
            if (res.success) {
                ttsManager.speakPersian(res.message)
            }
            _voiceFeedbackMessage.value = res.message
        }
    }

    fun finishSession(systemId: Int, endTimeMillis: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            stopAlarm()
            val prepared = repository.prepareFinishSession(systemId, endTimeMillis)
            if (prepared != null) {
                val (historyRecord, originalSnapshot) = prepared
                pendingReceiptSnapshot = originalSnapshot
                _lastFinishedSession.value = historyRecord
                closeSystemPopup()
                val finishMsg = "پایان بازی ${historyRecord.systemDisplayName}. مجموع دریافتی: ${historyRecord.totalFee} تومان."
                _voiceFeedbackMessage.value = finishMsg
                ttsManager.speakPersian(finishMsg)
            }
        }
    }

    fun stopAlarm() {
        ttsManager.stopAlarm()
        GameNetForegroundService.stopAlarm(getApplication())
    }

    // Customer operations
    fun addCustomer(
        code: String,
        name: String,
        phone: String = "",
        nationalId: String = "",
        discountPercent: Int = 0
    ) {
        viewModelScope.launch {
            repository.addCustomer(code, name, phone, nationalId, discountPercent)
            _voiceFeedbackMessage.value = "مشتری $name با کد $code ثبت گردید."
        }
    }

    fun updateCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.updateCustomer(customer)
            _voiceFeedbackMessage.value = "اطلاعات مشتری ${customer.name} به‌روزرسانی شد."
        }
    }

    fun deleteCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
            _voiceFeedbackMessage.value = "مشتری ${customer.name} حذف شد."
        }
    }

    // Debts operations
    fun addDebt(name: String, amount: Long, note: String = "", code: String = "") {
        viewModelScope.launch {
            repository.addDebt(name, amount, note, code)
            _voiceFeedbackMessage.value = "بدهی $name به مبلغ $amount تومان ثبت شد."
        }
    }

    fun settleDebtAndTransferToStats(debt: CustomerDebtEntity) {
        viewModelScope.launch {
            repository.settleDebtAndTransferToStats(debt)
            _voiceFeedbackMessage.value = "بدهی ${debt.customerName} تسویه، به آمار فروش منتقل و از دفتر حسابداری پاک شد."
        }
    }

    fun updateOrAddDebtLineItems(debtId: Long, updatedItems: List<DebtLineItem>, updatedNote: String) {
        viewModelScope.launch {
            repository.updateOrAddDebtLineItems(debtId, updatedItems, updatedNote)
            _voiceFeedbackMessage.value = "بدهی مشتری با موفقیت ویرایش و به‌روزرسانی شد."
        }
    }

    fun toggleDebtSettled(debt: CustomerDebtEntity) {
        viewModelScope.launch {
            if (!debt.isSettled) {
                repository.settleDebtAndTransferToStats(debt)
            }
        }
    }

    fun updateDebt(debt: CustomerDebtEntity) {
        viewModelScope.launch {
            repository.updateDebt(debt)
            _voiceFeedbackMessage.value = "مبلغ/اطلاعات بدهی ${debt.customerName} ویرایش شد."
        }
    }

    fun deleteDebt(debt: CustomerDebtEntity) {
        viewModelScope.launch {
            repository.deleteDebt(debt)
            _voiceFeedbackMessage.value = "بدهی ${debt.customerName} حذف شد."
        }
    }

    // Customer Credits operations (طلب مشتری)
    fun addCustomerCredit(name: String, amount: Long, note: String = "", code: String = "") {
        viewModelScope.launch {
            if (amount > 0L && name.isNotBlank()) {
                repository.addCustomerCredit(name, amount, note, code)
                _voiceFeedbackMessage.value = "طلب $name به مبلغ $amount تومان ثبت شد."
            }
        }
    }

    fun deleteCustomerCredit(credit: CustomerCreditEntity) {
        viewModelScope.launch {
            repository.deleteCustomerCredit(credit)
            _voiceFeedbackMessage.value = "طلب ${credit.customerName} حذف شد."
        }
    }

    // Service Registration (خدمات گیم‌نت)
    fun addServiceEntry(
        title: String,
        amountTomans: Long,
        note: String = "",
        cashPaidTomans: Long = 0L,
        cardPaidTomans: Long = 0L
    ) {
        viewModelScope.launch {
            if (title.isNotBlank() && amountTomans > 0L) {
                repository.addServiceEntry(title, amountTomans, note, cashPaidTomans, cardPaidTomans)
                _voiceFeedbackMessage.value = "خدمت «$title» به مبلغ $amountTomans تومان ثبت شد."
            }
        }
    }

    // History operations (Edit / Delete / Clear)
    fun updateHistoryRecord(history: GameHistoryEntity) {
        viewModelScope.launch {
            repository.updateHistoryRecord(history)
            _voiceFeedbackMessage.value = "ریز بازی با موفقیت ویرایش شد."
        }
    }

    fun deleteHistoryRecord(history: GameHistoryEntity) {
        viewModelScope.launch {
            repository.deleteHistoryRecord(history)
            _voiceFeedbackMessage.value = "ریز بازی با موفقیت حذف شد."
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            _voiceFeedbackMessage.value = "تمامی گزارش‌های ریز بازی حذف گردید."
        }
    }

    // Cash ledger operations
    fun addCashEntry(amountTomans: Long, note: String = "", customerName: String = "", source: String = "MANUAL") {
        viewModelScope.launch {
            if (amountTomans > 0L) {
                repository.addCashEntry(amountTomans, note, customerName, source)
                _voiceFeedbackMessage.value = "مبلغ نقدی $amountTomans تومان ثبت شد."
            }
        }
    }

    fun updateCashEntry(entry: CashEntryEntity) {
        viewModelScope.launch {
            repository.updateCashEntry(entry)
            _voiceFeedbackMessage.value = "تراکنش نقدی با موفقیت ویرایش شد."
        }
    }

    fun deleteCashEntry(entry: CashEntryEntity) {
        viewModelScope.launch {
            repository.deleteCashEntry(entry)
            _voiceFeedbackMessage.value = "تراکنش نقدی حذف شد."
        }
    }

    // Profile
    fun saveProfile(clubName: String, managerName: String, phone: String, avatarUri: String = "") {
        viewModelScope.launch {
            val prof = ClubProfileEntity(
                id = 1,
                clubName = clubName.trim(),
                managerName = managerName.trim(),
                phoneNumber = phone.trim(),
                avatarUri = avatarUri
            )
            repository.saveProfile(prof)
            _voiceFeedbackMessage.value = "پروفایل گیم‌نت ذخیره شد."
        }
    }

    // Custom Voice Commands
    fun addCustomVoiceCommand(
        phrase: String,
        targetSystemId: Int,
        targetSystemName: String,
        players: Int,
        durationMin: Int,
        mode: String = "TIME",
        amountTomans: Long = 0L
    ) {
        viewModelScope.launch {
            repository.addCustomVoiceCommand(
                phrase = phrase,
                targetSystemId = targetSystemId,
                targetSystemName = targetSystemName,
                playerCount = players,
                durationMinutes = durationMin,
                mode = mode,
                amountTomans = amountTomans
            )
            _voiceFeedbackMessage.value = "دستور صوتی «$phrase» در حافظه ثبت گردید."
        }
    }

    fun deleteCustomVoiceCommand(cmd: CustomVoiceCommandEntity) {
        viewModelScope.launch {
            repository.deleteCustomVoiceCommand(cmd)
        }
    }

    fun deleteCustomVoiceCommandsByIds(ids: List<Long>) {
        viewModelScope.launch {
            repository.deleteCustomVoiceCommandsByIds(ids)
            _voiceFeedbackMessage.value = "دستورات انتخاب شده حذف شدند."
        }
    }

    fun clearAllCustomVoiceCommands() {
        viewModelScope.launch {
            repository.clearAllCustomVoiceCommands()
            _voiceFeedbackMessage.value = "تمامی دستورات تایپی ذخیره شده حذف شدند."
        }
    }

    // Bank Cards
    fun addBankCard(bankName: String, cardNumber: String, cardHolder: String = "") {
        viewModelScope.launch {
            repository.addBankCard(bankName, cardNumber, cardHolder)
            _voiceFeedbackMessage.value = "شماره کارت $cardNumber ثبت شد."
        }
    }

    fun deleteBankCard(card: BankCardEntity) {
        viewModelScope.launch {
            repository.deleteBankCard(card)
        }
    }

    // Backup & Restore (includes app preferences)
    suspend fun exportBackupJson(): String {
        val prefsObj = JSONObject().apply {
            put("voiceEngineMode", _voiceEngineMode.value.name)
        }
        return repository.exportBackupJson(prefsObj)
    }

    fun importBackupJson(jsonString: String, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val success = repository.importBackupJson(jsonString)
            if (success) {
                try {
                    val root = JSONObject(jsonString)
                    val prefObj = root.optJSONObject("preferences")
                    val modeName = prefObj?.optString("voiceEngineMode", "") ?: ""
                    if (modeName.isNotBlank()) {
                        try {
                            setVoiceEngineMode(VoiceEngineMode.valueOf(modeName))
                        } catch (_: Exception) {}
                    }
                } catch (_: Exception) {}
                _voiceFeedbackMessage.value = "تمامی اطلاعات با موفقیت بازیابی شد."
            } else {
                _voiceFeedbackMessage.value = "خطا در بازیابی اطلاعات فایل پشتیبان."
            }
            onResult(success)
        }
    }

    // Multi-candidate voice execution for higher recognition accuracy
    fun executeVoiceCandidates(candidates: List<String>) {
        if (candidates.isEmpty()) return
        val customCmds = customVoiceCommands.value
        val sysList = systems.value
        val bestText = candidates.firstOrNull { cand ->
            PersianVoiceParser.parse(cand, customCmds, sysList) !is VoiceCommandResult.Unknown
        } ?: candidates.first()
        executeVoiceCommand(bestText)
    }

    fun confirmPendingVoiceStart(
        systemId: Int,
        playerCount: Int,
        mode: VoiceStartMode,
        durationMinutes: Int,
        amountTomans: Long,
        customerCode: String,
        customStartHour: Int? = null,
        customStartMinute: Int? = null
    ) {
        viewModelScope.launch {
            val sys = repository.getSystemById(systemId)
            if (sys == null) {
                _voiceFeedbackMessage.value = "سیستم انتخاب شده یافت نشد."
                return@launch
            }
            if (repository.isSystemBusy(sys.id)) {
                val warn = "⚠️ ${sys.displayName} در حال حاضر فعال است و امکان ثبت مجدد وجود ندارد."
                _voiceFeedbackMessage.value = warn
                ttsManager.speakPersian(warn)
                return@launch
            }
            val safePlayers = playerCount.coerceIn(1, 8)
            val msg: String
            when (mode) {
                VoiceStartMode.TIME -> {
                    val mins = durationMinutes.coerceAtLeast(1)
                    repository.startSessionWithDuration(sys, safePlayers, mins, customerCode)
                    msg = "${sys.displayName} برای $safePlayers نفر به مدت $mins دقیقه شروع شد."
                }
                VoiceStartMode.AMOUNT -> {
                    val amt = amountTomans.coerceAtLeast(1000L)
                    repository.startSessionWithAmount(sys, safePlayers, amt, customerCode)
                    msg = "${sys.displayName} برای $safePlayers نفر با مبلغ $amt تومان فعال شد."
                }
                VoiceStartMode.OPEN -> {
                    val startMillis = if (customStartHour != null && customStartMinute != null) {
                        Calendar.getInstance().apply {
                            set(Calendar.HOUR_OF_DAY, customStartHour)
                            set(Calendar.MINUTE, customStartMinute)
                            set(Calendar.SECOND, 0)
                        }.timeInMillis
                    } else {
                        System.currentTimeMillis()
                    }
                    repository.startOpenEndedSession(
                        system = sys,
                        playerCount = safePlayers,
                        startTimeMillis = startMillis,
                        customerName = customerCode
                    )
                    msg = "${sys.displayName} برای $safePlayers نفر به صورت زمان آزاد شروع شد."
                }
            }
            _pendingVoiceStartCommand.value = null
            _voiceFeedbackMessage.value = msg
            ttsManager.speakPersian(msg)
        }
    }

    fun dismissPendingVoiceStart() {
        _pendingVoiceStartCommand.value = null
    }

    // Execute Voice Command
    fun executeVoiceCommand(rawInput: String) {
        _voiceTranscript.value = rawInput
        viewModelScope.launch {
            val customCmds = customVoiceCommands.value
            val sysList = systems.value
            val result = PersianVoiceParser.parse(rawInput, customCmds, sysList)

            when (result) {
                is VoiceCommandResult.CustomAction -> {
                    val sys = repository.getSystemById(result.systemId)
                    if (sys != null) {
                        if (repository.isSystemBusy(sys.id)) {
                            val warn = "⚠️ ${sys.displayName} در حال حاضر فعال است."
                            _voiceFeedbackMessage.value = warn
                            ttsManager.speakPersian(warn)
                            return@launch
                        }
                        val vMode = when (result.mode) {
                            "OPEN" -> VoiceStartMode.OPEN
                            "AMOUNT" -> VoiceStartMode.AMOUNT
                            else -> VoiceStartMode.TIME
                        }
                        _pendingVoiceStartCommand.value = PendingVoiceStartCommand(
                            systemId = sys.id,
                            systemDisplayName = sys.displayName,
                            playerCount = result.playerCount,
                            mode = vMode,
                            durationMinutes = result.durationMinutes.coerceAtLeast(5),
                            amountTomans = result.amountTomans.coerceAtLeast(10000L),
                            customerCode = result.customerCode,
                            rawTranscript = rawInput
                        )
                        _voiceFeedbackMessage.value = "پنجره تایید شروع ${sys.displayName} باز شد."
                    } else {
                        _voiceFeedbackMessage.value = "سیستم مورد نظر یافت نشد."
                    }
                }

                is VoiceCommandResult.WakeUp -> {
                    speakReadyPrompt()
                }

                is VoiceCommandResult.StartCountdownTime -> {
                    val sys = repository.getSystemById(result.systemId)
                    if (sys != null) {
                        if (repository.isSystemBusy(sys.id)) {
                            val warn = "⚠️ ${sys.displayName} در حال حاضر فعال می‌باشد و امکان ثبت مجدد وجود ندارد."
                            _voiceFeedbackMessage.value = warn
                            ttsManager.speakPersian(warn)
                            return@launch
                        }
                        _pendingVoiceStartCommand.value = PendingVoiceStartCommand(
                            systemId = sys.id,
                            systemDisplayName = sys.displayName,
                            playerCount = result.playerCount,
                            mode = VoiceStartMode.TIME,
                            durationMinutes = result.durationMinutes,
                            customerCode = result.customerCode,
                            rawTranscript = rawInput
                        )
                        _voiceFeedbackMessage.value = "لطفاً شروع ${sys.displayName} را تایید کنید."
                    } else {
                        _voiceFeedbackMessage.value = "سیستم پیدا نشد"
                    }
                }

                is VoiceCommandResult.StartCountdownAmount -> {
                    val sys = repository.getSystemById(result.systemId)
                    if (sys != null) {
                        if (repository.isSystemBusy(sys.id)) {
                            val warn = "⚠️ ${sys.displayName} در حال حاضر فعال می‌باشد و امکان ثبت مجدد وجود ندارد."
                            _voiceFeedbackMessage.value = warn
                            ttsManager.speakPersian(warn)
                            return@launch
                        }
                        _pendingVoiceStartCommand.value = PendingVoiceStartCommand(
                            systemId = sys.id,
                            systemDisplayName = sys.displayName,
                            playerCount = result.playerCount,
                            mode = VoiceStartMode.AMOUNT,
                            amountTomans = result.amountTomans,
                            customerCode = result.customerCode,
                            rawTranscript = rawInput
                        )
                        _voiceFeedbackMessage.value = "لطفاً شروع ${sys.displayName} را تایید کنید."
                    } else {
                        _voiceFeedbackMessage.value = "سیستم مورد نظر یافت نشد"
                    }
                }

                is VoiceCommandResult.StartOpenTime -> {
                    val sys = repository.getSystemById(result.systemId)
                    if (sys != null) {
                        if (repository.isSystemBusy(sys.id)) {
                            val warn = "⚠️ ${sys.displayName} در حال حاضر فعال می‌باشد و امکان ثبت مجدد وجود ندارد."
                            _voiceFeedbackMessage.value = warn
                            ttsManager.speakPersian(warn)
                            return@launch
                        }
                        _pendingVoiceStartCommand.value = PendingVoiceStartCommand(
                            systemId = sys.id,
                            systemDisplayName = sys.displayName,
                            playerCount = result.playerCount,
                            mode = VoiceStartMode.OPEN,
                            customerCode = result.customerCode,
                            customStartHour = if (result.useCurrentTime) null else result.hour,
                            customStartMinute = if (result.useCurrentTime) null else result.minute,
                            rawTranscript = rawInput
                        )
                        _voiceFeedbackMessage.value = "لطفاً شروع ${sys.displayName} را تایید کنید."
                    } else {
                        _voiceFeedbackMessage.value = "سیستم مورد نظر یافت نشد"
                    }
                }

                is VoiceCommandResult.FinishAtTime -> {
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, result.hour)
                        set(Calendar.MINUTE, result.minute)
                        set(Calendar.SECOND, 0)
                    }
                    finishSession(result.systemId, cal.timeInMillis)
                }

                is VoiceCommandResult.AddSnack -> {
                    val success = repository.addSnackToSession(result.systemId, result.snackName, result.count)
                    if (success) {
                        val msg = "${result.count} عدد ${result.snackName} به ${result.systemName} اضافه شد."
                        _voiceFeedbackMessage.value = msg
                        ttsManager.speakPersian(msg)
                    } else {
                        _voiceFeedbackMessage.value = "افزودن خوراکی ناموفق بود"
                    }
                }

                is VoiceCommandResult.FinishSession -> {
                    finishSession(result.systemId)
                }

                is VoiceCommandResult.PauseSession -> {
                    val ok = repository.pauseSession(result.systemId)
                    val msg = if (ok) {
                        "${result.systemName} به صورت موقت متوقف شد."
                    } else {
                        "${result.systemName} در حال حاضر بازی فعالی ندارد."
                    }
                    _voiceFeedbackMessage.value = msg
                    ttsManager.speakPersian(msg)
                }

                is VoiceCommandResult.ResumeSession -> {
                    val ok = repository.resumeSession(result.systemId)
                    val msg = if (ok) {
                        "${result.systemName} مجدداً شروع شد."
                    } else {
                        "${result.systemName} در حال حاضر بازی فعالی ندارد."
                    }
                    _voiceFeedbackMessage.value = msg
                    ttsManager.speakPersian(msg)
                }

                is VoiceCommandResult.OpenPopup -> {
                    val sys = repository.getSystemById(result.systemId)
                    if (sys != null) {
                        openSystemPopup(sys)
                        val msg = "پاپ‌آپ ${sys.displayName} باز شد."
                        _voiceFeedbackMessage.value = msg
                    }
                }

                is VoiceCommandResult.RegisterDebt -> {
                    repository.addDebt(result.customerName, result.amountTomans, "ثبت صوتی")
                    val msg = "بدهی ${result.customerName} به مبلغ ${result.amountTomans} تومان در دفتر حسابداری ثبت شد."
                    _voiceFeedbackMessage.value = msg
                    ttsManager.speakPersian(msg)
                }

                is VoiceCommandResult.ConvertOpenToCountdown -> {
                    val (ok, msg) = repository.convertOpenToCountdown(result.systemId, result.durationMinutes)
                    _voiceFeedbackMessage.value = if (ok) msg else "${result.systemName} بازی فعالی ندارد."
                    if (ok) ttsManager.speakPersian(msg)
                }

                is VoiceCommandResult.ConvertCountdownToOpen -> {
                    val ok = repository.convertCountdownToOpen(result.systemId)
                    val msg = if (ok) "${result.systemName} از معکوس به زمان آزاد تبدیل شد." else "${result.systemName} بازی فعالی ندارد."
                    _voiceFeedbackMessage.value = msg
                    if (ok) ttsManager.speakPersian(msg)
                }

                is VoiceCommandResult.ConvertAmountToTime -> {
                    val (ok, msg) = repository.convertAmountToTime(result.systemId, result.amountTomans)
                    _voiceFeedbackMessage.value = if (ok) msg else "${result.systemName} بازی فعالی ندارد."
                    if (ok) ttsManager.speakPersian(msg)
                }

                is VoiceCommandResult.Unknown -> {
                    _voiceFeedbackMessage.value = result.message
                }
            }
        }
    }

    fun updateSystem(system: GameSystemEntity) {
        viewModelScope.launch {
            repository.updateSystem(system)
        }
    }

    fun addNewSystem(displayName: String, systemType: String, hourlyRate: Long) {
        viewModelScope.launch {
            val sys = repository.addNewSystem(displayName, systemType, hourlyRate)
            _voiceFeedbackMessage.value = "دستگاه «${sys.displayName}» با کد ${sys.code} اضافه شد."
        }
    }

    fun addSnackItem(name: String, priceTomans: Long, category: String) {
        viewModelScope.launch {
            repository.addSnackItem(name, priceTomans, category)
        }
    }

    fun updateSnackItem(snack: SnackItemEntity) {
        viewModelScope.launch {
            repository.updateSnackItem(snack)
        }
    }

    fun deleteSnackItem(snack: SnackItemEntity) {
        viewModelScope.launch {
            repository.deleteSnackItem(snack)
        }
    }

    // Aliases matching UI callers
    fun updateHistory(history: GameHistoryEntity) = updateHistoryRecord(history)
    fun deleteHistory(history: GameHistoryEntity) = deleteHistoryRecord(history)
    fun addCustomCommand(
        phrase: String,
        targetSystemId: Int,
        targetSystemName: String,
        players: Int,
        durationMin: Int,
        mode: String = "TIME",
        amountTomans: Long = 0L
    ) = addCustomVoiceCommand(phrase, targetSystemId, targetSystemName, players, durationMin, mode, amountTomans)

    fun deleteCustomCommand(cmd: CustomVoiceCommandEntity) = deleteCustomVoiceCommand(cmd)
    fun updateClubProfile(clubName: String, managerName: String, phone: String, avatar: String = "") =
        saveProfile(clubName, managerName, phone, avatar)

    fun requestBatteryOptimizationExemption(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val packageName = context.packageName
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        }
    }

    fun requestCleanExit(context: Context) {
        stopAlarm()
        GameNetForegroundService.closeAppCleanly(context)
    }

    override fun onCleared() {
        ttsManager.release()
        super.onCleared()
    }
}
