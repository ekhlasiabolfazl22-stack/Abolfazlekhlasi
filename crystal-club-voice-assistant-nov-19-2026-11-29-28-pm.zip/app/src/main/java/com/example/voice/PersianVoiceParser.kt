package com.example.voice

import com.example.data.model.CustomVoiceCommandEntity
import com.example.data.model.GameSystemEntity
import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

sealed class VoiceCommandResult {
    object WakeUp : VoiceCommandResult()

    data class StartCountdownTime(
        val systemId: Int,
        val systemName: String,
        val playerCount: Int,
        val durationMinutes: Int,
        val customerCode: String = ""
    ) : VoiceCommandResult()

    data class StartCountdownAmount(
        val systemId: Int,
        val systemName: String,
        val playerCount: Int,
        val amountTomans: Long,
        val customerCode: String = ""
    ) : VoiceCommandResult()

    data class StartOpenTime(
        val systemId: Int,
        val systemName: String,
        val playerCount: Int,
        val hour: Int,
        val minute: Int,
        val customerCode: String = "",
        val useCurrentTime: Boolean = false
    ) : VoiceCommandResult()

    data class FinishAtTime(
        val systemId: Int,
        val systemName: String,
        val hour: Int,
        val minute: Int
    ) : VoiceCommandResult()

    data class AddSnack(
        val systemId: Int,
        val systemName: String,
        val snackName: String,
        val count: Int = 1
    ) : VoiceCommandResult()

    data class FinishSession(
        val systemId: Int,
        val systemName: String
    ) : VoiceCommandResult()

    data class PauseSession(
        val systemId: Int,
        val systemName: String
    ) : VoiceCommandResult()

    data class ResumeSession(
        val systemId: Int,
        val systemName: String
    ) : VoiceCommandResult()

    data class OpenPopup(
        val systemId: Int,
        val systemName: String
    ) : VoiceCommandResult()

    data class RegisterDebt(
        val customerName: String,
        val amountTomans: Long
    ) : VoiceCommandResult()

    data class ConvertOpenToCountdown(
        val systemId: Int,
        val systemName: String,
        val durationMinutes: Int
    ) : VoiceCommandResult()

    data class ConvertCountdownToOpen(
        val systemId: Int,
        val systemName: String
    ) : VoiceCommandResult()

    data class ConvertAmountToTime(
        val systemId: Int,
        val systemName: String,
        val amountTomans: Long
    ) : VoiceCommandResult()

    data class CustomAction(
        val systemId: Int,
        val systemName: String,
        val playerCount: Int,
        val durationMinutes: Int,
        val mode: String,
        val amountTomans: Long,
        val phrase: String,
        val customerCode: String = ""
    ) : VoiceCommandResult()

    data class Unknown(val rawText: String, val message: String) : VoiceCommandResult()
}

object PersianVoiceParser {

    fun parse(
        rawInput: String,
        customCommands: List<CustomVoiceCommandEntity> = emptyList(),
        systems: List<GameSystemEntity> = emptyList()
    ): VoiceCommandResult {
        val text = normalize(rawInput).trim()

        if (text.isEmpty()) {
            return VoiceCommandResult.Unknown(rawInput, "متن صوتی خالی است")
        }

        // Extract optional customer code first so its digits don't collide with system/time numbers
        val (customerCode, workingText) = extractCustomerCodeAndStrip(text)

        // Check against user-defined custom typed commands (exact/contains first, then fuzzy for offline ASR)
        val sortedCustom = customCommands.sortedByDescending { it.commandPhrase.length }
        for (cmd in sortedCustom) {
            val normalizedPhrase = normalize(cmd.commandPhrase).trim()
            if (normalizedPhrase.isNotBlank() &&
                (workingText == normalizedPhrase ||
                    workingText.contains(normalizedPhrase) ||
                    text.contains(normalizedPhrase) ||
                    (workingText.length >= 3 && normalizedPhrase.contains(workingText)))
            ) {
                return VoiceCommandResult.CustomAction(
                    systemId = cmd.targetSystemId,
                    systemName = cmd.targetSystemName,
                    playerCount = cmd.playerCount,
                    durationMinutes = cmd.durationMinutes,
                    mode = cmd.mode,
                    amountTomans = cmd.amountTomans,
                    phrase = cmd.commandPhrase,
                    customerCode = customerCode
                )
            }
        }

        // Fuzzy match custom commands (especially helpful for offline Vosk speech variants)
        var bestFuzzyCmd: CustomVoiceCommandEntity? = null
        var bestScore = 0.0
        for (cmd in sortedCustom) {
            val normPhrase = normalize(cmd.commandPhrase).trim()
            if (normPhrase.length < 3) continue
            val sim = similarityScore(workingText, normPhrase)
            if (sim >= 0.74 && sim > bestScore) {
                bestScore = sim
                bestFuzzyCmd = cmd
            }
        }
        if (bestFuzzyCmd != null) {
            return VoiceCommandResult.CustomAction(
                systemId = bestFuzzyCmd.targetSystemId,
                systemName = bestFuzzyCmd.targetSystemName,
                playerCount = bestFuzzyCmd.playerCount,
                durationMinutes = bestFuzzyCmd.durationMinutes,
                mode = bestFuzzyCmd.mode,
                amountTomans = bestFuzzyCmd.amountTomans,
                phrase = bestFuzzyCmd.commandPhrase,
                customerCode = customerCode
            )
        }

        // 1. Check for wake up
        if (workingText.contains("بازشو") || workingText.contains("باز شو") ||
            workingText == "گیم نت" || workingText.contains("سلام گیم نت")
        ) {
            return VoiceCommandResult.WakeUp
        }

        // 2. Check for Debt: e.g. "مبین دهقان چهل هزار تومن بدهی"
        if (workingText.contains("بدهی") || workingText.contains("نسیه") || workingText.contains("حساب دفتری")) {
            val debtParsed = parseDebt(workingText)
            if (debtParsed != null) return debtParsed
        }

        // Identify Target System dynamically from DB systems & aliases
        val detectedSystem = detectSystem(workingText, systems)

        // 2.5 Mode Conversion Voice Commands on an already running system
        if (detectedSystem != null) {
            // آزاد به معکوس (e.g. "کد 4 آزاد به معکوس 30 دقیقه" or "کد 4 آزاد به معکوس یک ساعت")
            if (workingText.contains("آزاد به معکوس") || workingText.contains("ازاد به معکوس")) {
                val afterConv = workingText.substringAfter("معکوس").trim()
                val durationMin = extractDurationMinutes(afterConv.ifBlank { workingText })
                return VoiceCommandResult.ConvertOpenToCountdown(
                    systemId = detectedSystem.first,
                    systemName = detectedSystem.second,
                    durationMinutes = durationMin.coerceAtLeast(1)
                )
            }

            // معکوس به آزاد (e.g. "کد 4 معکوس به آزاد")
            if (workingText.contains("معکوس به آزاد") || workingText.contains("معکوس به ازاد")) {
                return VoiceCommandResult.ConvertCountdownToOpen(
                    systemId = detectedSystem.first,
                    systemName = detectedSystem.second
                )
            }

            // مبلغ به تایم (e.g. "کد 4 ؛ 50000 تومن به تایم" or "کد 4 صد هزار تومان به تایم")
            if (workingText.contains("به تایم") &&
                (workingText.contains("تومان") || workingText.contains("تومن") || workingText.contains("مبلغ") || workingText.contains("هزار") || workingText.contains("میلیون"))
            ) {
                val strippedForAmt = stripSystemPrefixForAmount(workingText)
                val amt = extractAmountTomans(strippedForAmt).let {
                    if (it > 0L) it else extractAmountTomans(workingText)
                }
                if (amt > 0L) {
                    return VoiceCommandResult.ConvertAmountToTime(
                        systemId = detectedSystem.first,
                        systemName = detectedSystem.second,
                        amountTomans = amt
                    )
                }
            }
        }

        // 3. Pause / Resume commands
        if (detectedSystem != null &&
            (workingText.contains("توقف موقت") || workingText.contains("توقف") ||
                workingText.contains("مکث") || workingText.contains("استاپ") || workingText.contains("پاز"))
        ) {
            return VoiceCommandResult.PauseSession(
                systemId = detectedSystem.first,
                systemName = detectedSystem.second
            )
        }

        if (detectedSystem != null &&
            (workingText.contains("شروع مجدد") || workingText.contains("ادامه بازی") ||
                workingText.contains("ادامه بده") || workingText.contains("از سر گیری") ||
                workingText.contains("ریزیوم") || workingText.contains("ادامه سیستم"))
        ) {
            return VoiceCommandResult.ResumeSession(
                systemId = detectedSystem.first,
                systemName = detectedSystem.second
            )
        }

        // 4. Add snack
        if (detectedSystem != null && (workingText.contains("آبمیوه") || workingText.contains("کیک") ||
                workingText.contains("نوشابه") || workingText.contains("ریدبول") || workingText.contains("هایپ") ||
                workingText.contains("چیپس") || workingText.contains("پفک") || workingText.contains("چای") ||
                workingText.contains("اسپرسو") || workingText.contains("آب معدنی") || workingText.contains("خوراکی") || workingText.contains("عدد"))
        ) {
            val snackParsed = parseSnack(workingText, detectedSystem)
            if (snackParsed != null) return snackParsed
        }

        // 5. Finish session
        if (detectedSystem != null &&
            (workingText.contains("پایان") || workingText.contains("اتمام") ||
                workingText.contains("بستن") || workingText.contains("تسویه") ||
                workingText.contains("قطع") || workingText.contains("تموم"))
        ) {
            if (workingText.contains("ساعت پایان")) {
                val timeParsed = parseTime(workingText, "ساعت پایان")
                if (timeParsed != null) {
                    return VoiceCommandResult.FinishAtTime(
                        systemId = detectedSystem.first,
                        systemName = detectedSystem.second,
                        hour = timeParsed.first,
                        minute = timeParsed.second
                    )
                }
            }
            return VoiceCommandResult.FinishSession(
                systemId = detectedSystem.first,
                systemName = detectedSystem.second
            )
        }

        // 6. Open-ended with explicit "ساعت شروع"
        if (detectedSystem != null && (workingText.contains("ساعت شروع") || workingText.contains("شروع از ساعت"))) {
            val players = extractPlayerCount(workingText)
            val timeParsed = parseTime(workingText, "ساعت شروع") ?: parseTime(workingText, "شروع") ?: Pair(12, 0)
            return VoiceCommandResult.StartOpenTime(
                systemId = detectedSystem.first,
                systemName = detectedSystem.second,
                playerCount = players,
                hour = timeParsed.first,
                minute = timeParsed.second,
                customerCode = customerCode,
                useCurrentTime = false
            )
        }

        // 7. Explicit "آزاد" mode
        if (detectedSystem != null && (workingText.contains("آزاد") || workingText.contains("تایم باز") || workingText.contains("ساعت باز"))) {
            val players = extractPlayerCount(workingText)
            val cal = Calendar.getInstance()
            return VoiceCommandResult.StartOpenTime(
                systemId = detectedSystem.first,
                systemName = detectedSystem.second,
                playerCount = players,
                hour = cal.get(Calendar.HOUR_OF_DAY),
                minute = cal.get(Calendar.MINUTE),
                customerCode = customerCode,
                useCurrentTime = true
            )
        }

        // 8. Countdown by Amount
        if (detectedSystem != null && (workingText.contains("مبلغ") || workingText.contains("تومان") || workingText.contains("تومن") || workingText.contains("هزار") || workingText.contains("میلیون"))) {
            val players = extractPlayerCount(workingText)
            val amount = extractAmountTomans(stripSystemPrefixForAmount(workingText)).let {
                if (it > 0L) it else extractAmountTomans(workingText)
            }
            if (amount > 0) {
                return VoiceCommandResult.StartCountdownAmount(
                    systemId = detectedSystem.first,
                    systemName = detectedSystem.second,
                    playerCount = players,
                    amountTomans = amount,
                    customerCode = customerCode
                )
            }
        }

        // 9. Countdown by Time
        if (detectedSystem != null && (workingText.contains("ساعت") || workingText.contains("دقیقه") || workingText.contains("تایم") || workingText.contains("ربع"))) {
            val players = extractPlayerCount(workingText)
            val durationMin = extractDurationMinutes(workingText)
            if (durationMin > 0) {
                return VoiceCommandResult.StartCountdownTime(
                    systemId = detectedSystem.first,
                    systemName = detectedSystem.second,
                    playerCount = players,
                    durationMinutes = durationMin,
                    customerCode = customerCode
                )
            }
        }

        // 10. "شروع" keyword without explicit time or amount
        if (detectedSystem != null && workingText.contains("شروع")) {
            val players = extractPlayerCount(workingText)
            val isGenericSystemSyntax = (workingText.contains("سیستم") || workingText.contains("دستگاه") || workingText.contains("کد")) &&
                !workingText.contains("پی اس") && !workingText.contains("پلی استیشن") && !workingText.contains("ps")
            return if (isGenericSystemSyntax) {
                VoiceCommandResult.StartCountdownTime(
                    systemId = detectedSystem.first,
                    systemName = detectedSystem.second,
                    playerCount = players,
                    durationMinutes = 60,
                    customerCode = customerCode
                )
            } else {
                val cal = Calendar.getInstance()
                VoiceCommandResult.StartOpenTime(
                    systemId = detectedSystem.first,
                    systemName = detectedSystem.second,
                    playerCount = players,
                    hour = cal.get(Calendar.HOUR_OF_DAY),
                    minute = cal.get(Calendar.MINUTE),
                    customerCode = customerCode,
                    useCurrentTime = true
                )
            }
        }

        // 11. Open popup / detail for system
        if (detectedSystem != null) {
            return VoiceCommandResult.OpenPopup(
                systemId = detectedSystem.first,
                systemName = detectedSystem.second
            )
        }

        return VoiceCommandResult.Unknown(rawInput, "دستور شناسایی نشد. لطفا واضح‌تر بیان کنید.")
    }

    private fun extractCustomerCodeAndStrip(text: String): Pair<String, String> {
        val digitPattern = Regex("""(?:کد\s*مشتری|مشتری\s*کد|کد\s*مشتری)\s*[:؛]?\s*(\d+)""")
        val digitMatch = digitPattern.find(text)
        if (digitMatch != null) {
            val code = digitMatch.groupValues[1]
            val stripped = text.removeRange(digitMatch.range).replace(Regex("""\s+"""), " ").trim()
            return Pair(code, stripped)
        }

        val wordPattern = Regex("""(?:کد\s*مشتری|مشتری\s*کد)\s*[:؛]?\s*([آ-یa-z0-9]+)""")
        val wordMatch = wordPattern.find(text)
        if (wordMatch != null) {
            val rawVal = wordMatch.groupValues[1]
            val numVal = parseSingleWordNumber(rawVal)
            val code = numVal?.toString() ?: rawVal
            val stripped = text.removeRange(wordMatch.range).replace(Regex("""\s+"""), " ").trim()
            return Pair(code, stripped)
        }

        return Pair("", text)
    }

    private fun detectSystem(text: String, systems: List<GameSystemEntity>): Pair<Int, String>? {
        if (text.contains("پی اس فور") || text.contains("ps4") || text.contains("پلی استیشن چهار") ||
            text.contains("پلی استیشن 4") || text.contains("پی اس 4") || text.contains("پی اس چهار")
        ) {
            val num = extractNumberNearKeywords(
                text,
                listOf("پی اس فور", "ps4", "پلی استیشن چهار", "پلی استیشن 4", "پی اس 4", "پی اس چهار"),
                6
            ) ?: extractFirstStandaloneNumber(text, 6) ?: 4
            val matched = systems.firstOrNull {
                it.systemType == "PS4" && (it.id == num || it.code == num.toString() || it.displayName.contains(toPersianDigits(num.toString())))
            }
            return Pair(matched?.id ?: num, matched?.displayName ?: "پی اس فور ${toPersianDigits(num.toString())}")
        }

        if (text.contains("پی اس فایو") || text.contains("پی اس 5") || text.contains("ps5") ||
            text.contains("پلی استیشن پنج") || text.contains("پلی استیشن 5") || text.contains("پی اس پنج")
        ) {
            val num = extractNumberNearKeywords(
                text,
                listOf("پی اس فایو", "پی اس 5", "ps5", "پلی استیشن پنج", "پلی استیشن 5", "پی اس پنج"),
                4
            ) ?: extractFirstStandaloneNumber(text, 4) ?: 1
            val ps5List = systems.filter { it.systemType == "PS5" }
            val matched = ps5List.getOrNull(num - 1) ?: systems.firstOrNull { it.id == 6 + num }
            return Pair(matched?.id ?: (6 + num), matched?.displayName ?: "پی اس فایو ${toPersianDigits(num.toString())}")
        }

        if (text.contains("کامپیوتر") || text.contains("pc") || text.contains("پی سی")) {
            val num = extractNumberNearKeywords(text, listOf("کامپیوتر", "pc", "پی سی"), 10)
                ?: extractFirstStandaloneNumber(text, 10) ?: 1
            val pcList = systems.filter { it.systemType == "PC" }
            val matched = pcList.getOrNull(num - 1) ?: systems.firstOrNull { it.id == 8 + num }
            return Pair(matched?.id ?: (8 + num), matched?.displayName ?: "کامپیوتر ${toPersianDigits(num.toString())}")
        }

        if (text.contains("عینک مجازی") || text.contains("وی ار") || text.contains("وی آر") || text.contains("عینک") || text.contains("vr")) {
            val matched = systems.firstOrNull { it.systemType == "VR" }
            return Pair(matched?.id ?: 13, matched?.displayName ?: "عینک مجازی")
        }

        if (text.contains("فرمان بازی") || text.contains("فرمان") || text.contains("فرمون") || text.contains("wheel")) {
            val matched = systems.firstOrNull { it.systemType == "WHEEL" }
            return Pair(matched?.id ?: 14, matched?.displayName ?: "فرمان بازی")
        }

        if (text.contains("سیستم") || text.contains("دستگاه") || text.contains("کد") || text.contains("ردیف")) {
            val maxSystemId = (systems.maxOfOrNull { it.id } ?: 20).coerceAtLeast(20)
            val num = extractNumberNearKeywords(text, listOf("سیستم", "دستگاه", "کد", "ردیف"), maxSystemId)
                ?: extractFirstStandaloneNumber(text, maxSystemId)
            if (num != null) {
                val matched = systems.firstOrNull { it.id == num || it.code == num.toString() }
                return Pair(matched?.id ?: num, matched?.displayName ?: "سیستم ${toPersianDigits(num.toString())}")
            }
        }

        for (sys in systems) {
            val normName = normalize(sys.displayName)
            if (normName.isNotBlank() && text.contains(normName)) {
                return Pair(sys.id, sys.displayName)
            }
        }

        return null
    }

    private fun extractNumberNearKeywords(text: String, keywords: List<String>, maxNum: Int): Int? {
        for (kw in keywords) {
            if (!text.contains(kw)) continue
            val after = text.substringAfter(kw).trim()
            if (after.isNotBlank()) {
                val tokens = after.split(Regex("""[\s؛،:]+""")).take(3)
                for (tok in tokens) {
                    val digit = tok.toIntOrNull()
                    if (digit != null && digit in 1..maxNum) return digit
                    val wordVal = parseSingleWordNumber(tok)
                    if (wordVal != null && wordVal in 1..maxNum) return wordVal
                }
            }
        }
        return null
    }

    private fun extractFirstStandaloneNumber(text: String, maxNum: Int): Int? {
        val tokens = text.split(Regex("""[\s؛،:]+"""))
        for (tok in tokens) {
            val digit = tok.toIntOrNull()
            if (digit != null && digit in 1..maxNum) return digit
            val wordVal = parseSingleWordNumber(tok)
            if (wordVal != null && wordVal in 1..maxNum) return wordVal
        }
        return null
    }

    private fun parseSingleWordNumber(word: String): Int? {
        val clean = word.trim()
        val map = mapOf(
            "یک" to 1, "یه" to 1, "اول" to 1, "اولین" to 1,
            "دو" to 2, "دوم" to 2, "دومین" to 2,
            "سه" to 3, "سوم" to 3, "سومین" to 3,
            "چهار" to 4, "چهارم" to 4, "چهارمین" to 4,
            "پنج" to 5, "پنجم" to 5, "پنجمین" to 5,
            "شش" to 6, "شیش" to 6, "ششم" to 6, "ششمین" to 6,
            "هفت" to 7, "هفتم" to 7,
            "هشت" to 8, "هشتم" to 8,
            "نه" to 9, "نهم" to 9,
            "ده" to 10, "دهم" to 10,
            "یازده" to 11, "یازدهم" to 11,
            "دوازده" to 12, "دوازدهم" to 12,
            "سیزده" to 13, "سیزدهم" to 13,
            "چهارده" to 14, "چهاردهم" to 14,
            "پانزده" to 15, "پونزده" to 15,
            "شانزده" to 16, "شونزده" to 16,
            "هفده" to 17, "هجده" to 18, "نوزده" to 19,
            "بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50,
            "شصت" to 60, "هفتاد" to 70, "هشتاد" to 80, "نود" to 90,
            "صد" to 100, "یکصد" to 100
        )
        return map[clean]
    }

    private fun extractPlayerCount(text: String): Int {
        val regex = Regex("""(\d+)\s*نفر""")
        val match = regex.find(text)
        if (match != null) {
            return (match.groupValues[1].toIntOrNull() ?: 1).coerceIn(1, 8)
        }
        if (text.contains("تک نفره") || text.contains("یک نفره") || text.contains("یک نفر")) return 1
        if (text.contains("دو نفره") || text.contains("دو نفر")) return 2
        if (text.contains("سه نفره") || text.contains("سه نفر")) return 3
        if (text.contains("چهار نفره") || text.contains("چهار نفر")) return 4
        if (text.contains("پنج نفره") || text.contains("پنج نفر")) return 5
        if (text.contains("شش نفره") || text.contains("شش نفر") || text.contains("شیش نفر")) return 6
        return 1
    }

    private fun extractDurationMinutes(text: String): Int {
        var minutes = 0
        if (text.contains("یک ساعت و نیم") || text.contains("یکساعت و نیم") || text.contains("یک و نیم ساعت")) {
            return 90
        }
        if (text.contains("دو ساعت و نیم") || text.contains("دو و نیم ساعت")) {
            return 150
        }
        if (text.contains("نیم ساعت") || text.contains("سی دقیقه")) {
            minutes += 30
        } else if (text.contains("سه ربع")) {
            minutes += 45
        } else if (text.contains("یه ربع") || text.contains("یک ربع")) {
            minutes += 15
        }

        val hourDigitRegex = Regex("""(\d+)\s*ساعت""")
        val hourDigitMatch = hourDigitRegex.find(text)
        if (hourDigitMatch != null) {
            minutes += (hourDigitMatch.groupValues[1].toIntOrNull() ?: 1) * 60
        } else if (text.contains("یک ساعت") || text.contains("یکساعت") || text.contains("یه ساعت")) {
            minutes += 60
        } else if (text.contains("دو ساعت")) {
            minutes += 120
        } else if (text.contains("سه ساعت")) {
            minutes += 180
        } else if (text.contains("چهار ساعت")) {
            minutes += 240
        } else if (text.contains("پنج ساعت")) {
            minutes += 300
        }

        val minRegex = Regex("""(\d+)\s*دقیقه""")
        val minMatch = minRegex.find(text)
        if (minMatch != null) {
            minutes += minMatch.groupValues[1].toIntOrNull() ?: 0
        }

        if (minutes == 0) {
            when {
                text.contains("شصت دقیقه") -> minutes = 60
                text.contains("نود دقیقه") -> minutes = 90
                text.contains("چهل و پنج دقیقه") -> minutes = 45
                text.contains("چهل دقیقه") -> minutes = 40
                text.contains("بیست و پنج دقیقه") -> minutes = 25
                text.contains("بیست دقیقه") -> minutes = 20
                text.contains("پانزده دقیقه") || text.contains("پونزده دقیقه") -> minutes = 15
                text.contains("ده دقیقه") -> minutes = 10
            }
        }

        return if (minutes > 0) minutes else 60
    }

    private fun stripSystemPrefixForAmount(text: String): String {
        return text
            .replace(Regex("""(?:کد|سیستم|دستگاه|ردیف)\s*[:؛]?\s*\d+"""), " ")
            .replace(Regex("""(?:پی\s*اس\s*فور|پلی\s*استیشن|پی\s*اس\s*فایو|پی\s*اس|کامپیوتر|ps4|ps5|pc)\s*\d+"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun extractAmountTomans(text: String): Long {
        val afterMablaghRegex = Regex("""مبلغ\s*[:؛]?\s*(\d+)\s*(هزار|میلیون)?""")
        val mablaghMatch = afterMablaghRegex.find(text)
        if (mablaghMatch != null) {
            val num = mablaghMatch.groupValues[1].toLongOrNull() ?: 0L
            val unit = mablaghMatch.groupValues[2]
            if (unit == "میلیون") return num * 1_000_000L
            if (unit == "هزار" || (text.contains("هزار") && num < 10000)) return num * 1000L
            if (num >= 1000) return num
            if (num > 0) return num * 1000L
        }

        val regexDirect = Regex("""(\d+)\s*(هزار|میلیون)?\s*(تومان|تومن)?""")
        for (match in regexDirect.findAll(text)) {
            val num = match.groupValues[1].toLongOrNull() ?: 0L
            val unit = match.groupValues[2]
            val currency = match.groupValues[3]
            if (unit == "میلیون") return num * 1_000_000L
            if (unit == "هزار" || (currency.isNotBlank() && num in 1..999)) {
                return num * 1000L
            }
            if (num >= 1000) return num
        }

        return when {
            text.contains("یک میلیون") || text.contains("یه میلیون") -> 1_000_000L
            text.contains("پانصد هزار") || text.contains("پونصد هزار") -> 500_000L
            text.contains("چهارصد هزار") -> 400_000L
            text.contains("سیصد هزار") -> 300_000L
            text.contains("دویست هزار") -> 200_000L
            text.contains("صد و پنجاه هزار") -> 150_000L
            text.contains("صد و بیست هزار") -> 120_000L
            text.contains("صد هزار") || text.contains("یکصد هزار") -> 100_000L
            text.contains("نود هزار") -> 90_000L
            text.contains("هشتاد هزار") -> 80_000L
            text.contains("هفتاد هزار") -> 70_000L
            text.contains("شصت هزار") -> 60_000L
            text.contains("پنجاه هزار") -> 50_000L
            text.contains("چهل هزار") -> 40_000L
            text.contains("سی و پنج هزار") -> 35_000L
            text.contains("سی هزار") -> 30_000L
            text.contains("بیست و پنج هزار") -> 25_000L
            text.contains("بیست هزار") -> 20_000L
            text.contains("پانزده هزار") || text.contains("پونزده هزار") -> 15_000L
            text.contains("ده هزار") -> 10_000L
            else -> 0L
        }
    }

    private fun parseDebt(text: String): VoiceCommandResult? {
        val amount = extractAmountTomans(text)
        if (amount <= 0) return null

        var cleaned = text
            .replace("بدهی", "")
            .replace("نسیه", "")
            .replace("حساب دفتری", "")
            .replace("تومان", "")
            .replace("تومن", "")
            .replace("هزار", "")
            .replace("میلیون", "")
            .replace("پانصد", "")
            .replace("پونصد", "")
            .replace("چهارصد", "")
            .replace("سیصد", "")
            .replace("دویست", "")
            .replace("صد", "")
            .replace("پنجاه", "")
            .replace("چهل", "")
            .replace("سی", "")
            .replace("بیست", "")
            .replace("ده", "")
            .replace(Regex("""\d+"""), "")
            .trim()

        if (cleaned.isBlank()) cleaned = "مشتری"

        return VoiceCommandResult.RegisterDebt(
            customerName = cleaned,
            amountTomans = amount
        )
    }

    private fun parseSnack(text: String, system: Pair<Int, String>): VoiceCommandResult? {
        val snacks = listOf("آبمیوه", "کیک", "نوشابه", "ریدبول", "هایپ", "چیپس", "پفک", "چای", "اسپرسو", "آب معدنی")
        for (snack in snacks) {
            if (text.contains(snack)) {
                var count = 1
                val digitMatch = Regex("""(\d+)\s*(عدد|تا)""").find(text)
                if (digitMatch != null) {
                    count = (digitMatch.groupValues[1].toIntOrNull() ?: 1).coerceIn(1, 20)
                } else if (text.contains("دو عدد") || text.contains("دو تا")) count = 2
                else if (text.contains("سه عدد") || text.contains("سه تا")) count = 3
                else if (text.contains("چهار عدد") || text.contains("چهار تا")) count = 4
                return VoiceCommandResult.AddSnack(
                    systemId = system.first,
                    systemName = system.second,
                    snackName = snack,
                    count = count
                )
            }
        }
        return null
    }

    private fun parseTime(text: String, anchor: String): Pair<Int, Int>? {
        val sub = text.substringAfter(anchor).trim()
        val hourMap = mapOf(
            "بیست و سه" to 23, "بیست و دو" to 22, "بیست و یک" to 21, "بیست" to 20,
            "نوزده" to 19, "هجده" to 18, "هفده" to 17, "شانزده" to 16, "پانزده" to 15,
            "چهارده" to 14, "سیزده" to 13, "دوازده" to 12, "یازده" to 11, "ده" to 10,
            "نه" to 9, "هشت" to 8, "هفت" to 7, "شش" to 6, "شیش" to 6, "پنج" to 5, "چهار" to 4, "سه" to 3, "دو" to 2, "یک" to 1
        )

        var hour = 12
        for ((word, h) in hourMap) {
            if (sub.startsWith(word) || sub.contains("ساعت $word") || sub.contains(word)) {
                hour = h
                break
            }
        }

        var minute = 0
        if (sub.contains("نیم")) minute = 30
        else if (sub.contains("بیست دقیقه")) minute = 20
        else if (sub.contains("ده دقیقه")) minute = 10
        else if (sub.contains("پانزده دقیقه") || sub.contains("یک ربع")) minute = 15
        else if (sub.contains("چهل و پنج دقیقه")) minute = 45

        val timeRegex = Regex("""(\d{1,2})[:\s]+(\d{1,2})""")
        val match = timeRegex.find(sub)
        if (match != null) {
            hour = match.groupValues[1].toIntOrNull() ?: hour
            minute = match.groupValues[2].toIntOrNull() ?: minute
        }

        return Pair(hour, minute)
    }

    private fun similarityScore(a: String, b: String): Double {
        if (a == b) return 1.0
        val maxLen = max(a.length, b.length)
        if (maxLen == 0) return 1.0
        val dist = levenshtein(a, b)
        return 1.0 - (dist.toDouble() / maxLen.toDouble())
    }

    private fun levenshtein(a: String, b: String): Int {
        val m = a.length
        val n = b.length
        val dp = IntArray(n + 1) { it }
        for (i in 1..m) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..n) {
                val temp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = min(min(dp[j] + 1, dp[j - 1] + 1), prev + cost)
                prev = temp
            }
        }
        return dp[n]
    }

    private fun toPersianDigits(input: String): String {
        return input
            .replace('0', '۰')
            .replace('1', '۱')
            .replace('2', '۲')
            .replace('3', '۳')
            .replace('4', '۴')
            .replace('5', '۵')
            .replace('6', '۶')
            .replace('7', '۷')
            .replace('8', '۸')
            .replace('9', '۹')
    }

    fun normalize(input: String): String {
        return input
            .replace('ي', 'ی')
            .replace('ى', 'ی')
            .replace('ك', 'ک')
            .replace('ة', 'ه')
            .replace('ۀ', 'ه')
            .replace('ؤ', 'و')
            .replace('إ', 'ا')
            .replace('أ', 'ا')
            .replace('\u200C', ' ')
            .replace('۰', '0')
            .replace('۱', '1')
            .replace('۲', '2')
            .replace('۳', '3')
            .replace('۴', '4')
            .replace('۵', '5')
            .replace('۶', '6')
            .replace('۷', '7')
            .replace('۸', '8')
            .replace('۹', '9')
            .replace('٠', '0')
            .replace('١', '1')
            .replace('٢', '2')
            .replace('٣', '3')
            .replace('٤', '4')
            .replace('٥', '5')
            .replace('٦', '6')
            .replace('٧', '7')
            .replace('٨', '8')
            .replace('٩', '9')
            .lowercase()
    }
}
