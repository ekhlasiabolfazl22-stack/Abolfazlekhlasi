package com.example.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.*
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.math.sqrt

enum class VoiceEngineMode(val label: String) {
    HYBRID("هوشمند (آنلاین + آفلاین)"),
    OFFLINE("آفلاین (بدون اینترنت)"),
    ONLINE("فقط آنلاین")
}

class OfflineVoskSpeechManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var model: Model? = null
    private var isInitializing = false
    private var listeningJob: Job? = null

    @Volatile
    private var stopRequested = false

    @Volatile
    private var lastInitError: String? = null

    companion object {
        private const val TAG = "OfflineVoskSpeech"
        private const val ASSET_ZIP_NAME = "vosk-fa-model.zip"
        private const val MODEL_DOWNLOAD_URL = "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip"
        private const val MODEL_DIR_NAME = "vosk_fa_model_v042"
        private const val READY_MARKER = ".ready"
        private const val SAMPLE_RATE = 16000
    }

    fun isModelReady(): Boolean {
        val targetDir = File(context.filesDir, MODEL_DIR_NAME)
        return File(targetDir, READY_MARKER).exists()
    }

    fun warmupAsync(onReady: (Boolean) -> Unit = {}) {
        scope.launch {
            // Only unpack automatically on startup if already downloaded or bundled in assets
            val loaded = if (isModelReady() || hasBundledAsset()) {
                ensureModelLoaded(onStatus = {})
            } else {
                null
            }
            withContext(Dispatchers.Main) {
                onReady(loaded != null)
            }
        }
    }

    private fun hasBundledAsset(): Boolean {
        return try {
            context.assets.open(ASSET_ZIP_NAME).use { true }
        } catch (_: Exception) {
            false
        }
    }

    @Synchronized
    private fun ensureModelLoaded(onStatus: (String) -> Unit = {}): Model? {
        if (model != null) return model
        if (isInitializing) {
            while (isInitializing) {
                try {
                    Thread.sleep(50)
                } catch (_: InterruptedException) {
                    break
                }
            }
            return model
        }
        isInitializing = true
        lastInitError = null
        return try {
            val targetDir = File(context.filesDir, MODEL_DIR_NAME)
            val marker = File(targetDir, READY_MARKER)
            if (!marker.exists()) {
                if (targetDir.exists()) targetDir.deleteRecursively()
                targetDir.mkdirs()

                if (hasBundledAsset()) {
                    onStatus("در حال استخراج مدل آفلاین فارسی...")
                    context.assets.open(ASSET_ZIP_NAME).use { rawStream ->
                        unzipModelStream(rawStream, targetDir)
                    }
                } else {
                    val tempZip = File(context.cacheDir, "vosk_fa_model_tmp.zip")
                    try {
                        onStatus("در حال دانلود یک‌باره مدل صوتی آفلاین فارسی...")
                        downloadModelZip(MODEL_DOWNLOAD_URL, tempZip) { pct ->
                            onStatus("در حال دانلود یک‌باره مدل آفلاین فارسی ($pct%)...")
                        }
                        onStatus("در حال آماده‌سازی مدل آفلاین فارسی...")
                        FileInputStream(tempZip).use { fis ->
                            unzipModelStream(fis, targetDir)
                        }
                    } finally {
                        if (tempZip.exists()) tempZip.delete()
                    }
                }
                marker.createNewFile()
            }
            val loaded = Model(targetDir.absolutePath)
            model = loaded
            loaded
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to unpack/download/load Vosk Persian model", t)
            lastInitError = "برای دانلود یک‌باره مدل صوتی آفلاین فارسی به اینترنت متصل شوید یا از حالت آنلاین استفاده کنید."
            null
        } finally {
            isInitializing = false
        }
    }

    private fun unzipModelStream(rawStream: InputStream, targetDir: File) {
        ZipInputStream(BufferedInputStream(rawStream)).use { zis ->
            val buffer = ByteArray(16 * 1024)
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath + File.separator)) {
                    entry = zis.nextEntry
                    continue
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos ->
                        var len: Int
                        while (zis.read(buffer).also { len = it } > 0) {
                            fos.write(buffer, 0, len)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    private fun downloadModelZip(urlStr: String, destFile: File, onPercent: (Int) -> Unit) {
        var currentUrl = urlStr
        var redirects = 0
        var conn: HttpURLConnection? = null
        while (redirects < 5) {
            val url = URL(currentUrl)
            val c = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = true
            }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw IllegalStateException("Empty redirect URL")
                currentUrl = loc
                redirects++
                continue
            }
            conn = c
            break
        }
        val activeConn = conn ?: throw IllegalStateException("Too many redirects")
        try {
            if (activeConn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${activeConn.responseCode}")
            }
            val totalBytes = activeConn.contentLengthLong
            var downloaded = 0L
            var lastPct = -1
            BufferedInputStream(activeConn.inputStream).use { input ->
                FileOutputStream(destFile).use { output ->
                    val buf = ByteArray(16 * 1024)
                    var read: Int
                    while (input.read(buf).also { read = it } != -1) {
                        output.write(buf, 0, read)
                        downloaded += read
                        if (totalBytes > 0) {
                            val pct = ((downloaded * 100L) / totalBytes).toInt().coerceIn(0, 100)
                            if (pct != lastPct) {
                                lastPct = pct
                                onPercent(pct)
                            }
                        }
                    }
                }
            }
        } finally {
            activeConn.disconnect()
        }
    }

    @SuppressLint("MissingPermission")
    fun startListening(
        onListeningChanged: (Boolean) -> Unit,
        onPartial: (String) -> Unit,
        onFinalResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        stopListening()
        stopRequested = false

        listeningJob = scope.launch {
            withContext(Dispatchers.Main) {
                onPartial("در حال آماده‌سازی موتور آفلاین فارسی...")
            }

            val loadedModel = ensureModelLoaded { status ->
                scope.launch(Dispatchers.Main) {
                    onPartial(status)
                }
            }
            if (loadedModel == null) {
                withContext(Dispatchers.Main) {
                    onListeningChanged(false)
                    onError(lastInitError ?: "مدل صوتی آفلاین در حافظه بارگذاری نشد.")
                }
                return@launch
            }

            var audioRecord: AudioRecord? = null
            var recognizer: Recognizer? = null
            try {
                val minBuf = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(4096)

                audioRecord = createBestAudioRecord(minBuf * 2)
                if (audioRecord == null || audioRecord.state != AudioRecord.STATE_INITIALIZED) {
                    withContext(Dispatchers.Main) {
                        onListeningChanged(false)
                        onError("دسترسی به میکروفون برای موتور آفلاین برقرار نشد.")
                    }
                    return@launch
                }

                recognizer = Recognizer(loadedModel, SAMPLE_RATE.toFloat())
                val buffer = ShortArray(2048)

                audioRecord.startRecording()
                withContext(Dispatchers.Main) {
                    onListeningChanged(true)
                    onPartial("")
                }

                val startTime = System.currentTimeMillis()
                var lastVoiceTime = startTime
                var heardSpeech = false
                var finalEmittedText = ""

                while (isActive && !stopRequested) {
                    val read = audioRecord.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        val rms = computeRms(buffer, read)
                        val now = System.currentTimeMillis()
                        if (rms > 320.0) {
                            lastVoiceTime = now
                            heardSpeech = true
                        }

                        val isFinalChunk = recognizer.acceptWaveForm(buffer, read)
                        if (isFinalChunk) {
                            val txt = extractText(recognizer.result, "text")
                            if (txt.isNotBlank()) {
                                finalEmittedText = if (finalEmittedText.isBlank()) txt else "$finalEmittedText $txt"
                                withContext(Dispatchers.Main) {
                                    onPartial(finalEmittedText)
                                }
                                // End quickly once a complete utterance is recognized
                                if (now - lastVoiceTime > 900L) break
                            }
                        } else {
                            val partial = extractText(recognizer.partialResult, "partial")
                            if (partial.isNotBlank()) {
                                heardSpeech = true
                                lastVoiceTime = now
                                val display = if (finalEmittedText.isBlank()) partial else "$finalEmittedText $partial"
                                withContext(Dispatchers.Main) {
                                    onPartial(display)
                                }
                            }
                        }

                        // Auto-stop after 1.6s of silence following detected speech, or 12s max
                        if (heardSpeech && (now - lastVoiceTime > 1600L)) break
                        if (!heardSpeech && (now - startTime > 7500L)) break
                        if (now - startTime > 14000L) break
                    } else if (read < 0) {
                        break
                    }
                }

                val tail = extractText(recognizer.finalResult, "text")
                val combined = listOf(finalEmittedText, tail)
                    .filter { it.isNotBlank() }
                    .joinToString(" ")
                    .trim()

                withContext(Dispatchers.Main) {
                    onListeningChanged(false)
                    if (combined.isNotBlank()) {
                        onFinalResult(combined)
                    } else if (!stopRequested) {
                        onError("صدایی در حالت آفلاین تشخیص داده نشد. واضح‌تر نزدیک میکروفون صحبت کنید.")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Offline Vosk listening error", e)
                withContext(Dispatchers.Main) {
                    onListeningChanged(false)
                    onError("خطا در موتور صوتی آفلاین: ${e.message ?: "نامشخص"}")
                }
            } finally {
                try {
                    audioRecord?.stop()
                } catch (_: Exception) {}
                try {
                    audioRecord?.release()
                } catch (_: Exception) {}
                try {
                    recognizer?.close()
                } catch (_: Exception) {}
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun createBestAudioRecord(bufferSize: Int): AudioRecord? {
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC
        )
        for (src in sources) {
            try {
                val rec = AudioRecord(
                    src,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
                if (rec.state == AudioRecord.STATE_INITIALIZED) return rec
                rec.release()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun computeRms(buf: ShortArray, len: Int): Double {
        var sum = 0.0
        for (i in 0 until len) {
            val s = buf[i].toDouble()
            sum += s * s
        }
        return if (len > 0) sqrt(sum / len) else 0.0
    }

    private fun extractText(jsonStr: String, key: String): String {
        return try {
            JSONObject(jsonStr).optString(key, "").trim()
        } catch (_: Exception) {
            ""
        }
    }

    fun stopListening() {
        stopRequested = true
        listeningJob?.cancel()
        listeningJob = null
    }

    fun release() {
        stopListening()
        scope.cancel()
        try {
            model?.close()
        } catch (_: Exception) {}
        model = null
    }
}
