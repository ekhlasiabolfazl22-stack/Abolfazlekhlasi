package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.service.GameNetForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CrystalGameNetApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getDatabase(this)
        CoroutineScope(Dispatchers.IO).launch {
            // Check if default systems exist, if not populate
            val systems = db.gameNetDao().getAllSystems()
            val existing = db.gameNetDao().getSystemById(1)
            if (existing == null) {
                AppDatabase.populateInitialData(db.gameNetDao())
            }
        }

        // Start background persistence service
        GameNetForegroundService.start(this)
    }
}
