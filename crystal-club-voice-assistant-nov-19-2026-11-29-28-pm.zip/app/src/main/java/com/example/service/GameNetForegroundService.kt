package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.AlarmAndTtsManager
import com.example.data.local.AppDatabase
import com.example.data.repository.GameNetRepository
import kotlinx.coroutines.*

class GameNetForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var alarmManager: AlarmAndTtsManager
    private lateinit var repository: GameNetRepository

    private val notifiedExpiringSystems = mutableSetOf<Int>()

    companion object {
        const val CHANNEL_ID = "gamenet_monitor_channel"
        const val ALARM_CHANNEL_ID = "gamenet_alarm_channel"
        const val NOTIFICATION_ID = 1001
        const val ALARM_NOTIFICATION_ID = 1002

        const val ACTION_START_SERVICE = "com.example.service.START"
        const val ACTION_STOP_ALARM = "com.example.service.STOP_ALARM"
        const val ACTION_EXTEND_15M = "com.example.service.EXTEND_15M"
        const val ACTION_CLOSE_APP = "com.example.service.CLOSE_APP"

        const val EXTRA_SYSTEM_ID = "extra_system_id"

        var isServiceRunning = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, GameNetForegroundService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopAlarm(context: Context) {
            val intent = Intent(context, GameNetForegroundService::class.java).apply {
                action = ACTION_STOP_ALARM
            }
            try {
                context.startService(intent)
            } catch (ignored: Exception) {}
        }

        fun closeAppCleanly(context: Context) {
            val intent = Intent(context, GameNetForegroundService::class.java).apply {
                action = ACTION_CLOSE_APP
            }
            try {
                context.startService(intent)
            } catch (ignored: Exception) {}
        }
    }

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        alarmManager = AlarmAndTtsManager(this)
        val db = AppDatabase.getDatabase(this)
        repository = GameNetRepository(db.gameNetDao())

        acquireWakeLock()
        createNotificationChannels()
        startForegroundSafe("مدیریت گیم‌نت در حال پایش فعال است")

        startMonitoringSessions()
    }

    private fun startForegroundSafe(contentText: String) {
        val notification = buildForegroundNotification(contentText)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (ignored: Exception) {}
        }
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "CafeManagement::CpuWakeLock"
            ).apply {
                acquire(12 * 60 * 60 * 1000L)
            }
        } catch (ignored: Exception) {}
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
            wakeLock = null
        } catch (ignored: Exception) {}
    }

    private fun wakeScreenBriefly() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            @Suppress("DEPRECATION")
            val screenLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "CafeManagement::ScreenWakeLock"
            )
            screenLock.acquire(5000L)
        } catch (ignored: Exception) {}
    }

    private fun startMonitoringSessions() {
        serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                val now = System.currentTimeMillis()
                val db = AppDatabase.getDatabase(this@GameNetForegroundService)
                val allActive = db.gameNetDao().getActiveSessionsList()

                var hasAlarming = false
                val activeSummary = "${allActive.size} سیستم در حال بازی"

                for (session in allActive) {
                    if (session.isCountDown && !session.isPaused && session.expectedEndTimeMillis in 1..now) {
                        if (!session.isAlarmDismissed) {
                            hasAlarming = true
                            if (!notifiedExpiringSystems.contains(session.systemId)) {
                                notifiedExpiringSystems.add(session.systemId)
                                withContext(Dispatchers.Main) {
                                    wakeScreenBriefly()
                                    alarmManager.triggerTimeEndedAlarm(session.systemDisplayName)
                                    showAlarmNotification(session.systemId, session.systemDisplayName)
                                }
                            }
                        }
                    } else {
                        notifiedExpiringSystems.remove(session.systemId)
                    }
                }

                if (!hasAlarming && alarmManager.isAlarmPlaying()) {
                    withContext(Dispatchers.Main) {
                        alarmManager.stopAlarm()
                    }
                }

                withContext(Dispatchers.Main) {
                    updateNotification(activeSummary)
                }

                delay(1000)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> {
                alarmManager.stopAlarm()
                dismissAlarmNotification()
                serviceScope.launch(Dispatchers.IO) {
                    val db = AppDatabase.getDatabase(this@GameNetForegroundService)
                    val active = db.gameNetDao().getActiveSessionsList()
                    val now = System.currentTimeMillis()
                    for (s in active) {
                        if (s.isCountDown && s.expectedEndTimeMillis <= now) {
                            db.gameNetDao().updateSession(s.copy(isAlarmDismissed = true))
                        }
                    }
                }
            }
            ACTION_EXTEND_15M -> {
                val sysId = intent.getIntExtra(EXTRA_SYSTEM_ID, -1)
                if (sysId != -1) {
                    serviceScope.launch(Dispatchers.IO) {
                        repository.modifySessionTimer(sysId, 15)
                        notifiedExpiringSystems.remove(sysId)
                    }
                }
                alarmManager.stopAlarm()
                dismissAlarmNotification()
            }
            ACTION_CLOSE_APP -> {
                cleanupAndStop()
                val exitIntent = Intent("com.example.ACTION_FORCE_EXIT").apply {
                    setPackage(packageName)
                }
                sendBroadcast(exitIntent)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            val persistentChannel = NotificationChannel(
                CHANNEL_ID,
                "مدیریت گیم‌نت - وضعیت سیستم‌ها",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "پایش دائمی تایمرهای بازی در پس‌زمینه"
            }

            val alarmChannel = NotificationChannel(
                ALARM_CHANNEL_ID,
                "هشدار پایان زمان بازی",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "آلارم صوتی و لرزشی اتمام وقت سیستم"
                enableVibration(true)
                setBypassDnd(true)
            }

            nm.createNotificationChannel(persistentChannel)
            nm.createNotificationChannel(alarmChannel)
        }
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val appIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            appIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val exitIntent = Intent(this, GameNetForegroundService::class.java).apply {
            action = ACTION_CLOSE_APP
        }
        val exitPendingIntent = PendingIntent.getService(
            this,
            1,
            exitIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("مدیریت گیم‌نت (فعال و در حال کار)")
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "خروج و بستن کامل", exitPendingIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildForegroundNotification(text))
    }

    private fun showAlarmNotification(systemId: Int, systemName: String) {
        val appIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra("open_system_id", systemId)
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            systemId,
            appIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, GameNetForegroundService::class.java).apply {
            action = ACTION_STOP_ALARM
        }
        val stopPending = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val extendIntent = Intent(this, GameNetForegroundService::class.java).apply {
            action = ACTION_EXTEND_15M
            putExtra(EXTRA_SYSTEM_ID, systemId)
        }
        val extendPending = PendingIntent.getService(
            this,
            3,
            extendIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, ALARM_CHANNEL_ID)
            .setContentTitle("⏰ پایان زمان: $systemName")
            .setContentText("زمان بازی این سیستم به اتمام رسیده است!")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pendingIntent, true)
            .setAutoCancel(true)
            .addAction(0, "قطع آلارم", stopPending)
            .addAction(0, "+۱۵ دقیقه تمدید", extendPending)
            .build()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(ALARM_NOTIFICATION_ID, notification)
    }

    private fun dismissAlarmNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(ALARM_NOTIFICATION_ID)
    }

    private fun cleanupAndStop() {
        isServiceRunning = false
        alarmManager.release()
        serviceScope.cancel()
        releaseWakeLock()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancelAll()
    }

    override fun onDestroy() {
        cleanupAndStop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
