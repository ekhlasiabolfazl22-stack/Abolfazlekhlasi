package com.example

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.GameNetViewModel
import com.example.viewmodel.NavTab
import com.example.voice.OfflineVoskSpeechManager
import com.example.voice.VoiceEngineMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class VoiceInputTarget {
    SYSTEM_COMMAND,
    RECEIPT_CUSTOMER,
    DEBTS_SEARCH,
    CUSTOMERS_SEARCH_DIR,
    CUSTOMERS_SEARCH_DEBT_SMS,
    CUSTOMERS_SEARCH_DISCOUNT,
    CUSTOMERS_SEARCH_DISC_SMS
}

class MainActivity : ComponentActivity() {

    private val viewModel: GameNetViewModel by viewModels()
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var offlineVoskManager: OfflineVoskSpeechManager

    private val _activeEngineBadge = MutableStateFlow("")
    private val activeEngineBadgeFlow = _activeEngineBadge.asStateFlow()

    private val _receiptCustomerVoiceHint = MutableStateFlow("")
    private val receiptCustomerVoiceHintFlow = _receiptCustomerVoiceHint.asStateFlow()

    private val _scopedVoiceSearchHint = MutableStateFlow<Pair<VoiceInputTarget, String>?>(null)
    private val scopedVoiceSearchHintFlow = _scopedVoiceSearchHint.asStateFlow()

    private val _voiceCommandAutoCloseSeq = MutableStateFlow(0L)
    private val voiceCommandAutoCloseSeqFlow = _voiceCommandAutoCloseSeq.asStateFlow()

    private var activeVoiceTarget: VoiceInputTarget = VoiceInputTarget.SYSTEM_COMMAND
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    companion object {
        private const val REQ_MIC_PERMISSION = 1001
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        @Suppress("DEPRECATION")
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC_PERMISSION) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted) {
                beginSpeechRecognitionInternal()
            } else {
                Toast.makeText(this, "لطفاً مجوز میکروفون را برای فرمان صوتی تایید کنید", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val forceExitReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finishAffinity()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        offlineVoskManager = OfflineVoskSpeechManager(applicationContext)
        offlineVoskManager.warmupAsync()

        val filter = IntentFilter("com.example.ACTION_FORCE_EXIT")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(forceExitReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(forceExitReceiver, filter)
        }

        handleIncomingIntent(intent)

        setContent {
            CrystalGameClubTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val activeBadge by activeEngineBadgeFlow.collectAsStateWithLifecycle()
                    val receiptHint by receiptCustomerVoiceHintFlow.collectAsStateWithLifecycle()
                    val scopedSearchHint by scopedVoiceSearchHintFlow.collectAsStateWithLifecycle()
                    val autoCloseSeq by voiceCommandAutoCloseSeqFlow.collectAsStateWithLifecycle()
                    MainAppContent(
                        viewModel = viewModel,
                        activeEngineBadge = activeBadge,
                        receiptVoiceHint = receiptHint,
                        scopedSearchHint = scopedSearchHint,
                        voiceAutoCloseSeq = autoCloseSeq,
                        onClearReceiptVoiceHint = { _receiptCustomerVoiceHint.value = "" },
                        onClearScopedSearchHint = { _scopedVoiceSearchHint.value = null },
                        onStartListening = { startSpeechListening(VoiceInputTarget.SYSTEM_COMMAND) },
                        onStartReceiptCustomerVoice = { startSpeechListening(VoiceInputTarget.RECEIPT_CUSTOMER) },
                        onStartTargetedVoice = { target -> startSpeechListening(target) },
                        onStopListening = { stopSpeechListening() }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val systemId = intent?.getIntExtra("open_system_id", -1) ?: -1
        if (systemId != -1) {
            val sys = viewModel.systems.value.firstOrNull { it.id == systemId }
            if (sys != null) {
                viewModel.openSystemPopup(sys)
            }
        }
    }

    private fun isNetworkConnected(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) {
            false
        }
    }

    private fun requestMicAudioFocus() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(attrs)
                    .build()
                audioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            }
        } catch (_: Exception) {}
    }

    private fun abandonMicAudioFocus() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {}
    }

    private fun createFreshOnlineRecognizer(): SpeechRecognizer? {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return null
        return SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    viewModel.setVoiceListening(true)
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    viewModel.setVoiceListening(false)
                }

                override fun onError(error: Int) {
                    viewModel.setVoiceListening(false)
                    abandonMicAudioFocus()
                    val mode = viewModel.voiceEngineMode.value

                    val isRecoverableNetworkOrBusyError = error == SpeechRecognizer.ERROR_NETWORK ||
                        error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_SERVER ||
                        error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                        error == SpeechRecognizer.ERROR_CLIENT ||
                        error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED ||
                        error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE

                    // Reset broken recognizer instance so subsequent taps work cleanly
                    destroyOnlineRecognizer()

                    if (mode == VoiceEngineMode.HYBRID && isRecoverableNetworkOrBusyError) {
                        _activeEngineBadge.value = "تبدیل خودکار به موتور آفلاین فارسی..."
                        startOfflineVoskListening()
                        return
                    }

                    val errorMsg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "صدایی با مفهوم دستور تشخیص داده نشد. مجدداً تلاش کنید"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "تایم گفتار پایان یافت"
                        SpeechRecognizer.ERROR_AUDIO -> "خطای ضبط صدا از میکروفون"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "اینترنت متصل نیست. موتور را روی «هوشمند» یا «آفلاین» قرار دهید"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "میکروفون مشغول بود و ریست شد؛ دوباره لمس کنید"
                        else -> "متوجه گفتار نشدم. مجدداً تلاش کنید"
                    }
                    viewModel.setVoiceTranscript(errorMsg)
                }

                override fun onResults(results: Bundle?) {
                    viewModel.setVoiceListening(false)
                    abandonMicAudioFocus()
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        dispatchRecognizedSpeech(matches)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partials = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!partials.isNullOrEmpty() && activeVoiceTarget == VoiceInputTarget.SYSTEM_COMMAND) {
                        viewModel.setVoiceTranscript(partials[0])
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun dispatchRecognizedSpeech(matches: List<String>) {
        val text = matches.firstOrNull().orEmpty().trim()
        val target = activeVoiceTarget
        activeVoiceTarget = VoiceInputTarget.SYSTEM_COMMAND

        when (target) {
            VoiceInputTarget.SYSTEM_COMMAND -> {
                if (matches.size == 1) {
                    viewModel.executeVoiceCommand(text)
                } else {
                    viewModel.executeVoiceCandidates(matches)
                }
                _voiceCommandAutoCloseSeq.value += 1L
            }
            VoiceInputTarget.RECEIPT_CUSTOMER -> {
                _receiptCustomerVoiceHint.value = text
            }
            else -> {
                _scopedVoiceSearchHint.value = target to text
            }
        }
    }

    private fun destroyOnlineRecognizer() {
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {}
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
    }

    private fun startSpeechListening(target: VoiceInputTarget = VoiceInputTarget.SYSTEM_COMMAND) {
        activeVoiceTarget = target
        val hasAudio = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasAudio) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQ_MIC_PERMISSION
            )
            return
        }
        beginSpeechRecognitionInternal()
    }

    private fun beginSpeechRecognitionInternal() {
        // Stop any TTS playback and active recognizers before opening the mic
        viewModel.stopAudioBeforeListening()
        offlineVoskManager.stopListening()
        destroyOnlineRecognizer()
        requestMicAudioFocus()

        val mode = viewModel.voiceEngineMode.value
        val onlineAvailable = isNetworkConnected() && SpeechRecognizer.isRecognitionAvailable(this)

        when (mode) {
            VoiceEngineMode.OFFLINE -> {
                _activeEngineBadge.value = "موتور آفلاین فارسی (فعال)"
                startOfflineVoskListening()
            }
            VoiceEngineMode.ONLINE -> {
                if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                    abandonMicAudioFocus()
                    viewModel.setVoiceTranscript("سرویس تشخیص صوت آنلاین روی این گوشی در دسترس نیست. حالت آفلاین را انتخاب کنید.")
                    return
                }
                _activeEngineBadge.value = "موتور آنلاین گوگل"
                startOnlineRecognizerListening()
            }
            VoiceEngineMode.HYBRID -> {
                if (onlineAvailable) {
                    _activeEngineBadge.value = "آنلاین گوگل (پشتیبان آفلاین آماده)"
                    startOnlineRecognizerListening()
                } else {
                    _activeEngineBadge.value = "موتور آفلاین فارسی (بدون اینترنت)"
                    startOfflineVoskListening()
                }
            }
        }
    }

    private fun startOnlineRecognizerListening() {
        try {
            speechRecognizer = createFreshOnlineRecognizer()
            if (speechRecognizer == null) {
                if (viewModel.voiceEngineMode.value == VoiceEngineMode.HYBRID) {
                    _activeEngineBadge.value = "موتور آفلاین فارسی (خودکار)"
                    startOfflineVoskListening()
                } else {
                    abandonMicAudioFocus()
                    viewModel.setVoiceTranscript("سرویس صوت آنلاین در دسترس نیست")
                }
                return
            }

            val promptText = if (activeVoiceTarget == VoiceInputTarget.SYSTEM_COMMAND) {
                "فرمان صوتی مدیریت گیم‌نت را بگویید..."
            } else {
                "نام یا کد مشتری را بگویید..."
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa")
                putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("fa-IR", "fa"))
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_PROMPT, promptText)
            }
            speechRecognizer?.startListening(intent)
            viewModel.setVoiceListening(true)
        } catch (_: Exception) {
            destroyOnlineRecognizer()
            if (viewModel.voiceEngineMode.value == VoiceEngineMode.HYBRID) {
                _activeEngineBadge.value = "موتور آفلاین فارسی (خودکار)"
                startOfflineVoskListening()
            } else {
                abandonMicAudioFocus()
                Toast.makeText(this, "امکان شروع ضبط صوتی وجود ندارد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startOfflineVoskListening() {
        offlineVoskManager.startListening(
            onListeningChanged = { listening ->
                if (!listening) abandonMicAudioFocus()
                viewModel.setVoiceListening(listening)
            },
            onPartial = { partial ->
                if (activeVoiceTarget == VoiceInputTarget.SYSTEM_COMMAND) {
                    viewModel.setVoiceTranscript(partial)
                }
            },
            onFinalResult = { recognized ->
                abandonMicAudioFocus()
                dispatchRecognizedSpeech(listOf(recognized))
            },
            onError = { errMsg ->
                abandonMicAudioFocus()
                if (activeVoiceTarget == VoiceInputTarget.SYSTEM_COMMAND) {
                    viewModel.setVoiceTranscript(errMsg)
                } else {
                    Toast.makeText(this, errMsg, Toast.LENGTH_SHORT).show()
                    activeVoiceTarget = VoiceInputTarget.SYSTEM_COMMAND
                }
            }
        )
    }

    private fun stopSpeechListening() {
        offlineVoskManager.stopListening()
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
        abandonMicAudioFocus()
        activeVoiceTarget = VoiceInputTarget.SYSTEM_COMMAND
        viewModel.setVoiceListening(false)
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(forceExitReceiver)
        } catch (_: Exception) {}
        destroyOnlineRecognizer()
        offlineVoskManager.release()
        abandonMicAudioFocus()
        super.onDestroy()
    }
}

@Composable
fun MainAppContent(
    viewModel: GameNetViewModel,
    activeEngineBadge: String = "",
    receiptVoiceHint: String = "",
    scopedSearchHint: Pair<VoiceInputTarget, String>? = null,
    voiceAutoCloseSeq: Long = 0L,
    onClearReceiptVoiceHint: () -> Unit = {},
    onClearScopedSearchHint: () -> Unit = {},
    onStartListening: () -> Unit,
    onStartReceiptCustomerVoice: () -> Unit = {},
    onStartTargetedVoice: (VoiceInputTarget) -> Unit = {},
    onStopListening: () -> Unit
) {
    val systemsWithSessions by viewModel.systemsWithSessions.collectAsStateWithLifecycle()
    val systems by viewModel.systems.collectAsStateWithLifecycle()
    val snacks by viewModel.snacks.collectAsStateWithLifecycle()
    val debts by viewModel.debts.collectAsStateWithLifecycle()
    val credits by viewModel.customerCredits.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val cashEntries by viewModel.cashEntries.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val bankCards by viewModel.bankCards.collectAsStateWithLifecycle()
    val clubProfile by viewModel.clubProfile.collectAsStateWithLifecycle()
    val customVoiceCommands by viewModel.customVoiceCommands.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentNavTab.collectAsStateWithLifecycle()

    val voiceEngineMode by viewModel.voiceEngineMode.collectAsStateWithLifecycle()
    val isVoiceListening by viewModel.isVoiceListening.collectAsStateWithLifecycle()
    val voiceTranscript by viewModel.voiceTranscript.collectAsStateWithLifecycle()
    val voiceFeedbackMessage by viewModel.voiceFeedbackMessage.collectAsStateWithLifecycle()
    val pendingVoiceStartCommand by viewModel.pendingVoiceStartCommand.collectAsStateWithLifecycle()

    val selectedSystemForPopup by viewModel.selectedSystemForPopup.collectAsStateWithLifecycle()
    val selectedSystemForStart by viewModel.selectedSystemForStart.collectAsStateWithLifecycle()
    val lastFinishedSession by viewModel.lastFinishedSession.collectAsStateWithLifecycle()
    val miniPlayerCheckoutState by viewModel.miniPlayerCheckoutState.collectAsStateWithLifecycle()
    val transferCandidateSystem by viewModel.transferCandidateSystem.collectAsStateWithLifecycle()

    var showVoiceAssistantDialog by remember { mutableStateOf(false) }
    var showDeveloperInfoDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showMiniCalculator by remember { mutableStateOf(false) }

    val busySystemIds = remember(systemsWithSessions) {
        systemsWithSessions.filter { it.session != null }.map { it.system.id }.toSet()
    }
    val activeSessionsBySystemId = remember(systemsWithSessions) {
        systemsWithSessions.mapNotNull { it.session?.let { s -> it.system.id to s } }.toMap()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    LaunchedEffect(Unit) {
        val permissionsToAsk = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToAsk.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(permissionsToAsk.toTypedArray())
    }

    // Auto-close VoiceAssistantDialog when a spoken voice command finishes and executes
    LaunchedEffect(voiceAutoCloseSeq) {
        if (voiceAutoCloseSeq > 0L) {
            showVoiceAssistantDialog = false
        }
    }

    // Internal in-app notification auto-dismisses after exactly 10 seconds
    LaunchedEffect(voiceFeedbackMessage) {
        if (voiceFeedbackMessage != null) {
            kotlinx.coroutines.delay(10_000L)
            viewModel.clearVoiceFeedback()
        }
    }

    // Back press on secondary bottom tabs returns cleanly to Systems home screen
    BackHandler(enabled = currentTab != NavTab.SYSTEMS) {
        viewModel.setNavTab(NavTab.SYSTEMS)
    }

    val activeCount = remember(systemsWithSessions) {
        systemsWithSessions.count { it.session != null }
    }

    val expiredItem = remember(systemsWithSessions) {
        systemsWithSessions.firstOrNull { it.isExpired }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(GamingBackground),
        topBar = {
            HeaderHeroBanner(
                activeSystemsCount = activeCount,
                totalSystemsCount = systems.size,
                isVoiceListening = isVoiceListening,
                clubName = clubProfile?.clubName ?: "",
                onVoiceClick = {
                    showVoiceAssistantDialog = true
                    onStartListening()
                },
                onDeveloperInfoClick = {
                    showDeveloperInfoDialog = true
                },
                onProfileClick = {
                    showProfileDialog = true
                },
                onOpenCalculator = {
                    showMiniCalculator = true
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = GamingSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == NavTab.SYSTEMS,
                    onClick = { viewModel.setNavTab(NavTab.SYSTEMS) },
                    icon = { Icon(Icons.Default.SportsEsports, contentDescription = "سیستم‌ها") },
                    label = { Text("سیستم‌ها", fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CrystalCyan,
                        indicatorColor = CrystalCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )

                NavigationBarItem(
                    selected = currentTab == NavTab.DEBTS,
                    onClick = { viewModel.setNavTab(NavTab.DEBTS) },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = "دفتر حسابداری") },
                    label = { Text("حسابداری", fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CrystalAmber,
                        indicatorColor = CrystalAmber,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )

                NavigationBarItem(
                    selected = currentTab == NavTab.STATS,
                    onClick = { viewModel.setNavTab(NavTab.STATS) },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "آمار و گزارش") },
                    label = { Text("آمار فروش", fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CrystalGreen,
                        indicatorColor = CrystalGreen,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )

                NavigationBarItem(
                    selected = currentTab == NavTab.CUSTOMERS,
                    onClick = { viewModel.setNavTab(NavTab.CUSTOMERS) },
                    icon = { Icon(Icons.Default.People, contentDescription = "مشتریان") },
                    label = { Text("مشتریان", fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CrystalMagenta,
                        indicatorColor = CrystalMagenta,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )

                NavigationBarItem(
                    selected = currentTab == NavTab.SETTINGS,
                    onClick = { viewModel.setNavTab(NavTab.SETTINGS) },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "تنظیمات") },
                    label = { Text("تنظیمات", fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1, softWrap = false) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = CrystalPurple,
                        indicatorColor = CrystalPurple,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        },
        containerColor = GamingBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NavTab.SYSTEMS -> {
                    SystemsScreen(
                        systemsWithSessions = systemsWithSessions,
                        onSystemClick = { item ->
                            if (item.session != null) {
                                viewModel.openSystemPopup(item.system)
                            } else {
                                viewModel.openStartDialog(item.system)
                            }
                        },
                        onStopAlarm = { sysId ->
                            viewModel.finishSession(sysId)
                        },
                        onTransferSystemClick = { item ->
                            viewModel.openTransferDialogForSystem(item.system)
                        },
                        onOpenVoiceAssistant = {
                            showVoiceAssistantDialog = true
                            onStartListening()
                        }
                    )
                }

                NavTab.DEBTS -> {
                    DebtsScreen(
                        debts = debts,
                        credits = credits,
                        voiceSearchHint = if (scopedSearchHint?.first == VoiceInputTarget.DEBTS_SEARCH) scopedSearchHint.second else "",
                        onRequestVoiceForSearch = {
                            onClearScopedSearchHint()
                            onStartTargetedVoice(VoiceInputTarget.DEBTS_SEARCH)
                        },
                        onAddDebt = { name, amount, note ->
                            viewModel.addDebt(name, amount, note)
                        },
                        onAddCredit = { name, amount, note ->
                            viewModel.addCustomerCredit(name, amount, note)
                        },
                        onAddCustomer = { code, name, phone, nationalId ->
                            viewModel.addCustomer(code, name, phone, nationalId, 0)
                        },
                        onSettleDebt = { debt ->
                            viewModel.settleDebtAndTransferToStats(debt)
                        },
                        onDeleteDebt = { debt ->
                            viewModel.deleteDebt(debt)
                        },
                        onDeleteCredit = { credit ->
                            viewModel.deleteCustomerCredit(credit)
                        },
                        onUpdateDebtLineItems = { debtId, updatedItems, updatedNote ->
                            viewModel.updateOrAddDebtLineItems(debtId, updatedItems, updatedNote)
                        }
                    )
                }

                NavTab.STATS -> {
                    StatsScreen(
                        historyList = history,
                        cashEntries = cashEntries,
                        onUpdateHistory = { updated ->
                            viewModel.updateHistory(updated)
                        },
                        onDeleteHistory = { target ->
                            viewModel.deleteHistory(target)
                        },
                        onClearAllHistory = {
                            viewModel.clearAllHistory()
                        },
                        onAddCashEntry = { amount, note, customer ->
                            viewModel.addCashEntry(amount, note, customer)
                        },
                        onUpdateCashEntry = { entry ->
                            viewModel.updateCashEntry(entry)
                        },
                        onDeleteCashEntry = { entry ->
                            viewModel.deleteCashEntry(entry)
                        },
                        onAddService = { title, amount, note, cashPaid, cardPaid ->
                            viewModel.addServiceEntry(title, amount, note, cashPaid, cardPaid)
                        }
                    )
                }

                NavTab.CUSTOMERS -> {
                    val custTargetKey = when (scopedSearchHint?.first) {
                        VoiceInputTarget.CUSTOMERS_SEARCH_DIR -> CustomerSubTab.DIRECTORY.name
                        VoiceInputTarget.CUSTOMERS_SEARCH_DEBT_SMS -> CustomerSubTab.SEND_DEBT_SMS.name
                        VoiceInputTarget.CUSTOMERS_SEARCH_DISCOUNT -> CustomerSubTab.SET_DISCOUNT.name
                        VoiceInputTarget.CUSTOMERS_SEARCH_DISC_SMS -> CustomerSubTab.SEND_DISCOUNT_SMS.name
                        else -> ""
                    }
                    CustomersScreen(
                        customers = customers,
                        debts = debts,
                        bankCards = bankCards,
                        clubName = clubProfile?.clubName ?: "",
                        credits = credits,
                        voiceSearchHint = if (custTargetKey.isNotEmpty()) scopedSearchHint?.second.orEmpty() else "",
                        voiceSearchTarget = custTargetKey,
                        onRequestVoiceForSearch = { subTabKey ->
                            onClearScopedSearchHint()
                            val target = when (subTabKey) {
                                CustomerSubTab.SEND_DEBT_SMS.name -> VoiceInputTarget.CUSTOMERS_SEARCH_DEBT_SMS
                                CustomerSubTab.SET_DISCOUNT.name -> VoiceInputTarget.CUSTOMERS_SEARCH_DISCOUNT
                                CustomerSubTab.SEND_DISCOUNT_SMS.name -> VoiceInputTarget.CUSTOMERS_SEARCH_DISC_SMS
                                else -> VoiceInputTarget.CUSTOMERS_SEARCH_DIR
                            }
                            onStartTargetedVoice(target)
                        },
                        onAddCustomer = { code, name, phone, nationalId, discount ->
                            viewModel.addCustomer(code, name, phone, nationalId, discount)
                        },
                        onUpdateCustomer = { customer ->
                            viewModel.updateCustomer(customer)
                        },
                        onDeleteCustomer = { customer ->
                            viewModel.deleteCustomer(customer)
                        },
                        onUpdateDebt = { debt ->
                            viewModel.updateDebt(debt)
                        },
                        onDeleteDebt = { debt ->
                            viewModel.deleteDebt(debt)
                        },
                        onAddBankCard = { bankName, cardNumber, cardHolder ->
                            viewModel.addBankCard(bankName, cardNumber, cardHolder)
                        },
                        onDeleteBankCard = { bankCard ->
                            viewModel.deleteBankCard(bankCard)
                        },
                        onBackToSettings = null
                    )
                }

                NavTab.SETTINGS -> {
                    SettingsScreen(
                        systems = systems,
                        snacks = snacks,
                        customCommands = customVoiceCommands,
                        customerCount = customers.size,
                        onOpenCustomers = { viewModel.setNavTab(NavTab.CUSTOMERS) },
                        onAddSystem = { name, type, rate ->
                            viewModel.addNewSystem(name, type, rate)
                        },
                        onUpdateSystemRate = { sys ->
                            viewModel.updateSystem(sys)
                        },
                        onAddSnack = { name, price, category ->
                            viewModel.addSnackItem(name, price, category)
                        },
                        onUpdateSnack = { snack ->
                            viewModel.updateSnackItem(snack)
                        },
                        onDeleteSnack = { snack ->
                            viewModel.deleteSnackItem(snack)
                        },
                        onDeleteCustomCommand = { cmd ->
                            viewModel.deleteCustomCommand(cmd)
                        },
                        onExportBackup = {
                            viewModel.exportBackupJson()
                        },
                        onImportBackup = { json ->
                            viewModel.importBackupJson(json)
                        },
                        onRequestBatteryOptimization = { ctx ->
                            viewModel.requestBatteryOptimizationExemption(ctx)
                        },
                        onRequestCleanExit = { ctx ->
                            viewModel.requestCleanExit(ctx)
                        }
                    )
                }
            }

            if (voiceFeedbackMessage != null && !showVoiceAssistantDialog) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, CrystalCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .align(Alignment.TopCenter)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = voiceFeedbackMessage ?: "",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrystalCyan,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearVoiceFeedback() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                        }
                    }
                }
            }
        }
    }

    if (showVoiceAssistantDialog) {
        VoiceAssistantDialog(
            isListening = isVoiceListening,
            transcript = voiceTranscript,
            feedbackMessage = voiceFeedbackMessage,
            customCommands = customVoiceCommands,
            systems = systems,
            voiceEngineMode = voiceEngineMode,
            activeEngineBadge = activeEngineBadge,
            onVoiceEngineModeChange = { viewModel.setVoiceEngineMode(it) },
            onDismiss = {
                showVoiceAssistantDialog = false
                onStopListening()
            },
            onStartListening = onStartListening,
            onSubmitCommand = { cmd ->
                viewModel.executeVoiceCommand(cmd)
                showVoiceAssistantDialog = false
            },
            onAddCustomCommand = { phrase, targetSysId, targetSysName, players, durationMin, mode, amountTomans ->
                viewModel.addCustomCommand(phrase, targetSysId, targetSysName, players, durationMin, mode, amountTomans)
            },
            onDeleteCustomCommand = { cmd ->
                viewModel.deleteCustomCommand(cmd)
            },
            onDeleteCustomCommandsByIds = { ids ->
                viewModel.deleteCustomVoiceCommandsByIds(ids)
            },
            onClearAllCustomCommands = {
                viewModel.clearAllCustomVoiceCommands()
            }
        )
    }

    // Voice System Start Confirmation Dialog (always asks user before starting)
    if (pendingVoiceStartCommand != null) {
        VoiceStartConfirmationDialog(
            pending = pendingVoiceStartCommand!!,
            systems = systems,
            busySystemIds = busySystemIds,
            customers = customers,
            onConfirm = { sysId, players, mode, durationMin, amountTomans, customerCode ->
                viewModel.confirmPendingVoiceStart(
                    systemId = sysId,
                    playerCount = players,
                    mode = mode,
                    durationMinutes = durationMin,
                    amountTomans = amountTomans,
                    customerCode = customerCode,
                    customStartHour = pendingVoiceStartCommand?.customStartHour,
                    customStartMinute = pendingVoiceStartCommand?.customStartMinute
                )
            },
            onDismiss = { viewModel.dismissPendingVoiceStart() }
        )
    }

    if (showDeveloperInfoDialog) {
        DeveloperInfoDialog(
            onDismiss = { showDeveloperInfoDialog = false }
        )
    }

    if (showProfileDialog) {
        ClubProfileDialog(
            profile = clubProfile,
            onDismiss = { showProfileDialog = false },
            onSaveProfile = { name, manager, phone, avatar ->
                viewModel.updateClubProfile(name, manager, phone, avatar)
            }
        )
    }

    if (selectedSystemForStart != null) {
        val sys = selectedSystemForStart!!
        StartSessionDialog(
            system = sys,
            onDismiss = { viewModel.closeStartDialog() },
            onStartByDuration = { players, mins, customer ->
                viewModel.startSessionWithDuration(sys, players, mins, customer)
            },
            onStartByAmount = { players, amt, customer ->
                viewModel.startSessionWithAmount(sys, players, amt, customer)
            },
            onStartOpenEnded = { players, customer ->
                viewModel.startOpenEnded(sys, players, customer)
            },
            onStartCustomTime = { startMode, players, mins, amt, customer, customStartMillis ->
                when (startMode) {
                    StartMode.BY_TIME -> viewModel.startSessionWithDuration(sys, players, mins, customer, customStartMillis)
                    StartMode.BY_AMOUNT -> viewModel.startSessionWithAmount(sys, players, amt, customer, customStartMillis)
                    StartMode.OPEN_ENDED -> viewModel.startOpenEnded(sys, players, customer, customStartMillis)
                }
            }
        )
    }

    if (selectedSystemForPopup != null) {
        val sys = selectedSystemForPopup!!
        val activeItem = systemsWithSessions.firstOrNull { it.system.id == sys.id }
        SystemDetailPopupSheet(
            system = sys,
            session = activeItem?.session,
            snacksList = snacks,
            allSystems = systems,
            busySystemIds = busySystemIds,
            activeSessionsBySystemId = activeSessionsBySystemId,
            customers = customers,
            voiceTranscriptHint = receiptVoiceHint,
            onRequestVoiceForCustomer = onStartReceiptCustomerVoice,
            onDismiss = { viewModel.closeSystemPopup() },
            onAddSnack = { snackName, count, targetSeatId ->
                viewModel.addSnackToSession(sys.id, snackName, count, targetSeatId)
            },
            onRemoveSnackLine = { lineId ->
                viewModel.removeSnackLine(sys.id, lineId)
            },
            onUpdateSessionNote = { noteText ->
                viewModel.updateSessionNote(sys.id, noteText)
            },
            onUpdateSeatCustomerName = { seatId, newNameOrCode ->
                viewModel.updateSeatCustomerName(sys.id, seatId, newNameOrCode)
            },
            onModifyTimer = { deltaMin ->
                viewModel.modifyTimer(sys.id, deltaMin)
            },
            onUpdatePlayersFromStart = { newCount, addedNames ->
                viewModel.updatePlayersFromStart(sys.id, newCount, addedNames)
            },
            onAddPlayersFromNow = { addedNames ->
                viewModel.addPlayersFromNow(sys.id, addedNames)
            },
            onRequestMiniCheckoutForSeat = { seatId ->
                viewModel.requestMiniCheckoutForSeat(sys.id, seatId)
            },
            onConvertCountdownToOpen = {
                viewModel.convertCountdownToOpen(sys.id)
            },
            onConvertOpenToCountdown = { mins ->
                viewModel.convertOpenToCountdown(sys.id, mins)
            },
            onConvertAmountToTime = { amt ->
                viewModel.convertAmountToTime(sys.id, amt)
            },
            onTransferOrMerge = { seatIds, customerInput, targetSystem ->
                onClearReceiptVoiceHint()
                viewModel.transferOrMergePlayers(sys.id, seatIds, customerInput, targetSystem)
            },
            onPauseSession = {
                viewModel.pauseSession(sys.id)
            },
            onResumeSession = {
                viewModel.resumeSession(sys.id)
            },
            onFinishSession = {
                viewModel.finishSession(sys.id)
            }
        )
    }

    // Standalone Transfer Dialog launched directly from any SystemCard menu/pill
    if (transferCandidateSystem != null) {
        val srcSys = transferCandidateSystem!!
        val srcSess = activeSessionsBySystemId[srcSys.id]
        TransferSystemDialog(
            sourceSystem = srcSys,
            sourceSession = srcSess,
            allSystems = systems,
            activeSessionsBySystemId = activeSessionsBySystemId,
            customers = customers,
            voiceTranscriptHint = receiptVoiceHint,
            onRequestVoiceForCustomer = onStartReceiptCustomerVoice,
            onDismiss = {
                onClearReceiptVoiceHint()
                viewModel.closeTransferDialogForSystem()
            },
            onConfirmTransfer = { seatIds, customerInput, targetSystem ->
                onClearReceiptVoiceHint()
                viewModel.transferOrMergePlayers(srcSys.id, seatIds, customerInput, targetSystem)
            }
        )
    }

    // Departing Player Mini Checkout Dialog
    if (miniPlayerCheckoutState != null) {
        val checkout = miniPlayerCheckoutState!!
        MiniPlayerCheckoutDialog(
            data = checkout,
            customers = customers,
            onDismiss = { viewModel.dismissMiniCheckout() },
            onConfirmPaid = { editedHist, custInput, cashPaid, cardPaid ->
                viewModel.finalizeDepartingPlayerCheckout(
                    checkout = checkout,
                    editedHistory = editedHist,
                    settleAsDebt = false,
                    customerInput = custInput,
                    cashPaidTomans = cashPaid,
                    cardPaidTomans = cardPaid
                )
            },
            onConfirmDebt = { editedHist, custInput, cashPaid, cardPaid ->
                viewModel.finalizeDepartingPlayerCheckout(
                    checkout = checkout,
                    editedHistory = editedHist,
                    settleAsDebt = true,
                    customerInput = custInput,
                    cashPaidTomans = cashPaid,
                    cardPaidTomans = cardPaid
                )
            }
        )
    }

    if (expiredItem != null && lastFinishedSession == null) {
        TimeExpiredPopupDialog(
            expiredItem = expiredItem,
            onContinueOpenEnded = {
                viewModel.continueSessionOpenEnded(expiredItem.system.id)
            },
            onExtendMinutes = { mins ->
                viewModel.modifyTimer(expiredItem.system.id, mins)
            },
            onFinishGame = {
                viewModel.finishSession(expiredItem.system.id)
            }
        )
    }

    if (lastFinishedSession != null) {
        FinishedReceiptDialog(
            history = lastFinishedSession!!,
            customers = customers,
            debts = debts,
            credits = credits,
            voiceTranscriptHint = receiptVoiceHint,
            onRequestVoiceForCustomer = onStartReceiptCustomerVoice,
            onQuickAddCustomer = { code, name, phone, nationalId ->
                viewModel.addCustomer(code, name, phone, nationalId, 0)
            },
            onConfirmSave = { editedHistory, cashPaidTomans, debtSettlementAmountTomans, customerCodeOrName, cardPaidTomans, seatResolutions ->
                onClearReceiptVoiceHint()
                viewModel.completePaidReceipt(
                    editedHistory = editedHistory,
                    cashPaidTomans = cashPaidTomans,
                    debtSettlementAmountTomans = debtSettlementAmountTomans,
                    customerCodeOrName = customerCodeOrName,
                    cardPaidTomans = cardPaidTomans,
                    seatResolutions = seatResolutions
                )
            },
            onConfirmSaveWithCredit = { editedHistory, cashPaidTomans, debtSettlementAmountTomans, customerCodeOrName, cardPaidTomans, seatResolutions, creditUsedTomans ->
                onClearReceiptVoiceHint()
                viewModel.completePaidReceipt(
                    editedHistory = editedHistory,
                    cashPaidTomans = cashPaidTomans,
                    debtSettlementAmountTomans = debtSettlementAmountTomans,
                    customerCodeOrName = customerCodeOrName,
                    cardPaidTomans = cardPaidTomans,
                    seatResolutions = seatResolutions,
                    creditUsedTomans = creditUsedTomans
                )
            },
            onCancelAndResume = {
                onClearReceiptVoiceHint()
                viewModel.cancelFinishAndResumeSession()
            },
            onDiscard = {
                onClearReceiptVoiceHint()
                viewModel.discardReceipt()
            },
            onRegisterAsDebt = { editedHistory, customerInput, cashPaidTomans, debtSettlementAmountTomans, cardPaidTomans, seatResolutions ->
                onClearReceiptVoiceHint()
                viewModel.registerReceiptAsDebt(
                    editedHistory = editedHistory,
                    customerInput = customerInput,
                    cashPaidTomans = cashPaidTomans,
                    debtSettlementAmountTomans = debtSettlementAmountTomans,
                    cardPaidTomans = cardPaidTomans,
                    seatResolutions = seatResolutions
                )
            },
            onRegisterAsDebtWithCredit = { editedHistory, customerInput, cashPaidTomans, debtSettlementAmountTomans, cardPaidTomans, seatResolutions, creditUsedTomans ->
                onClearReceiptVoiceHint()
                viewModel.registerReceiptAsDebt(
                    editedHistory = editedHistory,
                    customerInput = customerInput,
                    cashPaidTomans = cashPaidTomans,
                    debtSettlementAmountTomans = debtSettlementAmountTomans,
                    cardPaidTomans = cardPaidTomans,
                    seatResolutions = seatResolutions,
                    creditUsedTomans = creditUsedTomans
                )
            }
        )
    }

    if (showMiniCalculator) {
        MiniCalculatorOverlay(
            onDismiss = { showMiniCalculator = false }
        )
    }
}
