package com.example.data.local

import android.content.Context
import androidx.annotation.VisibleForTesting
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        GameSystemEntity::class,
        ActiveSessionEntity::class,
        GameHistoryEntity::class,
        SnackItemEntity::class,
        CustomerDebtEntity::class,
        CustomerCreditEntity::class,
        CustomerEntity::class,
        ClubProfileEntity::class,
        CustomVoiceCommandEntity::class,
        BankCardEntity::class,
        CashEntryEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gameNetDao(): GameNetDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        @VisibleForTesting
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN isPaused INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN pausedAtMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE custom_voice_commands ADD COLUMN mode TEXT NOT NULL DEFAULT 'TIME'")
                db.execSQL("ALTER TABLE custom_voice_commands ADD COLUMN amountTomans INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE game_systems SET code = CAST(id AS TEXT)")
                db.execSQL("UPDATE game_systems SET hourlyRatePerPlayer = 60000 WHERE systemType = 'PS4' OR systemType = 'PC'")
                db.execSQL("UPDATE game_systems SET hourlyRatePerPlayer = 70000 WHERE systemType = 'PS5'")
                db.execSQL("UPDATE game_systems SET hourlyRatePerPlayer = 120000 WHERE systemType = 'VR'")
                db.execSQL("UPDATE game_systems SET hourlyRatePerPlayer = 100000 WHERE systemType = 'WHEEL'")
                db.execSQL("UPDATE club_profile SET clubName = 'مدیریت گیم‌نت' WHERE clubName = 'کلوپ کریستال'")
                db.execSQL("UPDATE club_profile SET managerName = 'مدیریت مجموعه' WHERE managerName = 'مدیریت کلوپ کریستال'")
                db.execSQL("UPDATE bank_cards SET cardHolder = 'مدیریت گیم‌نت' WHERE cardHolder = 'کلوپ کریستال'")
            }
        }

        @VisibleForTesting
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Active Sessions: segmented billing support (player change & system transfer)
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN segmentsJson TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN currentSegmentStartMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE active_sessions SET currentSegmentStartMillis = startTimeMillis WHERE currentSegmentStartMillis = 0")

                // Game History: cash deduction, debt settlement link, segment details, entryType
                db.execSQL("ALTER TABLE game_history ADD COLUMN cashPaidTomans INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_history ADD COLUMN debtSettledTomans INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_history ADD COLUMN segmentsDetailJson TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE game_history ADD COLUMN entryType TEXT NOT NULL DEFAULT 'GAME'")

                // Customer Debts: full receipt metadata for deferred transfer to Stats on settlement
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN systemDisplayName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN playerCount INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN playedMinutes INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN gameFee INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN snacksFee INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN snacksDetail TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN startTimeMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN endTimeMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN discountPercent INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN discountAmount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN segmentsDetailJson TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE customer_debts ADD COLUMN transferredToStats INTEGER NOT NULL DEFAULT 0")

                // Daily Cash Ledger Table
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cash_entries` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `amountTomans` INTEGER NOT NULL,
                        `note` TEXT NOT NULL DEFAULT '',
                        `customerName` TEXT NOT NULL DEFAULT '',
                        `source` TEXT NOT NULL DEFAULT 'RECEIPT',
                        `createdAtMillis` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        @VisibleForTesting
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN playerSeatsJson TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN modeConversionNotes TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN nextAnonCounter INTEGER NOT NULL DEFAULT 1")

                db.execSQL("ALTER TABLE game_history ADD COLUMN cardPaidTomans INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_history ADD COLUMN modeConversionNotes TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE game_history ADD COLUMN playerSeatsJson TEXT NOT NULL DEFAULT '[]'")

                db.execSQL("ALTER TABLE customer_debts ADD COLUMN debtItemsJson TEXT NOT NULL DEFAULT '[]'")
            }
        }

        @VisibleForTesting
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN sessionNote TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE active_sessions ADD COLUMN snacksItemsJson TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE game_history ADD COLUMN sessionNote TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `customer_credits` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `customerName` TEXT NOT NULL,
                        `customerCode` TEXT NOT NULL DEFAULT '',
                        `amountTomans` INTEGER NOT NULL,
                        `note` TEXT NOT NULL DEFAULT '',
                        `createdAtMillis` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cafe_management_db"
                )
                    .addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.gameNetDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: GameNetDao) {
            val defaultSystems = listOf(
                GameSystemEntity(1, "1", "پی اس فور ۱", "PS4", 60000, sortOrder = 1, iconType = "gamepad"),
                GameSystemEntity(2, "2", "پی اس فور ۲", "PS4", 60000, sortOrder = 2, iconType = "gamepad"),
                GameSystemEntity(3, "3", "پی اس فور ۳", "PS4", 60000, sortOrder = 3, iconType = "gamepad"),
                GameSystemEntity(4, "4", "پی اس فور ۴", "PS4", 60000, sortOrder = 4, iconType = "gamepad"),
                GameSystemEntity(5, "5", "پی اس فور ۵", "PS4", 60000, sortOrder = 5, iconType = "gamepad"),
                GameSystemEntity(6, "6", "پی اس فور ۶", "PS4", 60000, sortOrder = 6, iconType = "gamepad"),
                GameSystemEntity(7, "7", "پی اس فایو ۱", "PS5", 70000, sortOrder = 7, iconType = "gamepad"),
                GameSystemEntity(8, "8", "پی اس فایو ۲", "PS5", 70000, sortOrder = 8, iconType = "gamepad"),
                GameSystemEntity(9, "9", "کامپیوتر ۱", "PC", 60000, sortOrder = 9, iconType = "computer"),
                GameSystemEntity(10, "10", "کامپیوتر ۲", "PC", 60000, sortOrder = 10, iconType = "computer"),
                GameSystemEntity(11, "11", "کامپیوتر ۳", "PC", 60000, sortOrder = 11, iconType = "computer"),
                GameSystemEntity(12, "12", "کامپیوتر ۴", "PC", 60000, sortOrder = 12, iconType = "computer"),
                GameSystemEntity(13, "13", "عینک مجازی", "VR", 120000, sortOrder = 13, iconType = "headset"),
                GameSystemEntity(14, "14", "فرمان بازی", "WHEEL", 100000, sortOrder = 14, iconType = "steering_wheel")
            )
            dao.insertSystems(defaultSystems)

            val defaultSnacks = listOf(
                SnackItemEntity(name = "آبمیوه", priceTomans = 25000, category = "نوشیدنی", icon = "drink"),
                SnackItemEntity(name = "کیک", priceTomans = 18000, category = "خوراکی", icon = "cake"),
                SnackItemEntity(name = "نوشابه", priceTomans = 20000, category = "نوشیدنی", icon = "drink"),
                SnackItemEntity(name = "ریدبول", priceTomans = 85000, category = "انرژی‌زا", icon = "bolt"),
                SnackItemEntity(name = "هایپ", priceTomans = 80000, category = "انرژی‌زا", icon = "bolt"),
                SnackItemEntity(name = "چیپس", priceTomans = 22000, category = "تنقلات", icon = "snack"),
                SnackItemEntity(name = "پفک", priceTomans = 18000, category = "تنقلات", icon = "snack"),
                SnackItemEntity(name = "چای", priceTomans = 10000, category = "گرم", icon = "coffee"),
                SnackItemEntity(name = "اسپرسو", priceTomans = 30000, category = "گرم", icon = "coffee"),
                SnackItemEntity(name = "آب معدنی", priceTomans = 10000, category = "نوشیدنی", icon = "water")
            )
            dao.insertSnacks(defaultSnacks)

            val defaultProfile = ClubProfileEntity(
                id = 1,
                clubName = "",
                managerName = "",
                phoneNumber = ""
            )
            dao.saveProfile(defaultProfile)

            val defaultCard = BankCardEntity(
                bankName = "بانک ملی",
                cardNumber = "6037-9975-0000-0000",
                cardHolder = "مدیریت گیم‌نت"
            )
            dao.insertBankCard(defaultCard)
        }
    }
}
