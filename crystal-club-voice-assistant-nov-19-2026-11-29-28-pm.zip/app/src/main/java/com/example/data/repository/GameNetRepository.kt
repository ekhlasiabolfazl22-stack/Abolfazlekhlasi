package com.example.data.repository

import com.example.data.local.GameNetDao
import com.example.data.model.*
import com.example.util.PersianDateUtils
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.roundToLong

data class LiveSessionBilling(
    val completedSegments: List<SessionSegment>,
    val currentSegmentStartMillis: Long,
    val totalPlayedMinutes: Int,
    val rawGameFee: Long,
    val discountAmount: Long,
    val discountedGameFee: Long,
    val totalFeeWithSnacks: Long
)

data class PlayerSeatBreakdown(
    val seat: PlayerSeat,
    val priorGameFee: Long,
    val priorSnacksFee: Long,
    val currentSystemGameFee: Long,
    val assignedSnacksFee: Long,
    val sharedSnacksShare: Long,
    val discountAmount: Long,
    val totalShare: Long,
    val playedMinutes: Int,
    val detailLines: List<String>
)

data class MiniPlayerCheckoutData(
    val systemId: Int,
    val systemDisplayName: String,
    val departingSeat: PlayerSeat,
    val breakdown: PlayerSeatBreakdown,
    val previewHistory: GameHistoryEntity,
    val snapshotTimeMillis: Long
)

data class SeatResolutionInput(
    val seatId: String,
    val displayName: String,
    val status: String, // "PAID" | "DEBT"
    val customerInput: String,
    val amountTomans: Long
)

data class TransferExecutionResult(
    val success: Boolean,
    val targetSystemId: Int,
    val targetSystemName: String,
    val message: String
)

object SessionCostCalculator {

    private fun toPersianDigits(num: Int): String {
        return num.toString()
            .replace('0', '۰')
            .replace('1', '۱')
            .replace('2', '۲')
            .replace('3', '۳')
            .replace('4', '۴')
            .replace('5', '۵')
            .replace('6', '۶')
            .replace('7', '۷')
            .replace('8', '۸')
            .replace('9', '۹')
    }

    private val seatSeq = java.util.concurrent.atomic.AtomicLong(1L)

    fun nextSeatId(prefix: String = "seat"): String {
        val seq = seatSeq.getAndIncrement()
        val rand = java.util.UUID.randomUUID().toString().take(6)
        return "${prefix}_${seq}_${rand}"
    }

    fun ensureSeats(session: ActiveSessionEntity): List<PlayerSeat> {
        val decoded = PlayerSeatCodec.decode(session.playerSeatsJson)
        if (decoded.isNotEmpty()) return decoded
        val count = max(1, session.playerCount)
        return (1..count).map { idx ->
            val name = if (idx == 1 && session.customerName.isNotBlank()) {
                session.customerName
            } else {
                "ناشناس ${toPersianDigits(idx)}"
            }
            PlayerSeat(
                seatId = "seat_${session.id}_${session.systemId}_$idx",
                displayName = name,
                customerCode = "",
                joinedAtMillis = session.startTimeMillis
            )
        }
    }

    fun calculateLiveBilling(
        session: ActiveSessionEntity,
        effectiveNowMillis: Long,
        forFinalReceipt: Boolean = false
    ): LiveSessionBilling {
        val priorSegments = SessionSegmentCodec.decode(session.segmentsJson)
        val seats = ensureSeats(session)
        val activeSeats = seats.filter { !it.isSettled }

        val segStart = if (session.currentSegmentStartMillis > 0L) {
            session.currentSegmentStartMillis
        } else {
            session.startTimeMillis
        }
        val currentElapsedMillis = max(0L, effectiveNowMillis - segStart)

        val currentMinutes: Int
        val currentFee: Long
        val hourlyTotal = session.hourlyRateApplied * session.playerCount
        if (priorSegments.isEmpty()) {
            val effectiveElapsed = max(60_000L, currentElapsedMillis)
            currentMinutes = (effectiveElapsed / 60_000.0).roundToInt().coerceAtLeast(1)
            currentFee = ((effectiveElapsed / 3_600_000.0) * hourlyTotal).roundToLong()
        } else if (currentElapsedMillis < 10_000L) {
            currentMinutes = 0
            currentFee = 0L
        } else {
            currentMinutes = (currentElapsedMillis / 60_000.0).roundToInt().coerceAtLeast(1)
            currentFee = ((currentElapsedMillis / 3_600_000.0) * hourlyTotal).roundToLong()
        }

        val priorFee = priorSegments.sumOf { it.costTomans }
        val priorMinutes = priorSegments.sumOf { it.playedMinutes }
        val seatPriorGameFee = activeSeats.sumOf { s -> s.priorSegments.sumOf { it.costTomans } }
        val seatPriorSnacksFee = activeSeats.sumOf { it.priorSnacksCost }

        val rawGameFee = priorFee + currentFee + seatPriorGameFee
        val totalMinutes = (priorMinutes + currentMinutes).coerceAtLeast(1)

        val discountAmount = if (session.discountPercent > 0) {
            (rawGameFee * session.discountPercent) / 100L
        } else 0L
        val discountedGameFee = max(0L, rawGameFee - discountAmount)
        val totalSnacksFee = session.snacksCost + seatPriorSnacksFee
        val totalFee = discountedGameFee + totalSnacksFee

        return LiveSessionBilling(
            completedSegments = priorSegments,
            currentSegmentStartMillis = segStart,
            totalPlayedMinutes = totalMinutes,
            rawGameFee = rawGameFee,
            discountAmount = discountAmount,
            discountedGameFee = discountedGameFee,
            totalFeeWithSnacks = totalFee
        )
    }

    fun calculateSeatBreakdowns(
        session: ActiveSessionEntity,
        effectiveNowMillis: Long,
        forFinalReceipt: Boolean = true
    ): List<PlayerSeatBreakdown> {
        val billing = calculateLiveBilling(session, effectiveNowMillis, forFinalReceipt)
        val seats = ensureSeats(session)
        if (seats.isEmpty()) return emptyList()

        val activeSeatIds = seats.map { it.seatId }.toSet()
        val allSegments = billing.completedSegments.toMutableList()
        val segStart = billing.currentSegmentStartMillis
        val finalElapsed = max(0L, effectiveNowMillis - segStart)
        val finalHourly = session.hourlyRateApplied * session.playerCount
        val finalMin: Int
        val finalSegCost: Long
        if (allSegments.isEmpty()) {
            val effectiveElapsed = max(60_000L, finalElapsed)
            finalMin = (effectiveElapsed / 60_000.0).roundToInt().coerceAtLeast(1)
            finalSegCost = ((effectiveElapsed / 3_600_000.0) * finalHourly).roundToLong()
        } else if (finalElapsed < 10_000L) {
            finalMin = 0
            finalSegCost = 0L
        } else {
            finalMin = (finalElapsed / 60_000.0).roundToInt().coerceAtLeast(1)
            finalSegCost = ((finalElapsed / 3_600_000.0) * finalHourly).roundToLong()
        }
        if (allSegments.isNotEmpty() || finalMin > 0 || finalSegCost > 0L) {
            allSegments.add(
                SessionSegment(
                    systemId = session.systemId,
                    systemDisplayName = session.systemDisplayName,
                    playerCount = session.playerCount,
                    hourlyRatePerPlayer = session.hourlyRateApplied,
                    startTimeMillis = segStart,
                    endTimeMillis = effectiveNowMillis,
                    playedMinutes = finalMin,
                    costTomans = finalSegCost,
                    note = "سهم بازی فعلی",
                    seatIds = seats.map { it.seatId }
                )
            )
        }

        val totalAssignedSnacks = seats.sumOf { it.currentSystemSnacksCost }
        val sharedPool = max(0L, session.snacksCost - totalAssignedSnacks)
        val sharedPerSeat = sharedPool / seats.size

        val rawSeatList = seats.map { seat ->
            val priorGame = seat.priorSegments.sumOf { it.costTomans }
            val priorSnacks = seat.priorSnacksCost

            var curGame = 0L
            var curMinutes = seat.priorSegments.sumOf { it.playedMinutes }
            val details = mutableListOf<String>()
            if (priorGame > 0L) {
                val srcNames = seat.priorSegments.map { it.systemDisplayName }.distinct().joinToString("، ")
                details.add("انتقال از $srcNames: ${formatNumberStatic(priorGame)} ت")
            }
            if (priorSnacks > 0L) {
                details.add("خوراکی قبلی (${seat.priorSnacksDetail}): ${formatNumberStatic(priorSnacks)} ت")
            }

            allSegments.forEach { seg ->
                val participants = if (seg.seatIds.isNotEmpty()) {
                    seg.seatIds.filter { it in activeSeatIds }
                } else {
                    seats.map { it.seatId }
                }
                if (seat.seatId in participants && participants.isNotEmpty()) {
                    curGame += seg.costTomans / participants.size
                    curMinutes += seg.playedMinutes
                }
            }

            val seatDisc = if (session.discountPercent > 0) {
                ((priorGame + curGame) * session.discountPercent) / 100L
            } else 0L

            if (curGame > 0L) {
                details.add("بازی در ${session.systemDisplayName}: ${formatNumberStatic(curGame)} ت")
            }
            if (seat.currentSystemSnacksCost > 0L) {
                details.add("خوراکی اختصاصی (${seat.currentSystemSnacksDetail}): ${formatNumberStatic(seat.currentSystemSnacksCost)} ت")
            }
            if (sharedPerSeat > 0L) {
                details.add("سهم خوراکی مشترک: ${formatNumberStatic(sharedPerSeat)} ت")
            }

            val total = max(0L, priorGame + curGame - seatDisc) + priorSnacks + seat.currentSystemSnacksCost + sharedPerSeat
            PlayerSeatBreakdown(
                seat = seat,
                priorGameFee = priorGame,
                priorSnacksFee = priorSnacks,
                currentSystemGameFee = curGame,
                assignedSnacksFee = seat.currentSystemSnacksCost,
                sharedSnacksShare = sharedPerSeat,
                discountAmount = seatDisc,
                totalShare = total,
                playedMinutes = curMinutes.coerceAtLeast(1),
                detailLines = details
            )
        }.toMutableList()

        // Absorb any integer-division rounding difference on the first seat so sum matches exact total
        val sumShares = rawSeatList.sumOf { it.totalShare }
        val diff = billing.totalFeeWithSnacks - sumShares
        if (diff != 0L && rawSeatList.isNotEmpty()) {
            val first = rawSeatList[0]
            rawSeatList[0] = first.copy(totalShare = max(0L, first.totalShare + diff))
        }
        return rawSeatList
    }

    fun calculateSeatBreakdownsFromHistory(history: GameHistoryEntity): List<PlayerSeatBreakdown> {
        val seats = PlayerSeatCodec.decode(history.playerSeatsJson)
        if (seats.isEmpty()) return emptyList()
        val segments = SessionSegmentCodec.decode(history.segmentsDetailJson)
        val activeIds = seats.map { it.seatId }.toSet()

        val totalAssignedSnacks = seats.sumOf { it.currentSystemSnacksCost }
        val priorSnacksAll = seats.sumOf { it.priorSnacksCost }
        val currentSessionSnacks = max(0L, history.snacksFee - priorSnacksAll)
        val sharedPool = max(0L, currentSessionSnacks - totalAssignedSnacks)
        val sharedPerSeat = sharedPool / seats.size

        val list = seats.map { seat ->
            val priorGame = seat.priorSegments.sumOf { it.costTomans }
            val priorSnacks = seat.priorSnacksCost
            var curGame = 0L
            var curMins = seat.priorSegments.sumOf { it.playedMinutes }
            val details = mutableListOf<String>()

            if (priorGame > 0L) {
                val srcNames = seat.priorSegments.map { it.systemDisplayName }.distinct().joinToString("، ")
                details.add("انتقال از $srcNames: ${formatNumberStatic(priorGame)} ت")
            }
            if (priorSnacks > 0L) {
                details.add("خوراکی قبلی: ${formatNumberStatic(priorSnacks)} ت")
            }

            segments.forEach { seg ->
                val participants = if (seg.seatIds.isNotEmpty()) {
                    seg.seatIds.filter { it in activeIds }
                } else {
                    seats.map { it.seatId }
                }
                if (seat.seatId in participants && participants.isNotEmpty()) {
                    curGame += seg.costTomans / participants.size
                    curMins += seg.playedMinutes
                }
            }

            if (curGame > 0L) {
                details.add("سهم بازی فعلی: ${formatNumberStatic(curGame)} ت")
            }
            if (seat.currentSystemSnacksCost > 0L) {
                details.add("خوراکی (${seat.currentSystemSnacksDetail}): ${formatNumberStatic(seat.currentSystemSnacksCost)} ت")
            }
            if (sharedPerSeat > 0L) {
                details.add("خوراکی مشترک: ${formatNumberStatic(sharedPerSeat)} ت")
            }

            val disc = if (history.discountPercent > 0) {
                ((priorGame + curGame) * history.discountPercent) / 100L
            } else 0L

            val total = max(0L, priorGame + curGame - disc) + priorSnacks + seat.currentSystemSnacksCost + sharedPerSeat
            PlayerSeatBreakdown(
                seat = seat,
                priorGameFee = priorGame,
                priorSnacksFee = priorSnacks,
                currentSystemGameFee = curGame,
                assignedSnacksFee = seat.currentSystemSnacksCost,
                sharedSnacksShare = sharedPerSeat,
                discountAmount = disc,
                totalShare = total,
                playedMinutes = curMins.coerceAtLeast(1),
                detailLines = details
            )
        }.toMutableList()

        val sumShares = list.sumOf { it.totalShare }
        val diff = history.totalFee - sumShares
        if (diff != 0L && list.isNotEmpty()) {
            list[0] = list[0].copy(totalShare = max(0L, list[0].totalShare + diff))
        }
        return list
    }

    fun buildSegmentForTransition(
        session: ActiveSessionEntity,
        transitionMillis: Long,
        note: String
    ): SessionSegment {
        val segStart = if (session.currentSegmentStartMillis > 0L) {
            session.currentSegmentStartMillis
        } else {
            session.startTimeMillis
        }
        val seats = ensureSeats(session)
        val elapsedMillis = max(0L, transitionMillis - segStart)
        val minutes = if (elapsedMillis < 10_000L) {
            0
        } else {
            (elapsedMillis / 60_000.0).roundToInt().coerceAtLeast(1)
        }
        val hourlyTotal = session.hourlyRateApplied * session.playerCount
        val cost = if (elapsedMillis < 10_000L) {
            0L
        } else {
            ((elapsedMillis / 3_600_000.0) * hourlyTotal).roundToLong()
        }
        return SessionSegment(
            systemId = session.systemId,
            systemDisplayName = session.systemDisplayName,
            playerCount = session.playerCount,
            hourlyRatePerPlayer = session.hourlyRateApplied,
            startTimeMillis = segStart,
            endTimeMillis = transitionMillis,
            playedMinutes = minutes,
            costTomans = cost,
            note = note,
            seatIds = seats.map { it.seatId }
        )
    }

    private fun formatNumberStatic(value: Long): String {
        return String.format(Locale.US, "%,d", value)
    }
}

class GameNetRepository(private val dao: GameNetDao) {

    val systems: Flow<List<GameSystemEntity>> = dao.getAllSystems()
    val activeSessions: Flow<List<ActiveSessionEntity>> = dao.getActiveSessions()
    val gameHistory: Flow<List<GameHistoryEntity>> = dao.getAllHistory()
    val cashEntries: Flow<List<CashEntryEntity>> = dao.getAllCashEntries()
    val snacks: Flow<List<SnackItemEntity>> = dao.getAllSnacks()
    val debts: Flow<List<CustomerDebtEntity>> = dao.getAllDebts()
    val credits: Flow<List<CustomerCreditEntity>> = dao.getAllCredits()
    val customers: Flow<List<CustomerEntity>> = dao.getAllCustomers()
    val profile: Flow<ClubProfileEntity?> = dao.getProfileFlow()
    val customVoiceCommands: Flow<List<CustomVoiceCommandEntity>> = dao.getAllCustomVoiceCommands()
    val bankCards: Flow<List<BankCardEntity>> = dao.getAllBankCards()

    suspend fun getSystemById(id: Int): GameSystemEntity? = dao.getSystemById(id)

    suspend fun updateSystem(system: GameSystemEntity) = dao.updateSystem(system)

    suspend fun addNewSystem(displayName: String, systemType: String, hourlyRate: Long): GameSystemEntity {
        val nextId = (dao.getMaxSystemId() ?: 14) + 1
        val iconType = when (systemType.uppercase()) {
            "PC" -> "computer"
            "VR" -> "headset"
            "WHEEL" -> "steering_wheel"
            else -> "gamepad"
        }
        val sys = GameSystemEntity(
            id = nextId,
            code = nextId.toString(),
            displayName = displayName.trim(),
            systemType = systemType.uppercase(),
            hourlyRatePerPlayer = hourlyRate,
            iconType = iconType,
            sortOrder = nextId
        )
        dao.insertSystem(sys)
        return sys
    }

    suspend fun getActiveSessionForSystem(systemId: Int): ActiveSessionEntity? =
        dao.getSessionBySystemId(systemId)

    suspend fun isSystemBusy(systemId: Int): Boolean {
        return dao.getSessionBySystemId(systemId) != null
    }

    private suspend fun resolveCustomerDiscount(customerQuery: String): Int {
        return findCustomerByCodeOrName(customerQuery)?.discountPercent ?: 0
    }

    private fun buildInitialSeats(
        playerCount: Int,
        customerName: String,
        matchedCustomer: CustomerEntity?,
        startTimeMillis: Long
    ): Pair<List<PlayerSeat>, Int> {
        val safePlayers = max(1, playerCount)
        var anonCounter = 1
        val seats = (1..safePlayers).map { idx ->
            val seatName: String
            val seatCode: String
            if (idx == 1 && (matchedCustomer != null || customerName.isNotBlank())) {
                seatName = matchedCustomer?.name ?: customerName.trim()
                seatCode = matchedCustomer?.customerCode ?: ""
            } else {
                seatName = "ناشناس ${toPersianDigits(anonCounter)}"
                seatCode = ""
                anonCounter++
            }
            PlayerSeat(
                seatId = SessionCostCalculator.nextSeatId("seat"),
                displayName = seatName,
                customerCode = seatCode,
                joinedAtMillis = startTimeMillis
            )
        }
        return Pair(seats, anonCounter)
    }

    suspend fun startSessionWithDuration(
        system: GameSystemEntity,
        playerCount: Int,
        durationMinutes: Int,
        customerName: String = "",
        startTimeMillis: Long = System.currentTimeMillis()
    ): Long {
        if (isSystemBusy(system.id)) return -1L
        val matched = findCustomerByCodeOrName(customerName)
        val discount = matched?.discountPercent ?: 0
        val start = startTimeMillis
        val endTime = start + (durationMinutes * 60 * 1000L)
        val safePlayers = max(1, playerCount)
        val (seats, nextAnon) = buildInitialSeats(safePlayers, customerName, matched, start)
        val resolvedLabel = matched?.name ?: customerName
        val session = ActiveSessionEntity(
            systemId = system.id,
            systemDisplayName = system.displayName,
            playerCount = safePlayers,
            startTimeMillis = start,
            durationMinutes = durationMinutes,
            expectedEndTimeMillis = endTime,
            isCountDown = true,
            hourlyRateApplied = system.hourlyRatePerPlayer,
            snacksCost = 0,
            snacksDetail = "",
            customerName = resolvedLabel,
            discountPercent = discount,
            segmentsJson = "[]",
            currentSegmentStartMillis = start,
            playerSeatsJson = PlayerSeatCodec.encode(seats),
            modeConversionNotes = "",
            nextAnonCounter = nextAnon
        )
        return dao.insertSession(session)
    }

    suspend fun startSessionWithAmount(
        system: GameSystemEntity,
        playerCount: Int,
        targetAmountTomans: Long,
        customerName: String = "",
        startTimeMillis: Long = System.currentTimeMillis()
    ): Long {
        if (isSystemBusy(system.id)) return -1L
        val matched = findCustomerByCodeOrName(customerName)
        val discount = matched?.discountPercent ?: 0
        val start = startTimeMillis
        val safePlayers = max(1, playerCount)
        val ratePerHour = system.hourlyRatePerPlayer * safePlayers
        val durationMinutes = if (ratePerHour > 0) {
            max(5, ((targetAmountTomans.toDouble() / ratePerHour.toDouble()) * 60).toInt())
        } else {
            60
        }
        val endTime = start + (durationMinutes * 60 * 1000L)
        val (seats, nextAnon) = buildInitialSeats(safePlayers, customerName, matched, start)
        val resolvedLabel = matched?.name ?: customerName

        val session = ActiveSessionEntity(
            systemId = system.id,
            systemDisplayName = system.displayName,
            playerCount = safePlayers,
            startTimeMillis = start,
            durationMinutes = durationMinutes,
            expectedEndTimeMillis = endTime,
            isCountDown = true,
            hourlyRateApplied = system.hourlyRatePerPlayer,
            snacksCost = 0,
            snacksDetail = "",
            targetAmountTomans = targetAmountTomans,
            customerName = resolvedLabel,
            discountPercent = discount,
            segmentsJson = "[]",
            currentSegmentStartMillis = start,
            playerSeatsJson = PlayerSeatCodec.encode(seats),
            modeConversionNotes = "",
            nextAnonCounter = nextAnon
        )
        return dao.insertSession(session)
    }

    suspend fun startOpenEndedSession(
        system: GameSystemEntity,
        playerCount: Int,
        startTimeMillis: Long = System.currentTimeMillis(),
        customerName: String = ""
    ): Long {
        if (isSystemBusy(system.id)) return -1L
        val matched = findCustomerByCodeOrName(customerName)
        val discount = matched?.discountPercent ?: 0
        val safePlayers = max(1, playerCount)
        val (seats, nextAnon) = buildInitialSeats(safePlayers, customerName, matched, startTimeMillis)
        val resolvedLabel = matched?.name ?: customerName

        val session = ActiveSessionEntity(
            systemId = system.id,
            systemDisplayName = system.displayName,
            playerCount = safePlayers,
            startTimeMillis = startTimeMillis,
            durationMinutes = 0,
            expectedEndTimeMillis = 0,
            isCountDown = false,
            hourlyRateApplied = system.hourlyRatePerPlayer,
            snacksCost = 0,
            snacksDetail = "",
            customerName = resolvedLabel,
            discountPercent = discount,
            segmentsJson = "[]",
            currentSegmentStartMillis = startTimeMillis,
            playerSeatsJson = PlayerSeatCodec.encode(seats),
            modeConversionNotes = "",
            nextAnonCounter = nextAnon
        )
        return dao.insertSession(session)
    }

    suspend fun addSnackToSession(
        systemId: Int,
        snackName: String,
        count: Int = 1,
        targetSeatId: String? = null
    ): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val allSnacks = dao.getAllSnacksList()
        val found = allSnacks.firstOrNull {
            it.name.trim().contains(snackName.trim(), ignoreCase = true) ||
                snackName.trim().contains(it.name.trim(), ignoreCase = true)
        } ?: allSnacks.firstOrNull() ?: return false

        val itemPrice = found.priceTomans * count
        val newSnackCost = session.snacksCost + itemPrice
        val baseAdditionText = "${found.name} ×$count (${formatPrice(itemPrice)})"

        val seats = SessionCostCalculator.ensureSeats(session).toMutableList()
        val targetSeatIdx = if (!targetSeatId.isNullOrBlank()) {
            seats.indexOfFirst { it.seatId == targetSeatId }
        } else -1
        val targetSeatName = if (targetSeatIdx >= 0) seats[targetSeatIdx].displayName else ""

        val labelSuffix = if (targetSeatIdx >= 0) " [$targetSeatName]" else ""
        val additionText = "$baseAdditionText$labelSuffix"
        val newDetail = if (session.snacksDetail.isBlank()) additionText else "${session.snacksDetail}، $additionText"

        if (targetSeatIdx >= 0) {
            val s = seats[targetSeatIdx]
            val newSeatSnackDetail = if (s.currentSystemSnacksDetail.isBlank()) baseAdditionText else "${s.currentSystemSnacksDetail}، $baseAdditionText"
            seats[targetSeatIdx] = s.copy(
                currentSystemSnacksCost = s.currentSystemSnacksCost + itemPrice,
                currentSystemSnacksDetail = newSeatSnackDetail
            )
        }

        val currentLines = SessionSnackCodec.decode(session.snacksItemsJson).toMutableList()
        currentLines.add(
            SessionSnackLine(
                id = "snk_${System.currentTimeMillis()}_${(100..999).random()}",
                snackName = found.name,
                unitPrice = found.priceTomans,
                count = count,
                targetSeatId = if (targetSeatIdx >= 0) seats[targetSeatIdx].seatId else "",
                targetSeatName = targetSeatName
            )
        )

        dao.updateSession(
            session.copy(
                snacksCost = newSnackCost,
                snacksDetail = newDetail,
                playerSeatsJson = PlayerSeatCodec.encode(seats),
                snacksItemsJson = SessionSnackCodec.encode(currentLines)
            )
        )
        return true
    }

    suspend fun removeSnackLineFromSession(systemId: Int, lineId: String): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val lines = SessionSnackCodec.decode(session.snacksItemsJson)
        val target = lines.firstOrNull { it.id == lineId } ?: return false
        val remaining = lines.filterNot { it.id == lineId }

        val updatedTotalSnacksCost = max(0L, session.snacksCost - target.totalPrice)
        val rebuiltDetail = remaining.joinToString("، ") { item ->
            val base = "${item.snackName} ×${item.count} (${formatPrice(item.totalPrice)})"
            if (item.targetSeatName.isNotBlank()) "$base [${item.targetSeatName}]" else base
        }

        val seats = SessionCostCalculator.ensureSeats(session).map { seat ->
            if (target.targetSeatId.isNotBlank() && seat.seatId == target.targetSeatId) {
                val seatRemLines = remaining.filter { it.targetSeatId == seat.seatId }
                seat.copy(
                    currentSystemSnacksCost = max(0L, seat.currentSystemSnacksCost - target.totalPrice),
                    currentSystemSnacksDetail = seatRemLines.joinToString("، ") {
                        "${it.snackName} ×${it.count} (${formatPrice(it.totalPrice)})"
                    }
                )
            } else {
                seat
            }
        }

        dao.updateSession(
            session.copy(
                snacksCost = updatedTotalSnacksCost,
                snacksDetail = rebuiltDetail,
                playerSeatsJson = PlayerSeatCodec.encode(seats),
                snacksItemsJson = SessionSnackCodec.encode(remaining)
            )
        )
        return true
    }

    suspend fun updateSessionNote(systemId: Int, note: String): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        dao.updateSession(session.copy(sessionNote = note.trim()))
        return true
    }

    suspend fun updateSeatCustomerInfo(systemId: Int, seatId: String, newNameOrCode: String): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val trimmed = newNameOrCode.trim()
        if (trimmed.isBlank()) return false
        val matched = findCustomerByCodeOrName(trimmed)
        val resolvedName = matched?.name ?: trimmed
        val resolvedCode = matched?.customerCode ?: ""

        val seats = SessionCostCalculator.ensureSeats(session).toMutableList()
        val idx = seats.indexOfFirst { it.seatId == seatId }
        if (idx < 0) return false
        seats[idx] = seats[idx].copy(
            displayName = resolvedName,
            customerCode = resolvedCode
        )
        val updatedCustomerName = if (idx == 0 || seats.size == 1) resolvedName else session.customerName
        val updatedDiscount = if ((idx == 0 || seats.size == 1) && matched != null && matched.discountPercent > 0) {
            matched.discountPercent
        } else {
            session.discountPercent
        }
        dao.updateSession(
            session.copy(
                customerName = updatedCustomerName,
                discountPercent = updatedDiscount,
                playerSeatsJson = PlayerSeatCodec.encode(seats)
            )
        )
        return true
    }

    suspend fun modifySessionTimer(
        systemId: Int,
        additionalMinutes: Int
    ): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val currentEnd = if (session.expectedEndTimeMillis > 0) {
            session.expectedEndTimeMillis
        } else {
            System.currentTimeMillis()
        }
        val newEnd = currentEnd + (additionalMinutes * 60 * 1000L)
        val newDuration = max(1, session.durationMinutes + additionalMinutes)
        dao.updateSession(
            session.copy(
                expectedEndTimeMillis = newEnd,
                durationMinutes = newDuration,
                isCountDown = true,
                isAlarmDismissed = false
            )
        )
        return true
    }

    /**
     * Converts an active countdown session back into an open-ended timer from the original startTimeMillis.
     */
    suspend fun convertCountdownToOpen(systemId: Int): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val startStr = PersianDateUtils.formatTime(session.startTimeMillis)
        val convNote = "تبدیل معکوس به آزاد (از ساعت $startStr)"
        val mergedNotes = appendConversionNote(session.modeConversionNotes, convNote)
        dao.updateSession(
            session.copy(
                isCountDown = false,
                expectedEndTimeMillis = 0L,
                isAlarmDismissed = true,
                modeConversionNotes = mergedNotes
            )
        )
        return true
    }

    /**
     * Converts an open-ended (or existing) session into a countdown of [targetDurationMinutes],
     * subtracting time already played since startTimeMillis.
     */
    suspend fun convertOpenToCountdown(
        systemId: Int,
        targetDurationMinutes: Int,
        effectiveNowMillis: Long = System.currentTimeMillis()
    ): Pair<Boolean, String> {
        val session = dao.getSessionBySystemId(systemId) ?: return Pair(false, "سیستم فعال نیست")
        val now = if (session.isPaused && session.pausedAtMillis > 0L) session.pausedAtMillis else effectiveNowMillis
        val safeTargetMin = targetDurationMinutes.coerceAtLeast(1)
        val elapsedMillis = max(0L, now - session.startTimeMillis)
        val elapsedMin = (elapsedMillis / 60_000L).toInt()
        val remainingMillis = max(0L, (safeTargetMin * 60_000L) - elapsedMillis)
        val remainingMin = ceil(remainingMillis / 60_000.0).toInt()

        val convNote = "آزاد به معکوس (${safeTargetMin} د): کسر ${elapsedMin} د قبلی، باقیمانده ${remainingMin} د"
        dao.updateSession(
            session.copy(
                isCountDown = true,
                durationMinutes = safeTargetMin,
                expectedEndTimeMillis = now + remainingMillis,
                isAlarmDismissed = remainingMillis == 0L,
                modeConversionNotes = appendConversionNote(session.modeConversionNotes, convNote)
            )
        )
        val msg = if (remainingMillis == 0L) {
            "زمان ${safeTargetMin} دقیقه‌ای ${session.systemDisplayName} قبلاً سپری شده است."
        } else {
            "تایمر ${session.systemDisplayName} به معکوس (${remainingMin} دقیقه باقیمانده) تبدیل شد."
        }
        return Pair(true, msg)
    }

    /**
     * Converts a session to Amount-based countdown: computes equivalent total minutes for [amountTomans],
     * subtracts elapsed played time, and sets countdown for remaining duration.
     */
    suspend fun convertAmountToTime(
        systemId: Int,
        amountTomans: Long,
        effectiveNowMillis: Long = System.currentTimeMillis()
    ): Pair<Boolean, String> {
        val session = dao.getSessionBySystemId(systemId) ?: return Pair(false, "سیستم فعال نیست")
        val now = if (session.isPaused && session.pausedAtMillis > 0L) session.pausedAtMillis else effectiveNowMillis
        val ratePerHour = max(1L, session.hourlyRateApplied * max(1, session.playerCount))
        val totalEquivMinutes = ((amountTomans.toDouble() / ratePerHour.toDouble()) * 60.0).roundToInt().coerceAtLeast(1)
        val elapsedMillis = max(0L, now - session.startTimeMillis)
        val elapsedMin = (elapsedMillis / 60_000L).toInt()
        val remainingMillis = max(0L, (totalEquivMinutes * 60_000L) - elapsedMillis)
        val remainingMin = ceil(remainingMillis / 60_000.0).toInt()

        val convNote = "مبلغ به تایم (${formatPrice(amountTomans)} ت = ${totalEquivMinutes} د): کسر ${elapsedMin} د قبلی، باقیمانده ${remainingMin} د"
        dao.updateSession(
            session.copy(
                isCountDown = true,
                targetAmountTomans = amountTomans,
                durationMinutes = totalEquivMinutes,
                expectedEndTimeMillis = now + remainingMillis,
                isAlarmDismissed = remainingMillis == 0L,
                modeConversionNotes = appendConversionNote(session.modeConversionNotes, convNote)
            )
        )
        val msg = "مبلغ ${formatPrice(amountTomans)} ت معادل ${totalEquivMinutes} د تنظیم شد (${remainingMin} دقیقه باقیمانده)."
        return Pair(true, msg)
    }

    private fun appendConversionNote(existing: String, addition: String): String {
        return if (existing.isBlank()) addition else "$existing | $addition"
    }

    /**
     * Updates player count retro-actively from the beginning of the session («از ابتدا»).
     */
    suspend fun updateSessionPlayersFromStart(
        systemId: Int,
        newPlayerCount: Int,
        addedNames: List<String> = emptyList()
    ): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val safePlayers = newPlayerCount.coerceIn(1, 8)
        val existingSeats = SessionCostCalculator.ensureSeats(session).toMutableList()
        var anonCounter = session.nextAnonCounter

        if (safePlayers > existingSeats.size) {
            val needed = safePlayers - existingSeats.size
            for (i in 0 until needed) {
                val rawName = addedNames.getOrNull(i)?.trim().orEmpty()
                val matched = if (rawName.isNotBlank()) findCustomerByCodeOrName(rawName) else null
                val finalName = matched?.name ?: rawName.ifBlank {
                    "ناشناس ${toPersianDigits(anonCounter++)}"
                }
                existingSeats.add(
                    PlayerSeat(
                        seatId = SessionCostCalculator.nextSeatId("seat"),
                        displayName = finalName,
                        customerCode = matched?.customerCode ?: "",
                        joinedAtMillis = session.startTimeMillis
                    )
                )
            }
        } else if (safePlayers < existingSeats.size) {
            while (existingSeats.size > safePlayers) {
                existingSeats.removeAt(existingSeats.lastIndex)
            }
        }

        val updatedSegments = SessionSegmentCodec.decode(session.segmentsJson).map { seg ->
            seg.copy(
                playerCount = safePlayers,
                costTomans = ((seg.playedMinutes / 60.0) * (seg.hourlyRatePerPlayer * safePlayers)).toLong(),
                seatIds = existingSeats.map { it.seatId }
            )
        }

        dao.updateSession(
            session.copy(
                playerCount = safePlayers,
                segmentsJson = SessionSegmentCodec.encode(updatedSegments),
                playerSeatsJson = PlayerSeatCodec.encode(existingSeats),
                nextAnonCounter = anonCounter,
                modeConversionNotes = appendConversionNote(session.modeConversionNotes, "اصلاح به $safePlayers نفر از ابتدا")
            )
        )
        return true
    }

    /**
     * Records a completed segment up to [changeTimeMillis] before updating playerCount from NOW.
     */
    suspend fun updateSessionPlayers(
        systemId: Int,
        newPlayerCount: Int,
        changeTimeMillis: Long = System.currentTimeMillis()
    ): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val safePlayers = newPlayerCount.coerceIn(1, 8)
        if (safePlayers == session.playerCount) return true

        val effectiveTime = if (session.isPaused && session.pausedAtMillis > 0L) {
            session.pausedAtMillis
        } else {
            changeTimeMillis
        }
        val seats = SessionCostCalculator.ensureSeats(session).toMutableList()
        var anonCounter = session.nextAnonCounter

        val existingSegments = SessionSegmentCodec.decode(session.segmentsJson).toMutableList()
        val outgoingSegment = SessionCostCalculator.buildSegmentForTransition(
            session = session,
            transitionMillis = effectiveTime,
            note = "تغییر به $safePlayers نفره"
        )
        if (outgoingSegment.playedMinutes > 0 || outgoingSegment.costTomans > 0L) {
            existingSegments.add(outgoingSegment)
        }

        if (safePlayers > seats.size) {
            for (i in seats.size until safePlayers) {
                seats.add(
                    PlayerSeat(
                        seatId = SessionCostCalculator.nextSeatId("seat"),
                        displayName = "ناشناس ${toPersianDigits(anonCounter++)}",
                        joinedAtMillis = effectiveTime
                    )
                )
            }
        } else {
            while (seats.size > safePlayers) {
                seats.removeAt(seats.lastIndex)
            }
        }

        dao.updateSession(
            session.copy(
                playerCount = safePlayers,
                segmentsJson = SessionSegmentCodec.encode(existingSegments),
                currentSegmentStartMillis = effectiveTime,
                playerSeatsJson = PlayerSeatCodec.encode(seats),
                nextAnonCounter = anonCounter
            )
        )
        return true
    }

    /**
     * Adds named (or auto-named ناشناس X) players starting from NOW («از الان»).
     */
    suspend fun addPlayersFromNow(
        systemId: Int,
        addedNames: List<String>,
        changeTimeMillis: Long = System.currentTimeMillis()
    ): Boolean {
        if (addedNames.isEmpty()) return false
        val session = dao.getSessionBySystemId(systemId) ?: return false
        val effectiveTime = if (session.isPaused && session.pausedAtMillis > 0L) {
            session.pausedAtMillis
        } else {
            changeTimeMillis
        }
        val seats = SessionCostCalculator.ensureSeats(session).toMutableList()
        var anonCounter = session.nextAnonCounter

        val existingSegments = SessionSegmentCodec.decode(session.segmentsJson).toMutableList()
        val newTotal = (seats.size + addedNames.size).coerceAtMost(8)
        val outgoingSegment = SessionCostCalculator.buildSegmentForTransition(
            session = session,
            transitionMillis = effectiveTime,
            note = "افزودن نفر جدید از الان (جمع $newTotal نفر)"
        )
        if (outgoingSegment.playedMinutes > 0 || outgoingSegment.costTomans > 0L) {
            existingSegments.add(outgoingSegment)
        }

        addedNames.take(8 - seats.size).forEachIndexed { idx, rawInput ->
            val trimmed = rawInput.trim()
            val matched = if (trimmed.isNotBlank()) findCustomerByCodeOrName(trimmed) else null
            val finalName = matched?.name ?: trimmed.ifBlank {
                "ناشناس ${toPersianDigits(anonCounter++)}"
            }
            seats.add(
                PlayerSeat(
                    seatId = SessionCostCalculator.nextSeatId("add"),
                    displayName = finalName,
                    customerCode = matched?.customerCode ?: "",
                    joinedAtMillis = effectiveTime
                )
            )
        }

        dao.updateSession(
            session.copy(
                playerCount = seats.size,
                segmentsJson = SessionSegmentCodec.encode(existingSegments),
                currentSegmentStartMillis = effectiveTime,
                playerSeatsJson = PlayerSeatCodec.encode(seats),
                nextAnonCounter = anonCounter
            )
        )
        return true
    }

    /**
     * Prepares a Mini Checkout receipt for a departing player mid-game without mutating DB yet.
     */
    suspend fun prepareMiniCheckoutForSeat(
        systemId: Int,
        departingSeatId: String,
        nowMillis: Long = System.currentTimeMillis()
    ): MiniPlayerCheckoutData? {
        val session = dao.getSessionBySystemId(systemId) ?: return null
        val effectiveNow = if (session.isPaused && session.pausedAtMillis > 0L) {
            session.pausedAtMillis
        } else {
            nowMillis
        }
        val breakdowns = SessionCostCalculator.calculateSeatBreakdowns(session, effectiveNow, forFinalReceipt = true)
        val targetBreakdown = breakdowns.firstOrNull { it.seat.seatId == departingSeatId }
            ?: breakdowns.lastOrNull()
            ?: return null

        val seat = targetBreakdown.seat
        val dateIso = PersianDateUtils.formatJalaliDateTime(effectiveNow)
        val snacksCost = targetBreakdown.priorSnacksFee + targetBreakdown.assignedSnacksFee + targetBreakdown.sharedSnacksShare
        val gameFee = max(0L, targetBreakdown.totalShare - snacksCost)
        val snackDesc = buildList {
            if (seat.priorSnacksDetail.isNotBlank()) add(seat.priorSnacksDetail)
            if (seat.currentSystemSnacksDetail.isNotBlank()) add(seat.currentSystemSnacksDetail)
            if (targetBreakdown.sharedSnacksShare > 0L) add("سهم خوراکی مشترک (${formatPrice(targetBreakdown.sharedSnacksShare)})")
        }.joinToString(" | ")

        val preview = GameHistoryEntity(
            systemId = session.systemId,
            systemDisplayName = "${session.systemDisplayName} (خروج ${seat.displayName})",
            playerCount = 1,
            startTimeMillis = if (seat.joinedAtMillis > 0L) seat.joinedAtMillis else session.startTimeMillis,
            endTimeMillis = effectiveNow,
            playedMinutes = targetBreakdown.playedMinutes,
            gameFee = gameFee,
            snacksFee = snacksCost,
            totalFee = targetBreakdown.totalShare,
            snacksDetail = snackDesc,
            customerName = seat.displayName,
            dateIso = dateIso,
            createdAtMillis = effectiveNow,
            discountPercent = session.discountPercent,
            discountAmount = targetBreakdown.discountAmount,
            entryType = "GAME"
        )

        return MiniPlayerCheckoutData(
            systemId = session.systemId,
            systemDisplayName = session.systemDisplayName,
            departingSeat = seat,
            breakdown = targetBreakdown,
            previewHistory = preview,
            snapshotTimeMillis = effectiveNow
        )
    }

    /**
     * Commits departing player's mini checkout (Paid or Debt), deducts that player's slice & snacks from
     * the main active session, logs stats or consolidated debt, and continues game with remaining players.
     */
    suspend fun finalizeDepartingPlayerCheckout(
        checkout: MiniPlayerCheckoutData,
        editedHistory: GameHistoryEntity,
        settleAsDebt: Boolean,
        customerInput: String,
        cashPaidTomans: Long = 0L,
        cardPaidTomans: Long = 0L
    ): Boolean {
        val session = dao.getSessionBySystemId(checkout.systemId) ?: return false
        val seats = SessionCostCalculator.ensureSeats(session)
        val departingId = checkout.departingSeat.seatId

        val snapshotTime = checkout.snapshotTimeMillis
        val allSegments = SessionSegmentCodec.decode(session.segmentsJson).toMutableList()
        val currentSeg = SessionCostCalculator.buildSegmentForTransition(
            session = session,
            transitionMillis = snapshotTime,
            note = "تسویه میان‌دوره‌ای ${checkout.departingSeat.displayName}"
        )
        if (currentSeg.playedMinutes > 0 || currentSeg.costTomans > 0L) {
            allSegments.add(currentSeg)
        }

        // Remove departing seat's slice from segments so remaining players only owe their own shares
        val remainingSegments = mutableListOf<SessionSegment>()
        for (seg in allSegments) {
            val participants = if (seg.seatIds.isNotEmpty()) seg.seatIds else seats.map { it.seatId }
            if (departingId in participants) {
                val slice = seg.costTomans / max(1, participants.size)
                val updatedIds = participants.filter { it != departingId }
                if (updatedIds.isNotEmpty()) {
                    remainingSegments.add(
                        seg.copy(
                            costTomans = max(0L, seg.costTomans - slice),
                            playerCount = updatedIds.size,
                            seatIds = updatedIds
                        )
                    )
                }
            } else {
                remainingSegments.add(seg)
            }
        }

        // Deduct departing seat's current-system snack share from active session
        val totalAssigned = seats.sumOf { it.currentSystemSnacksCost }
        val sharedPool = max(0L, session.snacksCost - totalAssigned)
        val sharedPerSeat = if (seats.isNotEmpty()) sharedPool / seats.size else 0L
        val snackDeduct = checkout.departingSeat.currentSystemSnacksCost + sharedPerSeat
        val updatedSessionSnacksCost = max(0L, session.snacksCost - snackDeduct)

        // Persist the departing player's invoice (Paid -> Stats, or Debt -> Consolidated Accounting)
        val resolvedCustomer = customerInput.trim().ifBlank { checkout.departingSeat.displayName }
        if (settleAsDebt) {
            registerReceiptAsDebt(
                editedHistory = editedHistory,
                customerInput = resolvedCustomer,
                cashPaidTomans = cashPaidTomans,
                debtSettlementAmountTomans = 0L,
                cardPaidTomans = cardPaidTomans
            )
        } else {
            completePaidReceipt(
                editedHistory = editedHistory,
                cashPaidTomans = cashPaidTomans,
                debtSettlementAmountTomans = 0L,
                customerCodeOrName = resolvedCustomer,
                cardPaidTomans = cardPaidTomans
            )
        }

        val remainingSeats = seats.filter { it.seatId != departingId }
        if (remainingSeats.isEmpty()) {
            dao.deleteSession(session)
        } else {
            dao.updateSession(
                session.copy(
                    playerCount = remainingSeats.size,
                    segmentsJson = SessionSegmentCodec.encode(remainingSegments),
                    currentSegmentStartMillis = snapshotTime,
                    snacksCost = updatedSessionSnacksCost,
                    playerSeatsJson = PlayerSeatCodec.encode(remainingSeats)
                )
            )
        }
        return true
    }

    /**
     * Transfers an active session from [fromSystemId] to an idle [targetSystem],
     * recording the elapsed time/cost on the old system and continuing on the new system.
     */
    suspend fun transferSessionToSystem(
        fromSystemId: Int,
        targetSystem: GameSystemEntity,
        transferTimeMillis: Long = System.currentTimeMillis()
    ): Boolean {
        val result = transferOrMergePlayers(
            fromSystemId = fromSystemId,
            selectedSeatIdsOrNullForAll = null,
            customerNameOrCode = "",
            targetSystem = targetSystem,
            transferTimeMillis = transferTimeMillis
        )
        return result.success
    }

    /**
     * Unified transfer engine supporting:
     * 1. Whole session transfer to an idle system (preserves segment list & countdown timers).
     * 2. Partial or full player transfer & MERGE into an ALREADY BUSY system, preserving prior invoices
     *    per player on the target system and deducting transferred slices from the source system.
     */
    suspend fun transferOrMergePlayers(
        fromSystemId: Int,
        selectedSeatIdsOrNullForAll: List<String>?,
        customerNameOrCode: String,
        targetSystem: GameSystemEntity,
        transferTimeMillis: Long = System.currentTimeMillis()
    ): TransferExecutionResult {
        if (fromSystemId == targetSystem.id) {
            return TransferExecutionResult(false, targetSystem.id, targetSystem.displayName, "سیستم مبدا و مقصد یکسان است.")
        }
        val sourceSession = dao.getSessionBySystemId(fromSystemId)
            ?: return TransferExecutionResult(false, targetSystem.id, targetSystem.displayName, "سیستم مبدا بازی فعالی ندارد.")

        val effectiveTime = if (sourceSession.isPaused && sourceSession.pausedAtMillis > 0L) {
            sourceSession.pausedAtMillis
        } else {
            transferTimeMillis
        }

        val sourceSeats = SessionCostCalculator.ensureSeats(sourceSession)
        val seatsToMove = if (selectedSeatIdsOrNullForAll == null) {
            sourceSeats
        } else {
            sourceSeats.filter { it.seatId in selectedSeatIdsOrNullForAll }
        }
        if (seatsToMove.isEmpty()) {
            return TransferExecutionResult(false, targetSystem.id, targetSystem.displayName, "هیچ بازیکنی برای انتقال انتخاب نشد.")
        }

        val targetSession = dao.getSessionBySystemId(targetSystem.id)
        val matchedCust = if (customerNameOrCode.isNotBlank()) findCustomerByCodeOrName(customerNameOrCode) else null
        var anonCounter = max(sourceSession.nextAnonCounter, targetSession?.nextAnonCounter ?: 1)

        // FAST PATH: Whole session move into an IDLE target system
        if (targetSession == null && seatsToMove.size == sourceSeats.size) {
            val existingSegments = SessionSegmentCodec.decode(sourceSession.segmentsJson).toMutableList()
            val outgoingSegment = SessionCostCalculator.buildSegmentForTransition(
                session = sourceSession,
                transitionMillis = effectiveTime,
                note = "انتقال به ${targetSystem.displayName}"
            )
            existingSegments.add(outgoingSegment)

            val updatedSeats = sourceSeats.mapIndexed { index, seat ->
                val assignedName = when {
                    index == 0 && customerNameOrCode.isNotBlank() -> matchedCust?.name ?: customerNameOrCode.trim()
                    seat.displayName.isBlank() -> "ناشناس ${toPersianDigits(anonCounter++)}"
                    else -> seat.displayName
                }
                val assignedCode = if (index == 0 && matchedCust != null) matchedCust.customerCode else seat.customerCode
                seat.copy(displayName = assignedName, customerCode = assignedCode)
            }
            val newCustomerLabel = if (customerNameOrCode.isNotBlank()) {
                matchedCust?.name ?: customerNameOrCode.trim()
            } else {
                sourceSession.customerName
            }

            val sourceRate = max(1L, sourceSession.hourlyRateApplied)
            val targetRate = max(1L, targetSystem.hourlyRatePerPlayer)
            var updatedExpectedEnd = sourceSession.expectedEndTimeMillis
            var updatedDuration = sourceSession.durationMinutes
            var updatedAlarmDismissed = sourceSession.isAlarmDismissed
            var updatedNotes = sourceSession.modeConversionNotes

            if (sourceSession.isCountDown && sourceSession.expectedEndTimeMillis > 0L) {
                val sourceRemMillis = max(0L, sourceSession.expectedEndTimeMillis - effectiveTime)
                val convertedRemMillis = if (sourceRate == targetRate) {
                    sourceRemMillis
                } else {
                    ((sourceRemMillis.toDouble() * sourceRate.toDouble()) / targetRate.toDouble()).roundToLong()
                }
                updatedExpectedEnd = effectiveTime + convertedRemMillis
                updatedDuration = ceil(convertedRemMillis / 60_000.0).toInt().coerceAtLeast(1)
                updatedAlarmDismissed = convertedRemMillis == 0L
                if (sourceRate != targetRate) {
                    val srcMins = ceil(sourceRemMillis / 60_000.0).toInt()
                    val convNote = "تبدیل نرخ تایمر (${formatPrice(sourceRate)} ← ${formatPrice(targetRate)} ت): ${srcMins} د ← ${updatedDuration} د"
                    updatedNotes = appendConversionNote(updatedNotes, convNote)
                }
            } else if (sourceRate != targetRate) {
                val convNote = "تغییر نرخ تایمر آزاد از ${formatPrice(sourceRate)} به ${formatPrice(targetRate)} ت"
                updatedNotes = appendConversionNote(updatedNotes, convNote)
            }

            dao.updateSession(
                sourceSession.copy(
                    systemId = targetSystem.id,
                    systemDisplayName = targetSystem.displayName,
                    hourlyRateApplied = targetSystem.hourlyRatePerPlayer,
                    expectedEndTimeMillis = updatedExpectedEnd,
                    durationMinutes = updatedDuration,
                    isAlarmDismissed = updatedAlarmDismissed,
                    customerName = newCustomerLabel,
                    segmentsJson = SessionSegmentCodec.encode(existingSegments),
                    currentSegmentStartMillis = effectiveTime,
                    playerSeatsJson = PlayerSeatCodec.encode(updatedSeats),
                    modeConversionNotes = updatedNotes,
                    nextAnonCounter = anonCounter
                )
            )
            return TransferExecutionResult(
                success = true,
                targetSystemId = targetSystem.id,
                targetSystemName = targetSystem.displayName,
                message = "بازی با حفظ زمان و فاکتور به ${targetSystem.displayName} منتقل شد."
            )
        }

        // MERGE OR PARTIAL TRANSFER PATH
        val sourceAllSegments = SessionSegmentCodec.decode(sourceSession.segmentsJson).toMutableList()
        val outgoingSourceSeg = SessionCostCalculator.buildSegmentForTransition(
            session = sourceSession,
            transitionMillis = effectiveTime,
            note = "انتقال از ${sourceSession.systemDisplayName} به ${targetSystem.displayName}"
        )
        if (outgoingSourceSeg.playedMinutes > 0 || outgoingSourceSeg.costTomans > 0L) {
            sourceAllSegments.add(outgoingSourceSeg)
        }

        val totalAssignedSourceSnacks = sourceSeats.sumOf { it.currentSystemSnacksCost }
        val sharedSourceSnackPool = max(0L, sourceSession.snacksCost - totalAssignedSourceSnacks)
        val sharedSourcePerSeat = if (sourceSeats.isNotEmpty()) sharedSourceSnackPool / sourceSeats.size else 0L

        val movingSeatIds = seatsToMove.map { it.seatId }.toSet()
        val preparedMovingSeats = mutableListOf<PlayerSeat>()

        seatsToMove.forEachIndexed { idx, seat ->
            val seatLabel = when {
                (seatsToMove.size == 1 || idx == 0) && customerNameOrCode.isNotBlank() ->
                    matchedCust?.name ?: customerNameOrCode.trim()
                seat.displayName.isBlank() || seat.displayName.startsWith("نفر ") ->
                    "ناشناس ${toPersianDigits(anonCounter++)}"
                else -> seat.displayName
            }
            val seatCode = if ((seatsToMove.size == 1 || idx == 0) && matchedCust != null) {
                matchedCust.customerCode
            } else seat.customerCode

            val newMergedSeatId = SessionCostCalculator.nextSeatId("merged")
            val extractedSlices = mutableListOf<SessionSegment>()
            extractedSlices.addAll(seat.priorSegments)

            sourceAllSegments.forEach { seg ->
                val participants = if (seg.seatIds.isNotEmpty()) seg.seatIds else sourceSeats.map { it.seatId }
                if (seat.seatId in participants && participants.isNotEmpty()) {
                    val sliceCost = seg.costTomans / participants.size
                    if (sliceCost > 0L || seg.playedMinutes > 0) {
                        extractedSlices.add(
                            seg.copy(
                                playerCount = 1,
                                costTomans = sliceCost,
                                note = "انتقال از ${seg.systemDisplayName} ($seatLabel)",
                                seatIds = listOf(newMergedSeatId)
                            )
                        )
                    }
                }
            }

            val carrySnacksCost = seat.priorSnacksCost + seat.currentSystemSnacksCost + sharedSourcePerSeat
            val carrySnacksDetail = buildList {
                if (seat.priorSnacksDetail.isNotBlank()) add(seat.priorSnacksDetail)
                if (seat.currentSystemSnacksDetail.isNotBlank()) add(seat.currentSystemSnacksDetail)
                if (sharedSourcePerSeat > 0L) add("سهم بوفه ${sourceSession.systemDisplayName} (${formatPrice(sharedSourcePerSeat)})")
            }.joinToString(" | ")

            preparedMovingSeats.add(
                PlayerSeat(
                    seatId = newMergedSeatId,
                    displayName = seatLabel,
                    customerCode = seatCode,
                    joinedAtMillis = effectiveTime,
                    priorSegments = extractedSlices,
                    priorSnacksCost = carrySnacksCost,
                    priorSnacksDetail = carrySnacksDetail,
                    currentSystemSnacksCost = 0L,
                    currentSystemSnacksDetail = ""
                )
            )
        }

        // Deduct transferred seats from sourceSession
        val stayingSeats = sourceSeats.filter { it.seatId !in movingSeatIds }
        if (stayingSeats.isEmpty()) {
            dao.deleteSession(sourceSession)
        } else {
            val updatedSourceSegments = mutableListOf<SessionSegment>()
            for (seg in sourceAllSegments) {
                val participants = if (seg.seatIds.isNotEmpty()) seg.seatIds else sourceSeats.map { it.seatId }
                val stayingInSeg = participants.filter { it !in movingSeatIds }
                val movedCount = participants.size - stayingInSeg.size
                if (stayingInSeg.isNotEmpty()) {
                    val slice = seg.costTomans / max(1, participants.size)
                    updatedSourceSegments.add(
                        seg.copy(
                            costTomans = max(0L, seg.costTomans - (slice * movedCount)),
                            playerCount = stayingInSeg.size,
                            seatIds = stayingInSeg
                        )
                    )
                }
            }
            val snacksRemovedFromSource = seatsToMove.sumOf { it.currentSystemSnacksCost + sharedSourcePerSeat }
            dao.updateSession(
                sourceSession.copy(
                    playerCount = stayingSeats.size,
                    segmentsJson = SessionSegmentCodec.encode(updatedSourceSegments),
                    currentSegmentStartMillis = effectiveTime,
                    snacksCost = max(0L, sourceSession.snacksCost - snacksRemovedFromSource),
                    playerSeatsJson = PlayerSeatCodec.encode(stayingSeats),
                    nextAnonCounter = anonCounter
                )
            )
        }

        // Insert or merge into targetSystem
        if (targetSession != null) {
            val targetSeats = SessionCostCalculator.ensureSeats(targetSession)
            val targetSegments = SessionSegmentCodec.decode(targetSession.segmentsJson).toMutableList()
            val segBeforeJoin = SessionCostCalculator.buildSegmentForTransition(
                session = targetSession,
                transitionMillis = effectiveTime,
                note = "اضافه شدن ${preparedMovingSeats.joinToString("، ") { it.displayName }} از ${sourceSession.systemDisplayName}"
            )
            if (segBeforeJoin.playedMinutes > 0 || segBeforeJoin.costTomans > 0L) {
                targetSegments.add(segBeforeJoin)
            }
            val combinedSeats = targetSeats + preparedMovingSeats
            val mergeNote = "ورود ${preparedMovingSeats.joinToString("، ") { it.displayName }} از ${sourceSession.systemDisplayName}"
            dao.updateSession(
                targetSession.copy(
                    playerCount = combinedSeats.size,
                    segmentsJson = SessionSegmentCodec.encode(targetSegments),
                    currentSegmentStartMillis = effectiveTime,
                    playerSeatsJson = PlayerSeatCodec.encode(combinedSeats),
                    nextAnonCounter = anonCounter,
                    modeConversionNotes = appendConversionNote(targetSession.modeConversionNotes, mergeNote)
                )
            )
            return TransferExecutionResult(
                success = true,
                targetSystemId = targetSystem.id,
                targetSystemName = targetSystem.displayName,
                message = "${preparedMovingSeats.joinToString("، ") { it.displayName }} با فاکتور قبلی به ${targetSystem.displayName} منتقل و ادغام شد."
            )
        } else {
            val sourceRate = max(1L, sourceSession.hourlyRateApplied)
            val targetRate = max(1L, targetSystem.hourlyRatePerPlayer)
            val keepCountdown = sourceSession.isCountDown && sourceSession.expectedEndTimeMillis > effectiveTime
            val sourceRemMillis = if (keepCountdown) max(0L, sourceSession.expectedEndTimeMillis - effectiveTime) else 0L
            val convertedRemMillis = if (keepCountdown) {
                if (sourceRate == targetRate) sourceRemMillis
                else ((sourceRemMillis.toDouble() * sourceRate.toDouble()) / targetRate.toDouble()).roundToLong()
            } else 0L
            val newExpectedEnd = if (keepCountdown) effectiveTime + convertedRemMillis else 0L
            val newDuration = if (keepCountdown) ceil(convertedRemMillis / 60_000.0).toInt().coerceAtLeast(1) else 0
            val transferNote = if (keepCountdown && sourceRate != targetRate) {
                "انتقال از ${sourceSession.systemDisplayName} | تبدیل نرخ (${formatPrice(sourceRate)} ← ${formatPrice(targetRate)} ت): ${ceil(sourceRemMillis / 60_000.0).toInt()} د ← ${newDuration} د"
            } else if (sourceRate != targetRate) {
                "انتقال از ${sourceSession.systemDisplayName} (تغییر نرخ ${formatPrice(sourceRate)} ← ${formatPrice(targetRate)} ت)"
            } else {
                "انتقال از ${sourceSession.systemDisplayName}"
            }

            val newSession = ActiveSessionEntity(
                systemId = targetSystem.id,
                systemDisplayName = targetSystem.displayName,
                playerCount = preparedMovingSeats.size,
                startTimeMillis = effectiveTime,
                durationMinutes = newDuration,
                expectedEndTimeMillis = newExpectedEnd,
                isCountDown = keepCountdown,
                hourlyRateApplied = targetSystem.hourlyRatePerPlayer,
                snacksCost = 0L,
                snacksDetail = "",
                customerName = preparedMovingSeats.firstOrNull()?.displayName ?: "",
                discountPercent = sourceSession.discountPercent,
                segmentsJson = "[]",
                currentSegmentStartMillis = effectiveTime,
                playerSeatsJson = PlayerSeatCodec.encode(preparedMovingSeats),
                modeConversionNotes = transferNote,
                nextAnonCounter = anonCounter
            )
            dao.insertSession(newSession)
            return TransferExecutionResult(
                success = true,
                targetSystemId = targetSystem.id,
                targetSystemName = targetSystem.displayName,
                message = "بازیکن انتخاب‌شده با فاکتور قبلی به ${targetSystem.displayName} منتقل شد."
            )
        }
    }

    suspend fun pauseSession(systemId: Int): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        if (session.isPaused) return true
        dao.updateSession(
            session.copy(
                isPaused = true,
                pausedAtMillis = System.currentTimeMillis(),
                isAlarmDismissed = true
            )
        )
        return true
    }

    suspend fun resumeSession(systemId: Int): Boolean {
        val session = dao.getSessionBySystemId(systemId) ?: return false
        if (!session.isPaused) return true
        val now = System.currentTimeMillis()
        val pausedDelta = if (session.pausedAtMillis > 0L) max(0L, now - session.pausedAtMillis) else 0L
        val newStart = session.startTimeMillis + pausedDelta
        val oldSegStart = if (session.currentSegmentStartMillis > 0L) session.currentSegmentStartMillis else session.startTimeMillis
        val newSegStart = oldSegStart + pausedDelta
        val newExpectedEnd = if (session.isCountDown && session.expectedEndTimeMillis > 0L) {
            session.expectedEndTimeMillis + pausedDelta
        } else {
            session.expectedEndTimeMillis
        }
        dao.updateSession(
            session.copy(
                startTimeMillis = newStart,
                currentSegmentStartMillis = newSegStart,
                expectedEndTimeMillis = newExpectedEnd,
                isPaused = false,
                pausedAtMillis = 0L,
                isAlarmDismissed = false
            )
        )
        return true
    }

    suspend fun prepareFinishSession(
        systemId: Int,
        endTimeMillis: Long = System.currentTimeMillis()
    ): Pair<GameHistoryEntity, ActiveSessionEntity>? {
        val session = dao.getSessionBySystemId(systemId) ?: return null
        val effectiveEnd = if (session.isPaused && session.pausedAtMillis > 0L) {
            session.pausedAtMillis
        } else {
            endTimeMillis
        }

        val seats = SessionCostCalculator.ensureSeats(session)
        val billing = SessionCostCalculator.calculateLiveBilling(
            session = session,
            effectiveNowMillis = effectiveEnd,
            forFinalReceipt = true
        )

        val allSegments = billing.completedSegments.toMutableList()
        val finalElapsed = max(0L, effectiveEnd - billing.currentSegmentStartMillis)
        val finalHourly = session.hourlyRateApplied * session.playerCount
        val finalSegMin: Int
        val finalSegCost: Long
        if (allSegments.isEmpty()) {
            val effectiveElapsed = max(60_000L, finalElapsed)
            finalSegMin = (effectiveElapsed / 60_000.0).roundToInt().coerceAtLeast(1)
            finalSegCost = ((effectiveElapsed / 3_600_000.0) * finalHourly).roundToLong()
        } else if (finalElapsed < 10_000L) {
            finalSegMin = 0
            finalSegCost = 0L
        } else {
            finalSegMin = (finalElapsed / 60_000.0).roundToInt().coerceAtLeast(1)
            finalSegCost = ((finalElapsed / 3_600_000.0) * finalHourly).roundToLong()
        }
        if (allSegments.isNotEmpty() || finalSegMin > 0 || finalSegCost > 0L) {
            allSegments.add(
                SessionSegment(
                    systemId = session.systemId,
                    systemDisplayName = session.systemDisplayName,
                    playerCount = session.playerCount,
                    hourlyRatePerPlayer = session.hourlyRateApplied,
                    startTimeMillis = billing.currentSegmentStartMillis,
                    endTimeMillis = effectiveEnd,
                    playedMinutes = finalSegMin,
                    costTomans = finalSegCost,
                    note = if (allSegments.isEmpty()) "بازی عادی" else "مرحله پایانی",
                    seatIds = seats.map { it.seatId }
                )
            )
        }

        val priorSnacksTotal = seats.sumOf { it.priorSnacksCost }
        val totalSnacksFee = session.snacksCost + priorSnacksTotal
        val combinedSnacksDetail = buildList {
            if (session.snacksDetail.isNotBlank()) add(session.snacksDetail)
            seats.forEach { s ->
                if (s.priorSnacksDetail.isNotBlank()) add("انتقالی (${s.displayName}): ${s.priorSnacksDetail}")
            }
        }.joinToString(" | ")

        val dateIso = PersianDateUtils.formatJalaliDateTime(effectiveEnd)

        val history = GameHistoryEntity(
            systemId = session.systemId,
            systemDisplayName = session.systemDisplayName,
            playerCount = session.playerCount,
            startTimeMillis = session.startTimeMillis,
            endTimeMillis = effectiveEnd,
            playedMinutes = billing.totalPlayedMinutes,
            gameFee = billing.discountedGameFee,
            snacksFee = totalSnacksFee,
            totalFee = billing.totalFeeWithSnacks,
            snacksDetail = combinedSnacksDetail,
            customerName = session.customerName,
            dateIso = dateIso,
            createdAtMillis = effectiveEnd,
            discountPercent = session.discountPercent,
            discountAmount = billing.discountAmount,
            segmentsDetailJson = SessionSegmentCodec.encode(allSegments),
            entryType = "GAME",
            modeConversionNotes = session.modeConversionNotes,
            playerSeatsJson = PlayerSeatCodec.encode(seats),
            sessionNote = session.sessionNote
        )

        dao.deleteSession(session)
        return Pair(history, session)
    }

    suspend fun restoreCancelledSession(snapshot: ActiveSessionEntity): Long {
        val existing = dao.getSessionBySystemId(snapshot.systemId)
        if (existing != null) return existing.id
        return dao.insertSession(
            snapshot.copy(
                id = 0,
                isAlarmDismissed = true
            )
        )
    }

    suspend fun saveHistoryRecord(history: GameHistoryEntity): Long = dao.insertHistory(history)

    /**
     * Completes a paid receipt, supporting per-player partial Debt splits, POS Card (`cardPaidTomans`),
     * Cash Payment (`cashPaidTomans` -> CashEntryEntity), automatic Customer Credit deduction,
     * and past debt settlements.
     */
    suspend fun completePaidReceipt(
        editedHistory: GameHistoryEntity,
        cashPaidTomans: Long,
        debtSettlementAmountTomans: Long,
        customerCodeOrName: String,
        cardPaidTomans: Long = 0L,
        seatResolutions: List<SeatResolutionInput> = emptyList(),
        creditUsedTomans: Long = 0L
    ) {
        val now = System.currentTimeMillis()
        val resolvedCustomer = if (customerCodeOrName.isNotBlank()) {
            findCustomerByCodeOrName(customerCodeOrName)
        } else null
        val finalCustomerLabel = resolvedCustomer?.name ?: customerCodeOrName.ifBlank { editedHistory.customerName }

        if (creditUsedTomans > 0L && (resolvedCustomer != null || finalCustomerLabel.isNotBlank())) {
            consumeCustomerCredit(
                customerName = finalCustomerLabel,
                customerCode = resolvedCustomer?.customerCode ?: "",
                amountToConsume = creditUsedTomans
            )
        }

        // Deferred per-player seats go to consolidated Debts (excluded from Sales Stats total)
        val deferredSeats = seatResolutions.filter { it.status == "DEBT" && it.amountTomans > 0L }
        val deferredSum = deferredSeats.sumOf { it.amountTomans }

        deferredSeats.forEach { dSeat ->
            val targetCustomer = dSeat.customerInput.ifBlank { dSeat.displayName }
            val dHist = editedHistory.copy(
                id = 0,
                playerCount = 1,
                gameFee = dSeat.amountTomans,
                snacksFee = 0L,
                totalFee = dSeat.amountTomans,
                customerName = targetCustomer,
                snacksDetail = "سهم بازیکن ${dSeat.displayName} از ${editedHistory.systemDisplayName}"
            )
            registerReceiptAsDebt(
                editedHistory = dHist,
                customerInput = targetCustomer,
                cashPaidTomans = 0L,
                debtSettlementAmountTomans = 0L,
                cardPaidTomans = 0L
            )
        }

        val paidTotalFee = max(0L, editedHistory.totalFee - deferredSum)
        val paidGameFee = max(0L, paidTotalFee - minOf(paidTotalFee, editedHistory.snacksFee))
        val paidSnacksFee = paidTotalFee - paidGameFee
        val creditNote = if (creditUsedTomans > 0L) {
            appendConversionNote(editedHistory.modeConversionNotes, "کسر از طلب قبلی: ${formatPrice(creditUsedTomans)} ت")
        } else editedHistory.modeConversionNotes

        if (paidTotalFee > 0L || deferredSeats.isEmpty()) {
            dao.insertHistory(
                editedHistory.copy(
                    customerName = finalCustomerLabel,
                    gameFee = paidGameFee,
                    snacksFee = paidSnacksFee,
                    totalFee = paidTotalFee,
                    cashPaidTomans = cashPaidTomans,
                    cardPaidTomans = cardPaidTomans,
                    debtSettledTomans = debtSettlementAmountTomans,
                    entryType = "GAME",
                    modeConversionNotes = creditNote
                )
            )
        }

        // Only Cash goes to Daily Cash Ledger; POS Card does not enter Cash Drawer
        if (cashPaidTomans > 0L) {
            dao.insertCashEntry(
                CashEntryEntity(
                    amountTomans = cashPaidTomans,
                    note = "دریافت نقدی فاکتور ${editedHistory.systemDisplayName}",
                    customerName = finalCustomerLabel,
                    source = "RECEIPT",
                    createdAtMillis = editedHistory.createdAtMillis
                )
            )
        }

        if (debtSettlementAmountTomans > 0L && (resolvedCustomer != null || finalCustomerLabel.isNotBlank())) {
            settleCustomerDebtsPartialOrFull(
                customerName = finalCustomerLabel,
                customerCode = resolvedCustomer?.customerCode ?: "",
                amountToSettle = debtSettlementAmountTomans,
                nowMillis = now
            )
        }
    }

    /**
     * Transfers remaining unpaid receipt balance into a Consolidated Customer Debt record
     * WITHOUT crediting Sales Stats until «تسویه شد».
     */
    suspend fun registerReceiptAsDebt(
        editedHistory: GameHistoryEntity,
        customerInput: String,
        cashPaidTomans: Long,
        debtSettlementAmountTomans: Long = 0L,
        cardPaidTomans: Long = 0L,
        seatResolutions: List<SeatResolutionInput> = emptyList(),
        creditUsedTomans: Long = 0L
    ) {
        val now = System.currentTimeMillis()
        val trimmed = customerInput.trim()
        val matched = findCustomerByCodeOrName(trimmed)
        val finalName = matched?.name ?: trimmed
        val finalCode = matched?.customerCode ?: ""

        if (creditUsedTomans > 0L) {
            consumeCustomerCredit(
                customerName = finalName,
                customerCode = finalCode,
                amountToConsume = creditUsedTomans
            )
        }

        if (debtSettlementAmountTomans > 0L) {
            settleCustomerDebtsPartialOrFull(
                customerName = finalName,
                customerCode = finalCode,
                amountToSettle = debtSettlementAmountTomans,
                nowMillis = now
            )
        }

        // Any seats individually marked DEBT on their own customer account
        val extraSeatDebts = seatResolutions.filter { it.status == "DEBT" && it.amountTomans > 0L }
        val extraSeatPaid = seatResolutions.filter { it.status == "PAID" && it.amountTomans > 0L }
        val extraSeatDebtSum = extraSeatDebts.sumOf { it.amountTomans }

        extraSeatDebts.forEach { dSeat ->
            val targetName = dSeat.customerInput.ifBlank { dSeat.displayName }
            upsertConsolidatedDebt(
                customerName = targetName,
                customerCode = "",
                addedAmount = dSeat.amountTomans,
                itemTitle = "سهم ${dSeat.displayName} - ${editedHistory.systemDisplayName}",
                systemDisplayName = editedHistory.systemDisplayName,
                note = "سهم بازیکن ${dSeat.displayName}",
                gameFee = dSeat.amountTomans,
                snacksFee = 0L,
                snacksDetail = "",
                playerCount = 1,
                playedMinutes = editedHistory.playedMinutes,
                startTimeMillis = editedHistory.startTimeMillis,
                endTimeMillis = editedHistory.endTimeMillis,
                discountPercent = editedHistory.discountPercent,
                discountAmount = 0L,
                segmentsDetailJson = editedHistory.segmentsDetailJson,
                nowMillis = now
            )
        }

        if (cashPaidTomans > 0L) {
            dao.insertCashEntry(
                CashEntryEntity(
                    amountTomans = cashPaidTomans,
                    note = "پرداخت نقدی بخشی از فاکتور ${editedHistory.systemDisplayName}",
                    customerName = finalName,
                    source = "RECEIPT",
                    createdAtMillis = now
                )
            )
        }

        val immediatePaidTotal = cashPaidTomans + cardPaidTomans + extraSeatPaid.sumOf { it.amountTomans }
        if (immediatePaidTotal > 0L) {
            dao.insertHistory(
                editedHistory.copy(
                    id = 0,
                    customerName = finalName,
                    totalFee = immediatePaidTotal,
                    gameFee = immediatePaidTotal,
                    snacksFee = 0L,
                    cashPaidTomans = cashPaidTomans,
                    cardPaidTomans = cardPaidTomans,
                    entryType = "CASH_PARTIAL",
                    dateIso = PersianDateUtils.formatJalaliDateTime(now),
                    createdAtMillis = now
                )
            )
        }

        val remainingDebt = max(0L, editedHistory.totalFee - creditUsedTomans - extraSeatDebtSum - immediatePaidTotal)
        if (remainingDebt > 0L) {
            val extraNote = buildList {
                add("فاکتور بازی ${editedHistory.systemDisplayName}")
                if (creditUsedTomans > 0L) add("کسر از طلب: ${formatPrice(creditUsedTomans)} ت")
                if (cashPaidTomans > 0L) add("کسر نقدی: ${formatPrice(cashPaidTomans)} ت")
                if (cardPaidTomans > 0L) add("کسر کارتخوان: ${formatPrice(cardPaidTomans)} ت")
                if (editedHistory.sessionNote.isNotBlank()) add(editedHistory.sessionNote)
                if (editedHistory.modeConversionNotes.isNotBlank()) add(editedHistory.modeConversionNotes)
                if (matched != null) {
                    if (matched.phone.isNotBlank()) add("تلفن: ${matched.phone}")
                    if (matched.nationalId.isNotBlank()) add("کدملی: ${matched.nationalId}")
                }
            }.joinToString(" | ")

            upsertConsolidatedDebt(
                customerName = finalName,
                customerCode = finalCode,
                addedAmount = remainingDebt,
                itemTitle = "فاکتور ${editedHistory.systemDisplayName} (${editedHistory.playedMinutes} د)",
                systemDisplayName = editedHistory.systemDisplayName,
                note = extraNote,
                gameFee = max(0L, remainingDebt - editedHistory.snacksFee),
                snacksFee = editedHistory.snacksFee,
                snacksDetail = editedHistory.snacksDetail,
                playerCount = editedHistory.playerCount,
                playedMinutes = editedHistory.playedMinutes,
                startTimeMillis = editedHistory.startTimeMillis,
                endTimeMillis = editedHistory.endTimeMillis,
                discountPercent = editedHistory.discountPercent,
                discountAmount = editedHistory.discountAmount,
                segmentsDetailJson = editedHistory.segmentsDetailJson,
                nowMillis = now
            )
        }
    }

    /**
     * Merges any new debt for a customer into ONE consolidated unsettled record per customer.
     */
    private suspend fun upsertConsolidatedDebt(
        customerName: String,
        customerCode: String,
        addedAmount: Long,
        itemTitle: String,
        systemDisplayName: String,
        note: String,
        gameFee: Long,
        snacksFee: Long,
        snacksDetail: String,
        playerCount: Int,
        playedMinutes: Int,
        startTimeMillis: Long,
        endTimeMillis: Long,
        discountPercent: Int,
        discountAmount: Long,
        segmentsDetailJson: String,
        nowMillis: Long
    ): Long {
        if (addedAmount <= 0L) return -1L
        val existing = dao.getAllDebtsList()
            .firstOrNull { !it.isSettled && debtMatchesCustomer(it, customerName, customerCode) }

        val newLineItem = DebtLineItem(
            id = "d_${nowMillis}_${(100..999).random()}",
            title = itemTitle.ifBlank { "بدهی ثبت‌شده" },
            amountTomans = addedAmount,
            createdAtMillis = nowMillis,
            systemDisplayName = systemDisplayName,
            note = note
        )

        if (existing != null) {
            val currentItems = DebtItemCodec.decode(existing.debtItemsJson).toMutableList()
            if (currentItems.isEmpty() && existing.amountTomans > 0L) {
                currentItems.add(
                    DebtLineItem(
                        id = "d_legacy_${existing.id}",
                        title = existing.systemDisplayName.ifBlank { "بدهی قبلی" },
                        amountTomans = existing.amountTomans,
                        createdAtMillis = existing.createdAtMillis,
                        systemDisplayName = existing.systemDisplayName,
                        note = existing.note
                    )
                )
            }
            currentItems.add(newLineItem)

            val newTotal = existing.amountTomans + addedAmount
            val mergedNote = listOf(existing.note, note).filter { it.isNotBlank() }.distinct().joinToString(" | ")
            val mergedSnacks = listOf(existing.snacksDetail, snacksDetail).filter { it.isNotBlank() }.joinToString("، ")
            val mergedSystems = listOf(existing.systemDisplayName, systemDisplayName).filter { it.isNotBlank() }.distinct().joinToString(" + ")

            val existingSegs = SessionSegmentCodec.decode(existing.segmentsDetailJson)
            val addedSegs = SessionSegmentCodec.decode(segmentsDetailJson)
            val mergedSegsJson = SessionSegmentCodec.encode(existingSegs + addedSegs)

            dao.updateDebt(
                existing.copy(
                    amountTomans = newTotal,
                    note = mergedNote,
                    customerCode = existing.customerCode.ifBlank { customerCode },
                    systemDisplayName = mergedSystems,
                    playedMinutes = existing.playedMinutes + playedMinutes,
                    gameFee = existing.gameFee + gameFee,
                    snacksFee = existing.snacksFee + snacksFee,
                    snacksDetail = mergedSnacks,
                    discountAmount = existing.discountAmount + discountAmount,
                    segmentsDetailJson = mergedSegsJson,
                    debtItemsJson = DebtItemCodec.encode(currentItems)
                )
            )
            return existing.id
        }

        return dao.insertDebt(
            CustomerDebtEntity(
                customerName = customerName,
                customerCode = customerCode,
                amountTomans = addedAmount,
                note = note,
                createdAtMillis = nowMillis,
                isSettled = false,
                settledAtMillis = 0L,
                systemDisplayName = systemDisplayName,
                playerCount = playerCount,
                playedMinutes = playedMinutes,
                gameFee = gameFee,
                snacksFee = snacksFee,
                snacksDetail = snacksDetail,
                startTimeMillis = startTimeMillis,
                endTimeMillis = endTimeMillis,
                discountPercent = discountPercent,
                discountAmount = discountAmount,
                segmentsDetailJson = segmentsDetailJson,
                transferredToStats = false,
                debtItemsJson = DebtItemCodec.encode(listOf(newLineItem))
            )
        )
    }

    /**
     * Marks/settles a debt card: transfers the complete itemized invoice into Sales Stats (`game_history`)
     * AND deletes the settled row from `customer_debts` so Accounting remains clean.
     */
    suspend fun settleDebtAndTransferToStats(debt: CustomerDebtEntity) {
        if (debt.isSettled) return
        val dbRow = dao.getDebtById(debt.id)
        if (dbRow == null && debt.id != 0L) return
        val target = dbRow ?: debt
        if (target.isSettled || target.transferredToStats) {
            dao.deleteDebt(target)
            return
        }

        val now = System.currentTimeMillis()
        if (target.amountTomans > 0L) {
            val items = DebtItemCodec.decode(target.debtItemsJson)
            val itemizedDesc = if (items.isNotEmpty()) {
                items.joinToString(" | ") { "${it.title}: ${formatPrice(it.amountTomans)} ت" }
            } else {
                target.note
            }
            val sysName = target.systemDisplayName.ifBlank { "تسویه بدهی (${target.customerName})" }
            val gFee = if (target.gameFee > 0L) target.gameFee else max(0L, target.amountTomans - target.snacksFee)
            val fullSnacksDetail = listOf(target.snacksDetail, itemizedDesc).filter { it.isNotBlank() }.distinct().joinToString(" | ")

            dao.insertHistory(
                GameHistoryEntity(
                    systemId = 0,
                    systemDisplayName = sysName,
                    playerCount = target.playerCount.coerceAtLeast(1),
                    startTimeMillis = if (target.startTimeMillis > 0L) target.startTimeMillis else target.createdAtMillis,
                    endTimeMillis = if (target.endTimeMillis > 0L) target.endTimeMillis else now,
                    playedMinutes = target.playedMinutes,
                    gameFee = gFee,
                    snacksFee = target.snacksFee,
                    totalFee = target.amountTomans,
                    snacksDetail = fullSnacksDetail,
                    customerName = target.customerName,
                    dateIso = PersianDateUtils.formatJalaliDateTime(now),
                    createdAtMillis = now,
                    discountPercent = target.discountPercent,
                    discountAmount = target.discountAmount,
                    segmentsDetailJson = target.segmentsDetailJson,
                    entryType = "DEBT_SETTLEMENT"
                )
            )
        }

        // Remove from customer_debts cleanly once transferred to Sales Stats
        dao.deleteDebt(target)
    }

    suspend fun updateOrAddDebtLineItems(
        debtId: Long,
        updatedItems: List<DebtLineItem>,
        updatedNote: String
    ) {
        val debt = dao.getDebtById(debtId) ?: return
        val newTotal = updatedItems.sumOf { it.amountTomans }.coerceAtLeast(0L)
        if (newTotal <= 0L && updatedItems.isEmpty()) {
            dao.deleteDebt(debt)
            return
        }
        val combinedSnacks = debt.snacksFee.coerceAtMost(newTotal)
        dao.updateDebt(
            debt.copy(
                amountTomans = newTotal,
                gameFee = max(0L, newTotal - combinedSnacks),
                note = updatedNote.trim(),
                debtItemsJson = DebtItemCodec.encode(updatedItems)
            )
        )
    }

    private suspend fun settleCustomerDebtsPartialOrFull(
        customerName: String,
        customerCode: String,
        amountToSettle: Long,
        nowMillis: Long
    ) {
        var remaining = amountToSettle
        val allDebts = dao.getAllDebtsList()
            .filter { !it.isSettled && debtMatchesCustomer(it, customerName, customerCode) }
            .sortedBy { it.createdAtMillis }

        for (d in allDebts) {
            if (remaining <= 0L) break
            if (d.amountTomans <= remaining) {
                remaining -= d.amountTomans
                settleDebtAndTransferToStats(d)
            } else {
                val leftover = d.amountTomans - remaining
                val paidNow = remaining
                remaining = 0L
                val existingItems = DebtItemCodec.decode(d.debtItemsJson).toMutableList()
                existingItems.add(
                    DebtLineItem(
                        id = "d_part_${nowMillis}",
                        title = "پرداخت بخشی از بدهی",
                        amountTomans = -paidNow,
                        createdAtMillis = nowMillis,
                        note = "تسویه جزئی"
                    )
                )
                val updatedNote = if (d.note.isBlank()) {
                    "پرداخت بخشی: ${formatPrice(paidNow)} ت"
                } else {
                    "${d.note} | پرداخت بخشی: ${formatPrice(paidNow)} ت"
                }
                dao.updateDebt(
                    d.copy(
                        amountTomans = leftover,
                        note = updatedNote,
                        debtItemsJson = DebtItemCodec.encode(existingItems)
                    )
                )
                dao.insertHistory(
                    GameHistoryEntity(
                        systemId = 0,
                        systemDisplayName = "تسویه جزئی بدهی (${d.customerName})",
                        playerCount = 1,
                        startTimeMillis = nowMillis,
                        endTimeMillis = nowMillis,
                        playedMinutes = 0,
                        gameFee = paidNow,
                        snacksFee = 0L,
                        totalFee = paidNow,
                        snacksDetail = "",
                        customerName = d.customerName,
                        dateIso = PersianDateUtils.formatJalaliDateTime(nowMillis),
                        createdAtMillis = nowMillis,
                        entryType = "DEBT_SETTLEMENT"
                    )
                )
            }
        }
    }

    private fun debtMatchesCustomer(
        debt: CustomerDebtEntity,
        name: String,
        code: String
    ): Boolean {
        if (code.isNotBlank() && debt.customerCode.equals(code, ignoreCase = true)) return true
        if (name.isNotBlank() && debt.customerName.equals(name, ignoreCase = true)) return true
        return false
    }

    // History operations
    suspend fun updateHistoryRecord(history: GameHistoryEntity) = dao.updateHistory(history)
    suspend fun deleteHistoryRecord(history: GameHistoryEntity) = dao.deleteHistory(history)
    suspend fun clearAllHistory() = dao.clearAllHistory()

    // Cash Ledger
    suspend fun addCashEntry(amountTomans: Long, note: String = "", customerName: String = "", source: String = "MANUAL"): Long {
        return dao.insertCashEntry(
            CashEntryEntity(
                amountTomans = amountTomans,
                note = note.trim(),
                customerName = customerName.trim(),
                source = source,
                createdAtMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateCashEntry(entry: CashEntryEntity) = dao.updateCashEntry(entry)

    suspend fun deleteCashEntry(entry: CashEntryEntity) = dao.deleteCashEntry(entry)

    suspend fun findCustomerByCodeOrName(input: String): CustomerEntity? {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return null
        val byCode = dao.getCustomerByCode(trimmed)
        if (byCode != null) return byCode
        val matches = dao.searchCustomers(trimmed)
        return matches.firstOrNull {
            it.customerCode.equals(trimmed, ignoreCase = true) ||
                it.name.equals(trimmed, ignoreCase = true)
        } ?: matches.firstOrNull()
    }

    // Standalone Consolidated Customer Debt
    suspend fun addDebt(
        customerName: String,
        amountTomans: Long,
        note: String = "",
        customerCode: String = ""
    ): Long {
        val resolved = findCustomerByCodeOrName(customerCode.ifBlank { customerName })
        val finalName = resolved?.name ?: customerName.trim()
        val finalCode = resolved?.customerCode ?: customerCode.trim()
        val now = System.currentTimeMillis()
        val extraInfo = buildList {
            if (note.isNotBlank()) add(note.trim())
            if (resolved != null) {
                if (resolved.phone.isNotBlank()) add("تلفن: ${resolved.phone}")
                if (resolved.nationalId.isNotBlank()) add("کدملی: ${resolved.nationalId}")
            }
        }.joinToString(" | ")

        return upsertConsolidatedDebt(
            customerName = finalName,
            customerCode = finalCode,
            addedAmount = amountTomans,
            itemTitle = note.trim().ifBlank { "ثبت بدهی دستی" },
            systemDisplayName = "",
            note = extraInfo,
            gameFee = amountTomans,
            snacksFee = 0L,
            snacksDetail = "",
            playerCount = 1,
            playedMinutes = 0,
            startTimeMillis = now,
            endTimeMillis = now,
            discountPercent = 0,
            discountAmount = 0L,
            segmentsDetailJson = "[]",
            nowMillis = now
        )
    }

    // Customer Credit Management (طلب مشتری)
    suspend fun addCustomerCredit(
        customerName: String,
        amountTomans: Long,
        note: String = "",
        customerCode: String = ""
    ): Long {
        if (amountTomans <= 0L) return -1L
        val resolved = findCustomerByCodeOrName(customerCode.ifBlank { customerName })
        val finalName = resolved?.name ?: customerName.trim()
        val finalCode = resolved?.customerCode ?: customerCode.trim()
        return dao.insertCredit(
            CustomerCreditEntity(
                customerName = finalName,
                customerCode = finalCode,
                amountTomans = amountTomans,
                note = note.trim(),
                createdAtMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteCustomerCredit(credit: CustomerCreditEntity) = dao.deleteCredit(credit)

    suspend fun consumeCustomerCredit(
        customerName: String,
        customerCode: String,
        amountToConsume: Long
    ) {
        if (amountToConsume <= 0L) return
        var remaining = amountToConsume
        val matchingCredits = dao.getAllCreditsList()
            .filter { creditMatchesCustomer(it, customerName, customerCode) }
            .sortedBy { it.createdAtMillis }

        for (credit in matchingCredits) {
            if (remaining <= 0L) break
            if (credit.amountTomans <= remaining) {
                remaining -= credit.amountTomans
                dao.deleteCredit(credit)
            } else {
                dao.updateCredit(credit.copy(amountTomans = credit.amountTomans - remaining))
                remaining = 0L
            }
        }
    }

    private fun creditMatchesCustomer(
        credit: CustomerCreditEntity,
        name: String,
        code: String
    ): Boolean {
        if (code.isNotBlank() && credit.customerCode.equals(code, ignoreCase = true)) return true
        if (name.isNotBlank() && credit.customerName.equals(name, ignoreCase = true)) return true
        return false
    }

    // Service Registration (خدمات گیم‌نت: نصب بازی، نصب ویندوز، آهنگ، تعمیر دسته...)
    suspend fun addServiceEntry(
        title: String,
        amountTomans: Long,
        note: String = "",
        cashPaidTomans: Long = 0L,
        cardPaidTomans: Long = 0L
    ): Long {
        if (amountTomans <= 0L || title.isBlank()) return -1L
        val now = System.currentTimeMillis()
        val actualCash = cashPaidTomans.coerceIn(0L, amountTomans)
        val actualCard = cardPaidTomans.coerceIn(0L, amountTomans)
        val id = dao.insertHistory(
            GameHistoryEntity(
                systemId = 0,
                systemDisplayName = title.trim(),
                playerCount = 1,
                startTimeMillis = now,
                endTimeMillis = now,
                playedMinutes = 0,
                gameFee = amountTomans,
                snacksFee = 0L,
                totalFee = amountTomans,
                snacksDetail = note.trim(),
                customerName = "خدمات",
                dateIso = PersianDateUtils.formatJalaliDateTime(now),
                createdAtMillis = now,
                cashPaidTomans = actualCash,
                cardPaidTomans = actualCard,
                entryType = "SERVICE",
                sessionNote = note.trim()
            )
        )
        if (actualCash > 0L) {
            dao.insertCashEntry(
                CashEntryEntity(
                    amountTomans = actualCash,
                    note = "خدمات: ${title.trim()}",
                    customerName = "خدمات",
                    source = "SERVICE",
                    createdAtMillis = now
                )
            )
        }
        return id
    }

    suspend fun updateDebt(debt: CustomerDebtEntity) = dao.updateDebt(debt)
    suspend fun deleteDebt(debt: CustomerDebtEntity) = dao.deleteDebt(debt)

    // Customer Directory operations
    suspend fun addCustomer(
        code: String,
        name: String,
        phone: String = "",
        nationalId: String = "",
        discountPercent: Int = 0
    ): Long {
        val customer = CustomerEntity(
            customerCode = code.trim(),
            name = name.trim(),
            phone = phone.trim(),
            nationalId = nationalId.trim(),
            discountPercent = discountPercent.coerceIn(0, 100)
        )
        return dao.insertCustomer(customer)
    }

    suspend fun updateCustomer(customer: CustomerEntity) = dao.updateCustomer(customer)
    suspend fun deleteCustomer(customer: CustomerEntity) = dao.deleteCustomer(customer)
    suspend fun searchCustomers(query: String) = dao.searchCustomers(query)
    suspend fun getCustomerByCode(code: String) = dao.getCustomerByCode(code)

    // Snacks
    suspend fun addSnackItem(name: String, priceTomans: Long, category: String) =
        dao.insertSnack(SnackItemEntity(name = name, priceTomans = priceTomans, category = category))

    suspend fun updateSnackItem(snack: SnackItemEntity) = dao.updateSnack(snack)
    suspend fun deleteSnackItem(snack: SnackItemEntity) = dao.deleteSnack(snack)

    // Club Profile
    suspend fun saveProfile(profile: ClubProfileEntity) = dao.saveProfile(profile)
    suspend fun getProfile() = dao.getProfile()

    // Custom Voice Commands
    suspend fun addCustomVoiceCommand(
        phrase: String,
        targetSystemId: Int,
        targetSystemName: String,
        playerCount: Int,
        durationMinutes: Int,
        mode: String = "TIME",
        amountTomans: Long = 0L
    ): Long {
        val cmd = CustomVoiceCommandEntity(
            commandPhrase = phrase.trim(),
            targetSystemId = targetSystemId,
            targetSystemName = targetSystemName,
            playerCount = playerCount,
            durationMinutes = durationMinutes,
            isCountDown = mode != "OPEN",
            mode = mode,
            amountTomans = amountTomans
        )
        return dao.insertCustomVoiceCommand(cmd)
    }

    suspend fun deleteCustomVoiceCommand(cmd: CustomVoiceCommandEntity) =
        dao.deleteCustomVoiceCommand(cmd)

    suspend fun deleteCustomVoiceCommandsByIds(ids: List<Long>) {
        if (ids.isNotEmpty()) dao.deleteCustomVoiceCommandsByIds(ids)
    }

    suspend fun clearAllCustomVoiceCommands() = dao.clearAllCustomVoiceCommands()

    // Bank Cards
    suspend fun addBankCard(bankName: String, cardNumber: String, cardHolder: String = ""): Long {
        return dao.insertBankCard(
            BankCardEntity(
                bankName = bankName.trim(),
                cardNumber = cardNumber.trim(),
                cardHolder = cardHolder.trim()
            )
        )
    }

    suspend fun deleteBankCard(card: BankCardEntity) = dao.deleteBankCard(card)

    // Full Backup & Restore Engine (v5 - includes customer credits, session notes, snack lines)
    suspend fun exportBackupJson(extraPrefsJson: JSONObject = JSONObject()): String {
        val root = JSONObject()
        root.put("version", 5)
        root.put("app", "CafeManagement")
        root.put("exportedAt", System.currentTimeMillis())
        root.put("preferences", extraPrefsJson)

        val prof = dao.getProfile()
        if (prof != null) {
            val pObj = JSONObject()
            pObj.put("clubName", prof.clubName)
            pObj.put("managerName", prof.managerName)
            pObj.put("phoneNumber", prof.phoneNumber)
            pObj.put("avatarUri", prof.avatarUri)
            root.put("profile", pObj)
        }

        val sysArray = JSONArray()
        dao.getAllSystemsList().forEach {
            sysArray.put(JSONObject().apply {
                put("id", it.id)
                put("code", it.code)
                put("displayName", it.displayName)
                put("systemType", it.systemType)
                put("hourlyRatePerPlayer", it.hourlyRatePerPlayer)
                put("flatRatePerHour", it.flatRatePerHour)
                put("iconType", it.iconType)
                put("sortOrder", it.sortOrder)
            })
        }
        root.put("systems", sysArray)

        val snackArray = JSONArray()
        dao.getAllSnacksList().forEach {
            snackArray.put(JSONObject().apply {
                put("name", it.name)
                put("priceTomans", it.priceTomans)
                put("category", it.category)
                put("icon", it.icon)
            })
        }
        root.put("snacks", snackArray)

        val activeArray = JSONArray()
        dao.getActiveSessionsList().forEach {
            activeArray.put(JSONObject().apply {
                put("systemId", it.systemId)
                put("systemDisplayName", it.systemDisplayName)
                put("playerCount", it.playerCount)
                put("startTimeMillis", it.startTimeMillis)
                put("durationMinutes", it.durationMinutes)
                put("expectedEndTimeMillis", it.expectedEndTimeMillis)
                put("isCountDown", it.isCountDown)
                put("hourlyRateApplied", it.hourlyRateApplied)
                put("snacksCost", it.snacksCost)
                put("snacksDetail", it.snacksDetail)
                put("targetAmountTomans", it.targetAmountTomans)
                put("customerName", it.customerName)
                put("isAlarmDismissed", it.isAlarmDismissed)
                put("discountPercent", it.discountPercent)
                put("isPaused", it.isPaused)
                put("pausedAtMillis", it.pausedAtMillis)
                put("segmentsJson", it.segmentsJson)
                put("currentSegmentStartMillis", it.currentSegmentStartMillis)
                put("playerSeatsJson", it.playerSeatsJson)
                put("modeConversionNotes", it.modeConversionNotes)
                put("nextAnonCounter", it.nextAnonCounter)
                put("sessionNote", it.sessionNote)
                put("snacksItemsJson", it.snacksItemsJson)
            })
        }
        root.put("activeSessions", activeArray)

        val debtsArray = JSONArray()
        dao.getAllDebtsList().forEach {
            debtsArray.put(JSONObject().apply {
                put("customerName", it.customerName)
                put("customerCode", it.customerCode)
                put("amountTomans", it.amountTomans)
                put("note", it.note)
                put("createdAtMillis", it.createdAtMillis)
                put("isSettled", it.isSettled)
                put("settledAtMillis", it.settledAtMillis)
                put("systemDisplayName", it.systemDisplayName)
                put("playerCount", it.playerCount)
                put("playedMinutes", it.playedMinutes)
                put("gameFee", it.gameFee)
                put("snacksFee", it.snacksFee)
                put("snacksDetail", it.snacksDetail)
                put("startTimeMillis", it.startTimeMillis)
                put("endTimeMillis", it.endTimeMillis)
                put("discountPercent", it.discountPercent)
                put("discountAmount", it.discountAmount)
                put("segmentsDetailJson", it.segmentsDetailJson)
                put("transferredToStats", it.transferredToStats)
                put("debtItemsJson", it.debtItemsJson)
            })
        }
        root.put("debts", debtsArray)

        val custArray = JSONArray()
        dao.getAllCustomersList().forEach {
            custArray.put(JSONObject().apply {
                put("customerCode", it.customerCode)
                put("name", it.name)
                put("phone", it.phone)
                put("nationalId", it.nationalId)
                put("discountPercent", it.discountPercent)
                put("createdAtMillis", it.createdAtMillis)
            })
        }
        root.put("customers", custArray)

        val histArray = JSONArray()
        dao.getAllHistoryList().forEach {
            histArray.put(JSONObject().apply {
                put("systemId", it.systemId)
                put("systemDisplayName", it.systemDisplayName)
                put("playerCount", it.playerCount)
                put("startTimeMillis", it.startTimeMillis)
                put("endTimeMillis", it.endTimeMillis)
                put("playedMinutes", it.playedMinutes)
                put("gameFee", it.gameFee)
                put("snacksFee", it.snacksFee)
                put("totalFee", it.totalFee)
                put("snacksDetail", it.snacksDetail)
                put("customerName", it.customerName)
                put("dateIso", it.dateIso)
                put("createdAtMillis", it.createdAtMillis)
                put("discountPercent", it.discountPercent)
                put("discountAmount", it.discountAmount)
                put("cashPaidTomans", it.cashPaidTomans)
                put("debtSettledTomans", it.debtSettledTomans)
                put("segmentsDetailJson", it.segmentsDetailJson)
                put("entryType", it.entryType)
                put("cardPaidTomans", it.cardPaidTomans)
                put("modeConversionNotes", it.modeConversionNotes)
                put("playerSeatsJson", it.playerSeatsJson)
                put("sessionNote", it.sessionNote)
            })
        }
        root.put("history", histArray)

        val creditsArray = JSONArray()
        dao.getAllCreditsList().forEach {
            creditsArray.put(JSONObject().apply {
                put("customerName", it.customerName)
                put("customerCode", it.customerCode)
                put("amountTomans", it.amountTomans)
                put("note", it.note)
                put("createdAtMillis", it.createdAtMillis)
            })
        }
        root.put("credits", creditsArray)

        val cashArray = JSONArray()
        dao.getAllCashEntriesList().forEach {
            cashArray.put(JSONObject().apply {
                put("amountTomans", it.amountTomans)
                put("note", it.note)
                put("customerName", it.customerName)
                put("source", it.source)
                put("createdAtMillis", it.createdAtMillis)
            })
        }
        root.put("cashEntries", cashArray)

        val cmdArray = JSONArray()
        dao.getAllCustomVoiceCommandsList().forEach {
            cmdArray.put(JSONObject().apply {
                put("commandPhrase", it.commandPhrase)
                put("targetSystemId", it.targetSystemId)
                put("targetSystemName", it.targetSystemName)
                put("playerCount", it.playerCount)
                put("durationMinutes", it.durationMinutes)
                put("mode", it.mode)
                put("amountTomans", it.amountTomans)
                put("createdAtMillis", it.createdAtMillis)
            })
        }
        root.put("customCommands", cmdArray)

        val cardsArray = JSONArray()
        dao.getAllBankCardsList().forEach {
            cardsArray.put(JSONObject().apply {
                put("bankName", it.bankName)
                put("cardNumber", it.cardNumber)
                put("cardHolder", it.cardHolder)
                put("createdAtMillis", it.createdAtMillis)
            })
        }
        root.put("bankCards", cardsArray)

        return root.toString(2)
    }

    suspend fun importBackupJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)

            if (root.has("profile")) {
                val p = root.getJSONObject("profile")
                dao.saveProfile(
                    ClubProfileEntity(
                        id = 1,
                        clubName = p.optString("clubName", ""),
                        managerName = p.optString("managerName", ""),
                        phoneNumber = p.optString("phoneNumber", ""),
                        avatarUri = p.optString("avatarUri", "")
                    )
                )
            }

            if (root.has("systems")) {
                val arr = root.getJSONArray("systems")
                val list = mutableListOf<GameSystemEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        GameSystemEntity(
                            id = o.getInt("id"),
                            code = o.getString("code"),
                            displayName = o.getString("displayName"),
                            systemType = o.getString("systemType"),
                            hourlyRatePerPlayer = o.getLong("hourlyRatePerPlayer"),
                            flatRatePerHour = o.optLong("flatRatePerHour", 0),
                            iconType = o.optString("iconType", "gamepad"),
                            sortOrder = o.optInt("sortOrder", 0)
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertSystems(list)
            }

            if (root.has("snacks")) {
                val arr = root.getJSONArray("snacks")
                dao.clearAllSnacks()
                val list = mutableListOf<SnackItemEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        SnackItemEntity(
                            name = o.getString("name"),
                            priceTomans = o.getLong("priceTomans"),
                            category = o.optString("category", "خوراکی"),
                            icon = o.optString("icon", "drink")
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertSnacks(list)
            }

            if (root.has("activeSessions")) {
                val arr = root.getJSONArray("activeSessions")
                dao.clearActiveSessions()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    dao.insertSession(
                        ActiveSessionEntity(
                            systemId = o.getInt("systemId"),
                            systemDisplayName = o.getString("systemDisplayName"),
                            playerCount = o.optInt("playerCount", 1),
                            startTimeMillis = o.getLong("startTimeMillis"),
                            durationMinutes = o.optInt("durationMinutes", 0),
                            expectedEndTimeMillis = o.optLong("expectedEndTimeMillis", 0L),
                            isCountDown = o.optBoolean("isCountDown", true),
                            hourlyRateApplied = o.optLong("hourlyRateApplied", 60000L),
                            snacksCost = o.optLong("snacksCost", 0L),
                            snacksDetail = o.optString("snacksDetail", ""),
                            targetAmountTomans = o.optLong("targetAmountTomans", 0L),
                            customerName = o.optString("customerName", ""),
                            isAlarmDismissed = o.optBoolean("isAlarmDismissed", false),
                            discountPercent = o.optInt("discountPercent", 0),
                            isPaused = o.optBoolean("isPaused", false),
                            pausedAtMillis = o.optLong("pausedAtMillis", 0L),
                            segmentsJson = o.optString("segmentsJson", "[]"),
                            currentSegmentStartMillis = o.optLong("currentSegmentStartMillis", o.getLong("startTimeMillis")),
                            playerSeatsJson = o.optString("playerSeatsJson", "[]"),
                            modeConversionNotes = o.optString("modeConversionNotes", ""),
                            nextAnonCounter = o.optInt("nextAnonCounter", 1),
                            sessionNote = o.optString("sessionNote", ""),
                            snacksItemsJson = o.optString("snacksItemsJson", "[]")
                        )
                    )
                }
            }

            if (root.has("customers")) {
                val arr = root.getJSONArray("customers")
                dao.clearAllCustomers()
                val list = mutableListOf<CustomerEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        CustomerEntity(
                            customerCode = o.getString("customerCode"),
                            name = o.getString("name"),
                            phone = o.optString("phone", ""),
                            nationalId = o.optString("nationalId", ""),
                            discountPercent = o.optInt("discountPercent", 0),
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertCustomers(list)
            }

            if (root.has("debts")) {
                val arr = root.getJSONArray("debts")
                dao.clearAllDebts()
                val list = mutableListOf<CustomerDebtEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        CustomerDebtEntity(
                            customerName = o.getString("customerName"),
                            customerCode = o.optString("customerCode", ""),
                            amountTomans = o.getLong("amountTomans"),
                            note = o.optString("note", ""),
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis()),
                            isSettled = o.optBoolean("isSettled", false),
                            settledAtMillis = o.optLong("settledAtMillis", 0L),
                            systemDisplayName = o.optString("systemDisplayName", ""),
                            playerCount = o.optInt("playerCount", 1),
                            playedMinutes = o.optInt("playedMinutes", 0),
                            gameFee = o.optLong("gameFee", 0L),
                            snacksFee = o.optLong("snacksFee", 0L),
                            snacksDetail = o.optString("snacksDetail", ""),
                            startTimeMillis = o.optLong("startTimeMillis", 0L),
                            endTimeMillis = o.optLong("endTimeMillis", 0L),
                            discountPercent = o.optInt("discountPercent", 0),
                            discountAmount = o.optLong("discountAmount", 0L),
                            segmentsDetailJson = o.optString("segmentsDetailJson", "[]"),
                            transferredToStats = o.optBoolean("transferredToStats", o.optBoolean("isSettled", false)),
                            debtItemsJson = o.optString("debtItemsJson", "[]")
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertDebts(list)
            }

            if (root.has("credits")) {
                val arr = root.getJSONArray("credits")
                dao.clearAllCredits()
                val list = mutableListOf<CustomerCreditEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        CustomerCreditEntity(
                            customerName = o.getString("customerName"),
                            customerCode = o.optString("customerCode", ""),
                            amountTomans = o.getLong("amountTomans"),
                            note = o.optString("note", ""),
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertCredits(list)
            }

            if (root.has("history")) {
                val arr = root.getJSONArray("history")
                dao.clearAllHistory()
                val list = mutableListOf<GameHistoryEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        GameHistoryEntity(
                            systemId = o.getInt("systemId"),
                            systemDisplayName = o.getString("systemDisplayName"),
                            playerCount = o.getInt("playerCount"),
                            startTimeMillis = o.getLong("startTimeMillis"),
                            endTimeMillis = o.getLong("endTimeMillis"),
                            playedMinutes = o.getInt("playedMinutes"),
                            gameFee = o.getLong("gameFee"),
                            snacksFee = o.getLong("snacksFee"),
                            totalFee = o.getLong("totalFee"),
                            snacksDetail = o.optString("snacksDetail", ""),
                            customerName = o.optString("customerName", ""),
                            dateIso = o.getString("dateIso"),
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis()),
                            discountPercent = o.optInt("discountPercent", 0),
                            discountAmount = o.optLong("discountAmount", 0),
                            cashPaidTomans = o.optLong("cashPaidTomans", 0L),
                            debtSettledTomans = o.optLong("debtSettledTomans", 0L),
                            segmentsDetailJson = o.optString("segmentsDetailJson", "[]"),
                            entryType = o.optString("entryType", "GAME"),
                            cardPaidTomans = o.optLong("cardPaidTomans", 0L),
                            modeConversionNotes = o.optString("modeConversionNotes", ""),
                            playerSeatsJson = o.optString("playerSeatsJson", "[]"),
                            sessionNote = o.optString("sessionNote", "")
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertHistoryList(list)
            }

            if (root.has("cashEntries")) {
                val arr = root.getJSONArray("cashEntries")
                dao.clearAllCashEntries()
                val list = mutableListOf<CashEntryEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        CashEntryEntity(
                            amountTomans = o.getLong("amountTomans"),
                            note = o.optString("note", ""),
                            customerName = o.optString("customerName", ""),
                            source = o.optString("source", "RECEIPT"),
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertCashEntries(list)
            }

            if (root.has("customCommands")) {
                val arr = root.getJSONArray("customCommands")
                dao.clearAllCustomVoiceCommands()
                val list = mutableListOf<CustomVoiceCommandEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        CustomVoiceCommandEntity(
                            commandPhrase = o.getString("commandPhrase"),
                            targetSystemId = o.getInt("targetSystemId"),
                            targetSystemName = o.getString("targetSystemName"),
                            playerCount = o.getInt("playerCount"),
                            durationMinutes = o.getInt("durationMinutes"),
                            mode = o.optString("mode", "TIME"),
                            amountTomans = o.optLong("amountTomans", 0L),
                            isCountDown = o.optString("mode", "TIME") != "OPEN",
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertCustomVoiceCommands(list)
            }

            if (root.has("bankCards")) {
                val arr = root.getJSONArray("bankCards")
                dao.clearAllBankCards()
                val list = mutableListOf<BankCardEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        BankCardEntity(
                            bankName = o.optString("bankName", "بانک"),
                            cardNumber = o.getString("cardNumber"),
                            cardHolder = o.optString("cardHolder", ""),
                            createdAtMillis = o.optLong("createdAtMillis", System.currentTimeMillis())
                        )
                    )
                }
                if (list.isNotEmpty()) dao.insertBankCards(list)
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun toPersianDigits(num: Int): String {
        return num.toString()
            .replace('0', '۰')
            .replace('1', '۱')
            .replace('2', '۲')
            .replace('3', '۳')
            .replace('4', '۴')
            .replace('5', '۵')
            .replace('6', '۶')
            .replace('7', '۷')
            .replace('8', '۸')
            .replace('9', '۹')
    }

    private fun formatPrice(price: Long): String {
        return String.format(Locale.US, "%,d", price)
    }
}
