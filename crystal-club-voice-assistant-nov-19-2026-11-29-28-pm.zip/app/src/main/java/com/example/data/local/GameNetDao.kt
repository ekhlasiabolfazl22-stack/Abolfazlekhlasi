package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GameNetDao {

    // --- Systems ---
    @Query("SELECT * FROM game_systems ORDER BY sortOrder ASC, id ASC")
    fun getAllSystems(): Flow<List<GameSystemEntity>>

    @Query("SELECT * FROM game_systems ORDER BY sortOrder ASC, id ASC")
    suspend fun getAllSystemsList(): List<GameSystemEntity>

    @Query("SELECT * FROM game_systems WHERE id = :id LIMIT 1")
    suspend fun getSystemById(id: Int): GameSystemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSystems(systems: List<GameSystemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSystem(system: GameSystemEntity): Long

    @Query("SELECT MAX(id) FROM game_systems")
    suspend fun getMaxSystemId(): Int?

    @Update
    suspend fun updateSystem(system: GameSystemEntity)

    // --- Active Sessions ---
    @Query("SELECT * FROM active_sessions")
    fun getActiveSessions(): Flow<List<ActiveSessionEntity>>

    @Query("SELECT * FROM active_sessions")
    suspend fun getActiveSessionsList(): List<ActiveSessionEntity>

    @Query("SELECT * FROM active_sessions WHERE systemId = :systemId LIMIT 1")
    suspend fun getSessionBySystemId(systemId: Int): ActiveSessionEntity?

    @Query("SELECT * FROM active_sessions WHERE systemId = :systemId LIMIT 1")
    fun getSessionBySystemIdFlow(systemId: Int): Flow<ActiveSessionEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ActiveSessionEntity): Long

    @Update
    suspend fun updateSession(session: ActiveSessionEntity)

    @Delete
    suspend fun deleteSession(session: ActiveSessionEntity)

    @Query("DELETE FROM active_sessions WHERE systemId = :systemId")
    suspend fun deleteSessionBySystemId(systemId: Int)

    @Query("DELETE FROM active_sessions")
    suspend fun clearActiveSessions()

    // --- History & Stats ---
    @Query("SELECT * FROM game_history ORDER BY createdAtMillis DESC")
    fun getAllHistory(): Flow<List<GameHistoryEntity>>

    @Query("SELECT * FROM game_history ORDER BY createdAtMillis DESC")
    suspend fun getAllHistoryList(): List<GameHistoryEntity>

    @Query("SELECT * FROM game_history WHERE createdAtMillis >= :startMillis AND createdAtMillis <= :endMillis ORDER BY createdAtMillis DESC")
    fun getHistoryBetween(startMillis: Long, endMillis: Long): Flow<List<GameHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: GameHistoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistoryList(historyList: List<GameHistoryEntity>)

    @Update
    suspend fun updateHistory(history: GameHistoryEntity)

    @Delete
    suspend fun deleteHistory(history: GameHistoryEntity)

    @Query("DELETE FROM game_history")
    suspend fun clearAllHistory()

    // --- Cash Ledger ---
    @Query("SELECT * FROM cash_entries ORDER BY createdAtMillis DESC")
    fun getAllCashEntries(): Flow<List<CashEntryEntity>>

    @Query("SELECT * FROM cash_entries ORDER BY createdAtMillis DESC")
    suspend fun getAllCashEntriesList(): List<CashEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashEntry(entry: CashEntryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashEntries(entries: List<CashEntryEntity>)

    @Update
    suspend fun updateCashEntry(entry: CashEntryEntity)

    @Delete
    suspend fun deleteCashEntry(entry: CashEntryEntity)

    @Query("DELETE FROM cash_entries")
    suspend fun clearAllCashEntries()

    // --- Snacks Catalog ---
    @Query("SELECT * FROM snack_items ORDER BY name ASC")
    fun getAllSnacks(): Flow<List<SnackItemEntity>>

    @Query("SELECT * FROM snack_items")
    suspend fun getAllSnacksList(): List<SnackItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnacks(snacks: List<SnackItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnack(snack: SnackItemEntity): Long

    @Update
    suspend fun updateSnack(snack: SnackItemEntity)

    @Delete
    suspend fun deleteSnack(snack: SnackItemEntity)

    @Query("DELETE FROM snack_items")
    suspend fun clearAllSnacks()

    // --- Customer Debts ---
    @Query("SELECT * FROM customer_debts ORDER BY createdAtMillis DESC")
    fun getAllDebts(): Flow<List<CustomerDebtEntity>>

    @Query("SELECT * FROM customer_debts")
    suspend fun getAllDebtsList(): List<CustomerDebtEntity>

    @Query("SELECT * FROM customer_debts WHERE id = :id LIMIT 1")
    suspend fun getDebtById(id: Long): CustomerDebtEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: CustomerDebtEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebts(debts: List<CustomerDebtEntity>)

    @Update
    suspend fun updateDebt(debt: CustomerDebtEntity)

    @Delete
    suspend fun deleteDebt(debt: CustomerDebtEntity)

    @Query("DELETE FROM customer_debts")
    suspend fun clearAllDebts()

    // --- Customer Credits ---
    @Query("SELECT * FROM customer_credits ORDER BY createdAtMillis DESC")
    fun getAllCredits(): Flow<List<CustomerCreditEntity>>

    @Query("SELECT * FROM customer_credits")
    suspend fun getAllCreditsList(): List<CustomerCreditEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCredit(credit: CustomerCreditEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCredits(credits: List<CustomerCreditEntity>)

    @Update
    suspend fun updateCredit(credit: CustomerCreditEntity)

    @Delete
    suspend fun deleteCredit(credit: CustomerCreditEntity)

    @Query("DELETE FROM customer_credits")
    suspend fun clearAllCredits()

    // --- Customers Directory ---
    @Query("SELECT * FROM customers ORDER BY createdAtMillis DESC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers")
    suspend fun getAllCustomersList(): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE customerCode = :code LIMIT 1")
    suspend fun getCustomerByCode(code: String): CustomerEntity?

    @Query("SELECT * FROM customers WHERE name LIKE '%' || :query || '%' OR customerCode LIKE '%' || :query || '%'")
    suspend fun searchCustomers(query: String): List<CustomerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<CustomerEntity>)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Delete
    suspend fun deleteCustomer(customer: CustomerEntity)

    @Query("DELETE FROM customers")
    suspend fun clearAllCustomers()

    // --- Club Profile ---
    @Query("SELECT * FROM club_profile WHERE id = 1 LIMIT 1")
    fun getProfileFlow(): Flow<ClubProfileEntity?>

    @Query("SELECT * FROM club_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfile(): ClubProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: ClubProfileEntity)

    // --- Custom Voice Commands ---
    @Query("SELECT * FROM custom_voice_commands ORDER BY createdAtMillis DESC")
    fun getAllCustomVoiceCommands(): Flow<List<CustomVoiceCommandEntity>>

    @Query("SELECT * FROM custom_voice_commands")
    suspend fun getAllCustomVoiceCommandsList(): List<CustomVoiceCommandEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomVoiceCommand(command: CustomVoiceCommandEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomVoiceCommands(commands: List<CustomVoiceCommandEntity>)

    @Delete
    suspend fun deleteCustomVoiceCommand(command: CustomVoiceCommandEntity)

    @Query("DELETE FROM custom_voice_commands WHERE id IN (:ids)")
    suspend fun deleteCustomVoiceCommandsByIds(ids: List<Long>)

    @Query("DELETE FROM custom_voice_commands")
    suspend fun clearAllCustomVoiceCommands()

    // --- Bank Cards ---
    @Query("SELECT * FROM bank_cards ORDER BY createdAtMillis DESC")
    fun getAllBankCards(): Flow<List<BankCardEntity>>

    @Query("SELECT * FROM bank_cards")
    suspend fun getAllBankCardsList(): List<BankCardEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankCard(card: BankCardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankCards(cards: List<BankCardEntity>)

    @Delete
    suspend fun deleteBankCard(card: BankCardEntity)

    @Query("DELETE FROM bank_cards")
    suspend fun clearAllBankCards()
}
