package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

data class SessionSegment(
    val systemId: Int,
    val systemDisplayName: String,
    val playerCount: Int,
    val hourlyRatePerPlayer: Long,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val playedMinutes: Int,
    val costTomans: Long,
    val note: String = "",
    val seatIds: List<String> = emptyList()
)

object SessionSegmentCodec {
    fun encode(segments: List<SessionSegment>): String {
        val arr = JSONArray()
        segments.forEach { seg ->
            val o = JSONObject()
            o.put("systemId", seg.systemId)
            o.put("systemDisplayName", seg.systemDisplayName)
            o.put("playerCount", seg.playerCount)
            o.put("hourlyRatePerPlayer", seg.hourlyRatePerPlayer)
            o.put("startTimeMillis", seg.startTimeMillis)
            o.put("endTimeMillis", seg.endTimeMillis)
            o.put("playedMinutes", seg.playedMinutes)
            o.put("costTomans", seg.costTomans)
            o.put("note", seg.note)
            val seatArr = JSONArray()
            seg.seatIds.forEach { seatArr.put(it) }
            o.put("seatIds", seatArr)
            arr.put(o)
        }
        return arr.toString()
    }

    fun decode(json: String?): List<SessionSegment> {
        if (json.isNullOrBlank() || json.trim() == "[]") return emptyList()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<SessionSegment>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val seatArr = o.optJSONArray("seatIds")
                val seatIds = mutableListOf<String>()
                if (seatArr != null) {
                    for (j in 0 until seatArr.length()) {
                        val sid = seatArr.optString(j, "")
                        if (sid.isNotBlank()) seatIds.add(sid)
                    }
                }
                list.add(
                    SessionSegment(
                        systemId = o.optInt("systemId", 0),
                        systemDisplayName = o.optString("systemDisplayName", ""),
                        playerCount = o.optInt("playerCount", 1),
                        hourlyRatePerPlayer = o.optLong("hourlyRatePerPlayer", 0L),
                        startTimeMillis = o.optLong("startTimeMillis", 0L),
                        endTimeMillis = o.optLong("endTimeMillis", 0L),
                        playedMinutes = o.optInt("playedMinutes", 0),
                        costTomans = o.optLong("costTomans", 0L),
                        note = o.optString("note", ""),
                        seatIds = seatIds
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }
}

data class PlayerSeat(
    val seatId: String,
    val displayName: String,
    val customerCode: String = "",
    val joinedAtMillis: Long,
    val priorSegments: List<SessionSegment> = emptyList(),
    val priorSnacksCost: Long = 0L,
    val priorSnacksDetail: String = "",
    val currentSystemSnacksCost: Long = 0L,
    val currentSystemSnacksDetail: String = "",
    val isSettled: Boolean = false,
    val settledStatus: String = "" // "", "PAID", "DEBT"
)

object PlayerSeatCodec {
    fun encode(seats: List<PlayerSeat>): String {
        val arr = JSONArray()
        seats.forEach { seat ->
            val o = JSONObject()
            o.put("seatId", seat.seatId)
            o.put("displayName", seat.displayName)
            o.put("customerCode", seat.customerCode)
            o.put("joinedAtMillis", seat.joinedAtMillis)
            o.put("priorSegmentsJson", SessionSegmentCodec.encode(seat.priorSegments))
            o.put("priorSnacksCost", seat.priorSnacksCost)
            o.put("priorSnacksDetail", seat.priorSnacksDetail)
            o.put("currentSystemSnacksCost", seat.currentSystemSnacksCost)
            o.put("currentSystemSnacksDetail", seat.currentSystemSnacksDetail)
            o.put("isSettled", seat.isSettled)
            o.put("settledStatus", seat.settledStatus)
            arr.put(o)
        }
        return arr.toString()
    }

    fun decode(json: String?): List<PlayerSeat> {
        if (json.isNullOrBlank() || json.trim() == "[]") return emptyList()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<PlayerSeat>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    PlayerSeat(
                        seatId = o.optString("seatId", "seat_${i + 1}"),
                        displayName = o.optString("displayName", "نفر ${i + 1}"),
                        customerCode = o.optString("customerCode", ""),
                        joinedAtMillis = o.optLong("joinedAtMillis", 0L),
                        priorSegments = SessionSegmentCodec.decode(o.optString("priorSegmentsJson", "[]")),
                        priorSnacksCost = o.optLong("priorSnacksCost", 0L),
                        priorSnacksDetail = o.optString("priorSnacksDetail", ""),
                        currentSystemSnacksCost = o.optLong("currentSystemSnacksCost", 0L),
                        currentSystemSnacksDetail = o.optString("currentSystemSnacksDetail", ""),
                        isSettled = o.optBoolean("isSettled", false),
                        settledStatus = o.optString("settledStatus", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }
}

data class DebtLineItem(
    val id: String,
    val title: String,
    val amountTomans: Long,
    val createdAtMillis: Long,
    val systemDisplayName: String = "",
    val note: String = ""
)

object DebtItemCodec {
    fun encode(items: List<DebtLineItem>): String {
        val arr = JSONArray()
        items.forEach { item ->
            val o = JSONObject()
            o.put("id", item.id)
            o.put("title", item.title)
            o.put("amountTomans", item.amountTomans)
            o.put("createdAtMillis", item.createdAtMillis)
            o.put("systemDisplayName", item.systemDisplayName)
            o.put("note", item.note)
            arr.put(o)
        }
        return arr.toString()
    }

    fun decode(json: String?): List<DebtLineItem> {
        if (json.isNullOrBlank() || json.trim() == "[]") return emptyList()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<DebtLineItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    DebtLineItem(
                        id = o.optString("id", "item_${i + 1}"),
                        title = o.optString("title", "بدهی"),
                        amountTomans = o.optLong("amountTomans", 0L),
                        createdAtMillis = o.optLong("createdAtMillis", 0L),
                        systemDisplayName = o.optString("systemDisplayName", ""),
                        note = o.optString("note", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }
}

data class SessionSnackLine(
    val id: String,
    val snackName: String,
    val unitPrice: Long,
    val count: Int,
    val targetSeatId: String = "",
    val targetSeatName: String = ""
) {
    val totalPrice: Long get() = unitPrice * count
}

object SessionSnackCodec {
    fun encode(items: List<SessionSnackLine>): String {
        val arr = JSONArray()
        items.forEach { item ->
            val o = JSONObject()
            o.put("id", item.id)
            o.put("snackName", item.snackName)
            o.put("unitPrice", item.unitPrice)
            o.put("count", item.count)
            o.put("targetSeatId", item.targetSeatId)
            o.put("targetSeatName", item.targetSeatName)
            arr.put(o)
        }
        return arr.toString()
    }

    fun decode(json: String?): List<SessionSnackLine> {
        if (json.isNullOrBlank() || json.trim() == "[]") return emptyList()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<SessionSnackLine>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    SessionSnackLine(
                        id = o.optString("id", "snk_${i + 1}"),
                        snackName = o.optString("snackName", "خوراکی"),
                        unitPrice = o.optLong("unitPrice", 0L),
                        count = o.optInt("count", 1),
                        targetSeatId = o.optString("targetSeatId", ""),
                        targetSeatName = o.optString("targetSeatName", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }
}

@Entity(tableName = "game_systems")
data class GameSystemEntity(
    @PrimaryKey
    val id: Int,
    val code: String,
    val displayName: String,
    val systemType: String,
    val hourlyRatePerPlayer: Long,
    val flatRatePerHour: Long = 0,
    val iconType: String = "gamepad",
    val sortOrder: Int = 0
)

@Entity(tableName = "active_sessions")
data class ActiveSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val systemId: Int,
    val systemDisplayName: String,
    val playerCount: Int = 1,
    val startTimeMillis: Long,
    val durationMinutes: Int = 0,
    val expectedEndTimeMillis: Long = 0,
    val isCountDown: Boolean = true,
    val hourlyRateApplied: Long = 60000,
    val snacksCost: Long = 0,
    val snacksDetail: String = "",
    val targetAmountTomans: Long = 0,
    val customerName: String = "",
    val isAlarmDismissed: Boolean = false,
    val discountPercent: Int = 0,
    val isPaused: Boolean = false,
    val pausedAtMillis: Long = 0L,
    val segmentsJson: String = "[]",
    val currentSegmentStartMillis: Long = 0L,
    val playerSeatsJson: String = "[]",
    val modeConversionNotes: String = "",
    val nextAnonCounter: Int = 1,
    val sessionNote: String = "",
    val snacksItemsJson: String = "[]"
)

@Entity(tableName = "game_history")
data class GameHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val systemId: Int,
    val systemDisplayName: String,
    val playerCount: Int,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val playedMinutes: Int,
    val gameFee: Long,
    val snacksFee: Long,
    val totalFee: Long,
    val snacksDetail: String,
    val customerName: String,
    val dateIso: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val discountPercent: Int = 0,
    val discountAmount: Long = 0,
    val cashPaidTomans: Long = 0L,
    val debtSettledTomans: Long = 0L,
    val segmentsDetailJson: String = "[]",
    val entryType: String = "GAME",
    val cardPaidTomans: Long = 0L,
    val modeConversionNotes: String = "",
    val playerSeatsJson: String = "[]",
    val sessionNote: String = ""
)

@Entity(tableName = "snack_items")
data class SnackItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val priceTomans: Long,
    val category: String = "نوشیدنی",
    val icon: String = "drink"
)

@Entity(tableName = "customer_debts")
data class CustomerDebtEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val amountTomans: Long,
    val note: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val isSettled: Boolean = false,
    val settledAtMillis: Long = 0,
    val customerCode: String = "",
    val systemDisplayName: String = "",
    val playerCount: Int = 1,
    val playedMinutes: Int = 0,
    val gameFee: Long = 0L,
    val snacksFee: Long = 0L,
    val snacksDetail: String = "",
    val startTimeMillis: Long = 0L,
    val endTimeMillis: Long = 0L,
    val discountPercent: Int = 0,
    val discountAmount: Long = 0L,
    val segmentsDetailJson: String = "[]",
    val transferredToStats: Boolean = false,
    val debtItemsJson: String = "[]"
)

@Entity(tableName = "customer_credits")
data class CustomerCreditEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val customerCode: String = "",
    val amountTomans: Long,
    val note: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerCode: String,
    val name: String,
    val phone: String = "",
    val nationalId: String = "",
    val discountPercent: Int = 0,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "club_profile")
data class ClubProfileEntity(
    @PrimaryKey
    val id: Int = 1,
    val clubName: String = "",
    val managerName: String = "",
    val phoneNumber: String = "",
    val avatarUri: String = ""
)

@Entity(tableName = "custom_voice_commands")
data class CustomVoiceCommandEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val commandPhrase: String,
    val targetSystemId: Int,
    val targetSystemName: String,
    val playerCount: Int = 1,
    val durationMinutes: Int = 60,
    val isCountDown: Boolean = true,
    val mode: String = "TIME",
    val amountTomans: Long = 0L,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "bank_cards")
data class BankCardEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val bankName: String = "بانک",
    val cardNumber: String,
    val cardHolder: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cash_entries")
data class CashEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val amountTomans: Long,
    val note: String = "",
    val customerName: String = "",
    val source: String = "RECEIPT",
    val createdAtMillis: Long = System.currentTimeMillis()
)
