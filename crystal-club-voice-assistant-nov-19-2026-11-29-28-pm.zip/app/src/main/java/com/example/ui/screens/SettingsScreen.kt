package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CustomVoiceCommandEntity
import com.example.data.model.GameSystemEntity
import com.example.data.model.SnackItemEntity
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    systems: List<GameSystemEntity>,
    snacks: List<SnackItemEntity>,
    customCommands: List<CustomVoiceCommandEntity> = emptyList(),
    customerCount: Int = 0,
    onOpenCustomers: () -> Unit = {},
    onAddSystem: (name: String, type: String, rate: Long) -> Unit = { _, _, _ -> },
    onUpdateSystemRate: (GameSystemEntity) -> Unit,
    onAddSnack: (name: String, price: Long, category: String) -> Unit,
    onUpdateSnack: (SnackItemEntity) -> Unit,
    onDeleteSnack: (SnackItemEntity) -> Unit,
    onDeleteCustomCommand: (CustomVoiceCommandEntity) -> Unit = {},
    onExportBackup: suspend () -> String = { "" },
    onImportBackup: (String) -> Unit = {},
    onRequestBatteryOptimization: (Context) -> Unit,
    onRequestCleanExit: (Context) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var editingSystem by remember { mutableStateOf<GameSystemEntity?>(null) }
    var showAddSystemDialog by remember { mutableStateOf(false) }
    var editingSnack by remember { mutableStateOf<SnackItemEntity?>(null) }
    var showAddSnackDialog by remember { mutableStateOf(false) }
    var showExitConfirmDialog by remember { mutableStateOf(false) }
    var showHelpGuideDialog by remember { mutableStateOf(false) }

    // Backup & Restore Dialog States
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupJsonContent by remember { mutableStateOf("") }
    var backupStatusMsg by remember { mutableStateOf("") }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreJsonInput by remember { mutableStateOf("") }

    // SAF File Manager Export (.gnbackup)
    val saveBackupDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null && backupJsonContent.isNotBlank()) {
            coroutineScope.launch(Dispatchers.IO) {
                val ok = try {
                    context.contentResolver.openOutputStream(uri)?.use { os ->
                        os.write(backupJsonContent.toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                    true
                } catch (_: Exception) {
                    false
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        if (ok) "فایل پشتیبان با موفقیت در محل انتخابی ذخیره شد." else "خطا در ذخیره فایل پشتیبان",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    // SAF File Manager Import (.gnbackup or JSON)
    val openBackupDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                val text = try {
                    context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (_: Exception) {
                    null
                }
                withContext(Dispatchers.Main) {
                    if (!text.isNullOrBlank()) {
                        onImportBackup(text)
                        showRestoreDialog = false
                        Toast.makeText(context, "فایل پشتیبان انتخاب‌شده بازیابی شد.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "خطا در خواندن فایل انتخاب‌شده.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 84.dp),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            // Help Guide & Voice Commands Card
            item(key = "card_help_guide") {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.5.dp, CrystalCyan.copy(alpha = 0.65f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showHelpGuideDialog = true }
                        .testTag("open_help_guide_btn")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CrystalCyan.copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = CrystalCyan)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "راهنمایی و دستورات صوتی",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CrystalCyan
                                    ),
                                    maxLines = 1,
                                    softWrap = false
                                )
                                Text(
                                    text = "آموزش تغییر حالت، انتقال و ادغام، نفرات، کارتخوان و دستورات صوتی",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                )
                            }
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = "مشاهده راهنما", tint = CrystalCyan)
                    }
                }
            }

            // System Rates & Add System Section
            item(key = "header_systems") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        SectionHeader(
                            title = "تعیین نرخ و کد هر دستگاه (ساعتی)",
                            subtitle = "کدگذاری ترتیبی از ۱ به بالا جهت کنترل صوتی"
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { showAddSystemDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("add_new_system_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "دستگاه جدید",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            items(systems, key = { "sys_${it.id}" }) { sys ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = sys.displayName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "کد سیستم: ${sys.code} | نوع: ${sys.systemType}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${formatNumber(sys.hourlyRatePerPlayer)} ت",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrystalCyan
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = { editingSystem = sys },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "ویرایش نرخ", tint = CrystalCyan)
                            }
                        }
                    }
                }
            }

            // Snacks Catalog Section
            item(key = "header_snacks") {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        SectionHeader(
                            title = "منوی بوفه و مبالغ خوراکی‌ها",
                            subtitle = "آبمیوه، کیک، ریدبول، چیپس، چای و..."
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { showAddSnackDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "خوراکی جدید",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            items(snacks, key = { "snack_${it.id}" }) { snack ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = snack.name,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "دسته: ${snack.category}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${formatNumber(snack.priceTomans)} ت",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrystalAmber
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = { editingSnack = snack },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "ویرایش", tint = CrystalCyan, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { onDeleteSnack(snack) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = TextTertiary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            // Custom Voice Commands Section
            if (customCommands.isNotEmpty()) {
                item(key = "header_custom_cmds") {
                    Spacer(modifier = Modifier.height(6.dp))
                    SectionHeader(
                        title = "دستورات صوتی سفارشی ذخیره شده",
                        subtitle = "دستوراتی که در دستیار آنلاین و آفلاین کار می‌کنند"
                    )
                }

                items(customCommands, key = { "cmd_${it.id}" }) { cmd ->
                    val modeDesc = when (cmd.mode) {
                        "OPEN" -> "ساعت آزاد"
                        "AMOUNT" -> "مبلغ ${formatNumber(cmd.amountTomans)} ت"
                        else -> "${cmd.durationMinutes} دقیقه"
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, CrystalPurple.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("«${cmd.commandPhrase}»", fontWeight = FontWeight.Bold, color = CrystalAmber)
                                Text(
                                    text = "اجرای: ${cmd.targetSystemName} | ${cmd.playerCount} نفره | $modeDesc",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            IconButton(onClick = { onDeleteCustomCommand(cmd) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف دستور", tint = TextTertiary)
                            }
                        }
                    }
                }
            }

            // Persistence & Performance Section
            item(key = "header_battery") {
                Spacer(modifier = Modifier.height(6.dp))
                SectionHeader(
                    title = "پایداری، اولویت اجرا و باتری",
                    subtitle = "جلوگیری از بسته شدن خودکار برنامه توسط سیستم‌عامل"
                )
            }

            item(key = "card_battery") {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, GamingBorderGlow),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "تنظیم اولویت بالا و عدم اعمال محدودیت باتری",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = CrystalCyan
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "جهت جلوگیری از بسته شدن برنامه در پس‌زمینه و قطع نشدن آلارم‌های صوتی، معافیت مصرف باتری را فعال نمایید.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { onRequestBatteryOptimization(context) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalCyan),
                            border = BorderStroke(1.dp, CrystalCyan),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "غیرفعال‌سازی بهینه‌سازی باتری",
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Advanced Backup & Restore Section
            item(key = "header_backup") {
                Spacer(modifier = Modifier.height(6.dp))
                SectionHeader(
                    title = "پشتیبان‌گیری جامع و فایل‌منیجر",
                    subtitle = "ذخیره فایل .gnbackup در Download/GamenetBackapp یا پوشه دلخواه"
                )
            }

            item(key = "card_backup") {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, CrystalGreen.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "پشتیبان‌گیری و بازیابی کل اطلاعات برنامه",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = CrystalGreen
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تمامی سیستم‌ها، آمار فروش، مبالغ نقدی، مشتریان، بدهی‌ها، بوفه، تنظیمات و دستورات صوتی بصورت کامل ذخیره و بازیابی می‌شوند.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        val json = onExportBackup()
                                        backupJsonContent = json
                                        val savedPath = withContext(Dispatchers.IO) {
                                            saveBackupToGamenetFolder(context, json)
                                        }
                                        backupStatusMsg = if (savedPath != null) {
                                            "فایل در مسیر $savedPath ذخیره شد."
                                        } else {
                                            "بکاپ آماده است؛ می‌توانید با فایل‌منیجر ذخیره یا اشتراک‌گذاری کنید."
                                        }
                                        showBackupDialog = true
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_backup_btn")
                            ) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "تهیه پشتیبان",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }

                            Button(
                                onClick = { showRestoreDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("open_restore_btn")
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "بازیابی اطلاعات",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }
            }

            // Clean Exit App Section
            item(key = "card_exit") {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { showExitConfirmDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("app_exit_button")
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "خروج و بستن کامل برنامه",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }

    // Add New System Dialog
    if (showAddSystemDialog) {
        AddNewSystemDialog(
            nextCode = ((systems.maxOfOrNull { it.id } ?: 14) + 1).toString(),
            onDismiss = { showAddSystemDialog = false },
            onConfirm = { name, type, rate ->
                onAddSystem(name, type, rate)
                showAddSystemDialog = false
            }
        )
    }

    // Backup Result Dialog
    if (showBackupDialog) {
        Dialog(onDismissRequest = { showBackupDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("فایل پشتیبان جامع آماده شد", color = CrystalGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    if (backupStatusMsg.isNotBlank()) {
                        Text(backupStatusMsg, color = CrystalAmber, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCard,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    ) {
                        Box(modifier = Modifier.verticalScroll(rememberScrollState())) {
                            Text(
                                text = backupJsonContent,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 10.sp),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                            saveBackupDocumentLauncher.launch("GamenetBackup_$stamp.gnbackup")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ذخیره با فایل‌منیجر در پوشه دلخواه", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1, softWrap = false)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("GameNetBackup", backupJsonContent)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "کد بکاپ در کلیپ‌بورد کپی شد.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("کپی متن", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }

                        Button(
                            onClick = {
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, backupJsonContent)
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, "اشتراک‌گذاری فایل پشتیبان مدیریت گیم‌نت")
                                context.startActivity(shareIntent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("اشتراک‌گذاری", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = { showBackupDialog = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("بستن", maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }

    // Restore Dialog
    if (showRestoreDialog) {
        Dialog(onDismissRequest = { showRestoreDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("بازیابی اطلاعات از فایل پشتیبان", color = CrystalCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            openBackupDocumentLauncher.launch(arrayOf("*/*"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pick_backup_file_btn")
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("انتخاب فایل .gnbackup از فایل‌منیجر", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1, softWrap = false)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("یا متن بکاپ را در کادر زیر وارد نمایید:", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = restoreJsonInput,
                        onValueChange = { restoreJsonInput = it },
                        placeholder = { Text("کد جیسون بکاپ را اینجا Paste کنید...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalCyan,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showRestoreDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("انصراف", maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = {
                                if (restoreJsonInput.isNotBlank()) {
                                    onImportBackup(restoreJsonInput)
                                    showRestoreDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("اجرای ریستور", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }

    // Edit System Rate Dialog
    if (editingSystem != null) {
        val sys = editingSystem!!
        var rateText by remember { mutableStateOf(sys.hourlyRatePerPlayer.toString()) }

        Dialog(onDismissRequest = { editingSystem = null }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GamingSurface,
                border = BorderStroke(1.dp, CrystalCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "ویرایش نرخ: ${sys.displayName} (کد ${sys.code})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = CrystalCyan
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = rateText,
                        onValueChange = { rateText = it.filter { c -> c.isDigit() } },
                        label = { Text("نرخ ساعتی به ازای هر نفر (تومان)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalCyan,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { editingSystem = null },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("انصراف", maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = {
                                val newRate = rateText.toLongOrNull() ?: sys.hourlyRatePerPlayer
                                onUpdateSystemRate(sys.copy(hourlyRatePerPlayer = newRate))
                                editingSystem = null
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan)
                        ) {
                            Text("ذخیره", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Snack Dialog
    if (showAddSnackDialog || editingSnack != null) {
        var snackName by remember { mutableStateOf(editingSnack?.name ?: "") }
        var snackPriceText by remember { mutableStateOf(editingSnack?.priceTomans?.toString() ?: "") }
        var snackCat by remember { mutableStateOf(editingSnack?.category ?: "خوراکی") }

        Dialog(onDismissRequest = {
            showAddSnackDialog = false
            editingSnack = null
        }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GamingSurface,
                border = BorderStroke(1.dp, CrystalAmber),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (editingSnack != null) "ویرایش خوراکی" else "افزودن خوراکی جدید به بوفه",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = CrystalAmber
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = snackName,
                        onValueChange = { snackName = it },
                        label = { Text("نام خوراکی (مثلا آبمیوه، کیک)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalAmber,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = snackPriceText,
                        onValueChange = { snackPriceText = it.filter { c -> c.isDigit() } },
                        label = { Text("قیمت (تومان)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalAmber,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                showAddSnackDialog = false
                                editingSnack = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("انصراف", maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = {
                                val p = snackPriceText.toLongOrNull() ?: 0L
                                if (snackName.isNotBlank() && p > 0) {
                                    if (editingSnack != null) {
                                        onUpdateSnack(editingSnack!!.copy(name = snackName, priceTomans = p, category = snackCat))
                                    } else {
                                        onAddSnack(snackName, p, snackCat)
                                    }
                                    showAddSnackDialog = false
                                    editingSnack = null
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber)
                        ) {
                            Text("ذخیره", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }

    // Exit Confirm Dialog
    if (showExitConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showExitConfirmDialog = false },
            title = {
                Text("خروج کامل از برنامه", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "آیا مطمئن هستید؟ با خروج کامل، سرویس پس‌زمینه و تایمرها بسته خواهند شد.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExitConfirmDialog = false
                        onRequestCleanExit(context)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalRed)
                ) {
                    Text("بستن کامل برنامه", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showExitConfirmDialog = false }) {
                    Text("انصراف", maxLines = 1, softWrap = false)
                }
            },
            containerColor = GamingSurface
        )
    }

    if (showHelpGuideDialog) {
        HelpGuideDialog(onDismiss = { showHelpGuideDialog = false })
    }
}

@Composable
private fun HelpGuideDialog(onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 620.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "راهنمای کامل برنامه و دستورات صوتی",
                        color = CrystalCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                GuideSectionCard(
                    title = "۱. دستورات صوتی جدید تغییر حالت تایمر",
                    accent = CrystalPurple,
                    body = "• تبدیل آزاد به معکوس: «کد ۴ آزاد به معکوس ۶۰ دقیقه» (زمان سپری‌شده کسر و باقیمانده تایمر می‌شود)\n" +
                        "• تبدیل معکوس به آزاد: «کد ۴ معکوس به آزاد» (زمان از ساعت شروع اولیه آزاد می‌چرخد)\n" +
                        "• مبلغ به تایم در حین بازی: «کد ۴ ؛ ۱۰۰ هزار تومن به تایم» یا «کد ۴ ؛ ۱۰۰ تومن به تایم»"
                )

                GuideSectionCard(
                    title = "۲. انتقال و ادغام بین سیستم‌ها (حتی سیستم مشغول)",
                    accent = CrystalCyan,
                    body = "• از منوی سه نقطه (⋮) روی کارت هر سیستم یا دکمه «انتقال به سیستم دیگر» استفاده کنید.\n" +
                        "• می‌توانید نام یا کد مشتری را تایپ یا صوتی وارد کنید (در صورت خالی بودن «ناشناس» ثبت می‌شود).\n" +
                        "• با انتخاب سیستم مقصد مشغول، فرد انتقالی با فاکتور قبلی خود به دستگاه جدید اضافه شده و سهم او در فاکتور نهایی تفکیک می‌شود."
                )

                GuideSectionCard(
                    title = "۳. افزایش/کاهش نفر (+ / - + تایید) و فاکتور خروج",
                    accent = CrystalGreen,
                    body = "• تعداد نفرات را با +/- تغییر داده و دکمه «تایید» را بزنید.\n" +
                        "• گزینه «از ابتدا» برای اصلاح از شروع بازی و گزینه «از الان» برای اعمال از همین لحظه است.\n" +
                        "• هنگام خروج یک بازیکن با «از الان»، فاکتور کوچک برای همان نفر صادر شده و بعد از تسویه از فاکتور اصلی کم می‌شود."
                )

                GuideSectionCard(
                    title = "۴. کارتخوان (POS)، دفتر نسیه و طلب مشتری",
                    accent = CrystalAmber,
                    body = "• مبلغ «کسر کارتخوان» از باقیمانده کم می‌شود ولی در «جمع نقدی روزانه» لحاظ نمی‌شود.\n" +
                        "• در «دفتر نسیه» علاوه بر بدهی‌ها می‌توانید برای مشتری «طلب» ثبت کنید تا در فاکتور بعدی خودکار کسر شود و تراز خالص نمایش یابد.\n" +
                        "• با زدن «تسویه شد» فاکتور به آمار فروش رفته و از دفتر نسیه پاک می‌شود."
                )

                GuideSectionCard(
                    title = "۵. ثبت خدمات جانبی گیم‌نت (درآمد غیربازی)",
                    accent = CrystalMagenta,
                    body = "• در صفحه «آمار فروش»، دکمه «خدمات» برای ثبت خدماتی مانند نصب بازی PS/PC، نصب ویندوز، آهنگ و فیلم یا تعمیر دسته قرار دارد.\n" +
                        "• می‌توانید خدمات را نقدی یا کارتخوان ثبت کنید تا تفکیک آن در نمودار ساعتی و گزارش کلی نمایش داده شود."
                )

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("متوجه شدم", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

@Composable
private fun GuideSectionCard(title: String, accent: Color, body: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = GamingCard,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = title, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Text(text = body, color = TextSecondary, fontSize = 11.sp, lineHeight = 18.sp)
        }
    }
}

private fun saveBackupToGamenetFolder(context: Context, jsonContent: String): String? {
    val fileName = "GamenetBackup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.gnbackup"
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/GamenetBackapp")
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            context.contentResolver.openOutputStream(uri)?.use { os ->
                os.write(jsonContent.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            "Download/GamenetBackapp/$fileName"
        } else {
            val dir = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir,
                "GamenetBackapp"
            )
            if (!dir.exists()) dir.mkdirs()
            val outFile = File(dir, fileName)
            FileOutputStream(outFile).use { fos ->
                fos.write(jsonContent.toByteArray(Charsets.UTF_8))
                fos.flush()
            }
            outFile.absolutePath
        }
    } catch (_: Exception) {
        null
    }
}

@Composable
fun AddNewSystemDialog(
    nextCode: String,
    onDismiss: () -> Unit,
    onConfirm: (name: String, type: String, rate: Long) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("PS4") }
    var rateText by remember { mutableStateOf("60000") }

    val typeDefaults = listOf(
        Triple("PS4", "پی‌اس۴", "60000"),
        Triple("PS5", "پی‌اس۵", "70000"),
        Triple("PC", "کامپیوتر", "60000"),
        Triple("VR", "عینک VR", "120000"),
        Triple("WHEEL", "فرمان", "100000")
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "افزودن دستگاه جدید (کد سیستم: $nextCode)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = CrystalCyan
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                Text("نوع دستگاه:", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    typeDefaults.forEach { (typeKey, label, defaultRate) ->
                        val isSel = selectedType == typeKey
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) CrystalCyan else GamingCard)
                                .clickable {
                                    selectedType = typeKey
                                    rateText = defaultRate
                                }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) Color.Black else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام دستگاه (مثلاً پی اس فور ۷ یا کامپیوتر ۵)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = rateText,
                    onValueChange = { rateText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("نرخ ساعتی هر نفر (تومان)", fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            val rate = rateText.toLongOrNull() ?: 60000L
                            val finalName = name.ifBlank { "سیستم $nextCode" }
                            onConfirm(finalName, selectedType, rate)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("افزودن دستگاه", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = CrystalCyan
            )
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
        )
    }
}

private fun formatNumber(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
