package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HeaderHeroBanner(
    activeSystemsCount: Int,
    totalSystemsCount: Int,
    isVoiceListening: Boolean,
    clubName: String = "مدیریت گیم‌نت",
    onVoiceClick: () -> Unit,
    onDeveloperInfoClick: () -> Unit,
    onProfileClick: () -> Unit,
    onOpenCalculator: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var currentTimeString by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            currentTimeString = sdf.format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "voice_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isVoiceListening) 1.22f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
    ) {
        // Gaming Hero Wallpaper
        Image(
            painter = painterResource(id = R.drawable.img_gaming_hero),
            contentDescription = "پس‌زمینه گیم‌نت",
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize()
        )

        // Dark contrast gradient overlay
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            GamingBackground.copy(alpha = 0.62f),
                            GamingBackground.copy(alpha = 0.94f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Header Area:
            // In RTL: Start = Top-Right (Developer Info small circle + Mini Calculator), Center = Logo + Club Name (non-clickable), End = Top-Left (Profile + larger Clock below)
            Box(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Top-Right (Start in RTL): Small Circular Developer Info + Mini Calculator pill
                Row(
                    modifier = Modifier.align(Alignment.TopStart),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = GamingCard.copy(alpha = 0.92f),
                        border = BorderStroke(1.2.dp, CrystalAmber.copy(alpha = 0.85f)),
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onDeveloperInfoClick)
                            .testTag("developer_info_chip")
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = "مشخصات سازنده",
                                tint = CrystalAmber,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "سازنده",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 8.5.sp
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    Surface(
                        shape = CircleShape,
                        color = GamingCard.copy(alpha = 0.92f),
                        border = BorderStroke(1.2.dp, CrystalCyan.copy(alpha = 0.85f)),
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onOpenCalculator)
                            .testTag("header_calculator_btn")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Calculate,
                                contentDescription = "ماشین حساب",
                                tint = CrystalCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Top-Center: App Icon + GameNet Name directly below (NOT clickable to open profile)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 96.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .border(1.8.dp, CrystalCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_crystal_logo),
                            contentDescription = "لوگوی برنامه",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = clubName.ifBlank { "مدیریت گیم‌نت" },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = CrystalCyan,
                            fontSize = 15.sp
                        ),
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "مدیریت هوشمند صوتی",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontSize = 10.sp
                        ),
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Top-Left (End in RTL): Profile Pill + Larger Digital Clock right below it
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCard.copy(alpha = 0.92f),
                        border = BorderStroke(1.dp, CrystalMagenta.copy(alpha = 0.8f)),
                        modifier = Modifier
                            .clickable(onClick = onProfileClick)
                            .testTag("club_profile_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = CrystalMagenta,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "پروفایل",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalMagenta,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    // Larger Digital Clock below Profile
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCard.copy(alpha = 0.9f),
                        border = BorderStroke(1.dp, GamingBorderGlow)
                    ) {
                        Text(
                            text = currentTimeString,
                            fontFamily = OrbitronFontFamily,
                            color = CrystalCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // Bottom Row: Active Systems Badge & Glowing Mic Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCardElevated.copy(alpha = 0.92f),
                    border = BorderStroke(1.dp, GamingBorderGlow)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (activeSystemsCount > 0) CrystalGreen else TextTertiary)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$activeSystemsCount سیستم فعال از $totalSystemsCount",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 12.sp
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isVoiceListening) "در حال شنیدن..." else "دستیار صوتی",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isVoiceListening) CrystalMagenta else CrystalCyan,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(end = 8.dp)
                    )

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size((46 * pulseScale).dp)
                            .clip(CircleShape)
                            .background(
                                if (isVoiceListening) Brush.radialGradient(
                                    listOf(CrystalMagenta, CrystalPurple)
                                ) else Brush.radialGradient(
                                    listOf(CrystalCyan, CrystalCyanDark)
                                )
                            )
                            .clickable(onClick = onVoiceClick)
                            .testTag("voice_assistant_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "دستیار صوتی گیم نت",
                            tint = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}
