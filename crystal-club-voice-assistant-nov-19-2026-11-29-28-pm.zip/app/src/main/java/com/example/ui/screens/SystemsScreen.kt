package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.SystemCard
import com.example.ui.theme.*
import com.example.viewmodel.SystemWithSession

@Composable
fun SystemsScreen(
    systemsWithSessions: List<SystemWithSession>,
    onSystemClick: (SystemWithSession) -> Unit,
    onStopAlarm: (Int) -> Unit,
    onTransferSystemClick: (SystemWithSession) -> Unit = {},
    onOpenVoiceAssistant: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("همه") }
    val filters = listOf("همه", "پلی‌استیشن", "کامپیوتر", "عینک و فرمان", "فقط در حال بازی", "فقط آزاد")

    val filteredList = remember(systemsWithSessions, selectedFilter) {
        when (selectedFilter) {
            "پلی‌استیشن" -> systemsWithSessions.filter { it.system.systemType in listOf("PS4", "PS5") }
            "کامپیوتر" -> systemsWithSessions.filter { it.system.systemType == "PC" }
            "عینک و فرمان" -> systemsWithSessions.filter { it.system.systemType in listOf("VR", "WHEEL") }
            "فقط در حال بازی" -> systemsWithSessions.filter { it.session != null }
            "فقط آزاد" -> systemsWithSessions.filter { it.session == null }
            else -> systemsWithSessions
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Filters Bar
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filters, key = { "filter_$it" }) { f ->
                val isSelected = selectedFilter == f
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) CrystalCyan else GamingCard,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) CrystalCyan else GamingBorder
                    ),
                    modifier = Modifier.clickable { selectedFilter = f }
                ) {
                    Text(
                        text = f,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color.Black else TextPrimary,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Systems List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(filteredList, key = { "sys_${it.system.id}" }) { item ->
                SystemCard(
                    item = item,
                    onClick = { onSystemClick(item) },
                    onStopAlarm = { onStopAlarm(item.system.id) },
                    onTransferClick = { onTransferSystemClick(item) }
                )
            }
        }
    }
}
