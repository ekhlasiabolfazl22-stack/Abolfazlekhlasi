package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Crystal Gaming Palette
val CrystalCyan = Color(0xFF00F0FF)
val CrystalCyanDark = Color(0xFF0098A6)
val CrystalMagenta = Color(0xFFFF2A85)
val CrystalPurple = Color(0xFF9D4EDD)
val CrystalGreen = Color(0xFF00E676)
val CrystalAmber = Color(0xFFFFB300)
val CrystalRed = Color(0xFFFF3366)

val GamingBackground = Color(0xFF0A0E17)
val GamingSurface = Color(0xFF111827)
val GamingCard = Color(0xFF161F30)
val GamingCardElevated = Color(0xFF1E293B)
val GamingBorder = Color(0xFF2A3B55)
val GamingBorderGlow = Color(0xFF00F0FF).copy(alpha = 0.35f)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
