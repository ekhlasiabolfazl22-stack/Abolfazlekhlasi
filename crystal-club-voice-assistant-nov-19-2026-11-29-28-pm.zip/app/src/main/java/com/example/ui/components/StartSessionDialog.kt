package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.GameSystemEntity
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import java.util.Calendar
import java.util.Locale

enum class StartMode {
    BY_TIME,
    BY_AMOUNT,
    OPEN_ENDED
}

@Composable
fun StartSessionDialog(
    system: GameSystemEntity,
    onDismiss: () -> Unit,
    onStartByDuration: (players: Int, minutes: Int, customer: String) -> Unit,
    onStartByAmount: (players: Int, amount: Long, customer: String) -> Unit,
    onStartOpenEnded: (players: Int, customer: String) -> Unit,
    onStartCustomTime: ((mode: StartMode, players: Int, durationMinutes: Int, amountTomans: Long, customer: String, startTimeMillis: Long) -> Unit)? = null
) {
    var mode by remember { mutableStateOf(StartMode.BY_TIME) }
    var selectedPlayers by remember { mutableIntStateOf(1) }
    var customerName by remember { mutableStateOf("") }

    // Custom Start Time («شروع از »)
    val nowCal = remember { Calendar.getInstance() }
    var useCustomStartTime by remember { mutableStateOf(false) }
    var startHourText by remember { mutableStateOf(String.format(Locale.US, "%02d", nowCal.get(Calendar.HOUR_OF_DAY))) }
    var startMinuteText by remember { mutableStateOf(String.format(Locale.US, "%02d", nowCal.get(Calendar.MINUTE))) }

    // By Time
    val timeOptions = listOf(15, 30, 45, 60, 90, 120, 180)
    var selectedMinutes by remember { mutableIntStateOf(60) }
    var customMinutesInput by remember { mutableStateOf("") }

    // By Amount
    val amountOptions = listOf(30000L, 50000L, 70000L, 100000L, 150000L, 200000L)
    var selectedAmount by remember { mutableLongStateOf(100000L) }
    var customAmountInput by remember { mutableStateOf("") }

    // Computed duration preview if by amount
    val ratePerHour = system.hourlyRatePerPlayer * selectedPlayers
    val previewMinutesFromAmount = if (ratePerHour > 0) {
        val amt = customAmountInput.toLongOrNull() ?: selectedAmount
        ((amt.toDouble() / ratePerHour.toDouble()) * 60).toInt()
    } else 60

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(22.dp),
            color = GamingSurface,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, CrystalCyanDark)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "شروع بازی: ${system.displayName}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = CrystalCyan
                            )
                        )
                        Text(
                            text = "نرخ: ساعتی ${formatNumber(system.hourlyRatePerPlayer)} ت به ازای هر نفر",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(GamingCard),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val tabs = listOf(
                        Triple(StartMode.BY_TIME, "تایم دلخواه", "time_mode_btn"),
                        Triple(StartMode.BY_AMOUNT, "مبلغ دلخواه", "amount_mode_btn"),
                        Triple(StartMode.OPEN_ENDED, "ساعت آزاد", "open_mode_btn")
                    )
                    tabs.forEach { (m, label, tag) ->
                        val isSelected = mode == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) CrystalCyan else Color.Transparent)
                                .clickable { mode = m }
                                .padding(vertical = 8.dp)
                                .testTag(tag),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.Black else TextSecondary
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Player Count Selector
                Text(
                    text = "تعداد نفرات:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    (1..4).forEach { p ->
                        val isSelected = selectedPlayers == p
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) CrystalPurple else GamingCard,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) CrystalMagenta else GamingBorder
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedPlayers = p }
                                .testTag("player_select_$p")
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$p نفر",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSelected) Color.White else TextPrimary,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Specific Controls
                when (mode) {
                    StartMode.BY_TIME -> {
                        Text(
                            text = "مدت زمان بازی (تایمر معکوس):",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(timeOptions, key = { "time_$it" }) { mins ->
                                val isSelected = selectedMinutes == mins && customMinutesInput.isBlank()
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) CrystalCyan else GamingCard,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) CrystalCyan else GamingBorder
                                    ),
                                    modifier = Modifier.clickable {
                                        selectedMinutes = mins
                                        customMinutesInput = ""
                                    }
                                ) {
                                    Text(
                                        text = if (mins >= 60 && mins % 60 == 0) "${mins / 60} ساعت" else "$mins دقیقه",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isSelected) Color.Black else TextPrimary,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customMinutesInput,
                            onValueChange = { customMinutesInput = it },
                            label = { Text("تایم دلخواه دیگر (به دقیقه)", fontSize = 12.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrystalCyan,
                                unfocusedBorderColor = GamingBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }

                    StartMode.BY_AMOUNT -> {
                        Text(
                            text = "مبلغ مورد نظر مشتری (تومان):",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(amountOptions, key = { "amt_$it" }) { amt ->
                                val isSelected = selectedAmount == amt && customAmountInput.isBlank()
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) CrystalCyan else GamingCard,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) CrystalCyan else GamingBorder
                                    ),
                                    modifier = Modifier.clickable {
                                        selectedAmount = amt
                                        customAmountInput = ""
                                    }
                                ) {
                                    Text(
                                        text = "${formatNumber(amt)} ت",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isSelected) Color.Black else TextPrimary,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customAmountInput,
                            onValueChange = { customAmountInput = it },
                            label = { Text("مبلغ دلخواه دیگر (به تومان)", fontSize = 12.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrystalCyan,
                                unfocusedBorderColor = GamingBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CrystalCyan.copy(alpha = 0.1f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⏱️ معادل زمان بازی: حدود $previewMinutesFromAmount دقیقه",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalCyan,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    StartMode.OPEN_ENDED -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GamingCard,
                            border = androidx.compose.foundation.BorderStroke(1.dp, GamingBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "حالت تایمر باز (ساعت شروع)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = CrystalGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "تایم بازی از لحظه شروع تا هنگام اعلام پایان محاسبه خواهد شد و مبلغ طبق دقایق دقیق بازی محاسبه می‌گردد.",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Start Time ("شروع از ")
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = GamingCard,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (useCustomStartTime) CrystalAmber.copy(alpha = 0.7f) else GamingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { useCustomStartTime = !useCustomStartTime }
                                    .testTag("toggle_custom_start_time")
                            ) {
                                Checkbox(
                                    checked = useCustomStartTime,
                                    onCheckedChange = { useCustomStartTime = it },
                                    colors = CheckboxDefaults.colors(checkedColor = CrystalAmber),
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "شروع از ساعت دلخواه (اختیاری)",
                                    color = if (useCustomStartTime) CrystalAmber else TextSecondary,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }

                            if (useCustomStartTime) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    OutlinedTextField(
                                        value = startMinuteText,
                                        onValueChange = { txt ->
                                            val clean = PersianDateUtils.toAsciiDigits(txt).filter { it.isDigit() }.take(2)
                                            startMinuteText = clean
                                        },
                                        label = { Text("دقیقه", fontSize = 9.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier
                                            .width(64.dp)
                                            .testTag("custom_start_minute_input")
                                    )
                                    Text(":", color = CrystalAmber, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    OutlinedTextField(
                                        value = startHourText,
                                        onValueChange = { txt ->
                                            val clean = PersianDateUtils.toAsciiDigits(txt).filter { it.isDigit() }.take(2)
                                            startHourText = clean
                                        },
                                        label = { Text("ساعت", fontSize = 9.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier
                                            .width(64.dp)
                                            .testTag("custom_start_hour_input")
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Optional Customer Name
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("نام مشتری یا کد (اختیاری)", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Start Button
                Button(
                    onClick = {
                        val resolvedStartMillis = if (useCustomStartTime) {
                            val hh = (startHourText.toIntOrNull() ?: nowCal.get(Calendar.HOUR_OF_DAY)).coerceIn(0, 23)
                            val mm = (startMinuteText.toIntOrNull() ?: nowCal.get(Calendar.MINUTE)).coerceIn(0, 59)
                            Calendar.getInstance().apply {
                                set(Calendar.HOUR_OF_DAY, hh)
                                set(Calendar.MINUTE, mm)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }.timeInMillis
                        } else {
                            System.currentTimeMillis()
                        }
                        val mins = customMinutesInput.toIntOrNull() ?: selectedMinutes
                        val amt = customAmountInput.toLongOrNull() ?: selectedAmount
                        if (onStartCustomTime != null) {
                            onStartCustomTime(mode, selectedPlayers, mins, amt, customerName, resolvedStartMillis)
                        } else {
                            when (mode) {
                                StartMode.BY_TIME -> onStartByDuration(selectedPlayers, mins, customerName)
                                StartMode.BY_AMOUNT -> onStartByAmount(selectedPlayers, amt, customerName)
                                StartMode.OPEN_ENDED -> onStartOpenEnded(selectedPlayers, customerName)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_start_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "شروع", tint = Color.Black)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "شروع بازی در ${system.displayName}",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}

private fun formatNumber(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
