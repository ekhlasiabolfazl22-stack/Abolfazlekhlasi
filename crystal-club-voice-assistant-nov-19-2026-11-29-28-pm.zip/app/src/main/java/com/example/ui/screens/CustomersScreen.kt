package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.data.model.BankCardEntity
import com.example.data.model.CustomerCreditEntity
import com.example.data.model.CustomerDebtEntity
import com.example.data.model.CustomerEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.CustomerDebtBreakdownDialog
import com.example.ui.components.EditCustomerDialog
import com.example.ui.components.PhoneContactsPickerDialog
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.random.Random

enum class CustomerSubTab {
    DIRECTORY,
    SEND_DEBT_SMS,
    SET_DISCOUNT,
    SEND_DISCOUNT_SMS,
    LUCKY_WHEEL
}

@Composable
fun CustomersScreen(
    customers: List<CustomerEntity>,
    debts: List<CustomerDebtEntity>,
    bankCards: List<BankCardEntity>,
    clubName: String,
    credits: List<CustomerCreditEntity> = emptyList(),
    voiceSearchHint: String = "",
    voiceSearchTarget: String = "",
    onRequestVoiceForSearch: (String) -> Unit = {},
    onAddCustomer: (code: String, name: String, phone: String, nationalId: String, discountPercent: Int) -> Unit,
    onUpdateCustomer: (CustomerEntity) -> Unit,
    onDeleteCustomer: (CustomerEntity) -> Unit,
    onUpdateDebt: (CustomerDebtEntity) -> Unit = {},
    onDeleteDebt: (CustomerDebtEntity) -> Unit = {},
    onAddBankCard: (bankName: String, cardNumber: String, cardHolder: String) -> Unit,
    onDeleteBankCard: (BankCardEntity) -> Unit,
    onBackToSettings: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var subTab by remember { mutableStateOf(CustomerSubTab.DIRECTORY) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var prefillContactName by remember { mutableStateOf("") }
    var prefillContactPhone by remember { mutableStateOf("") }
    var showContactsPicker by remember { mutableStateOf(false) }
    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var deletingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var debtBreakdownCustomer by remember { mutableStateOf<CustomerEntity?>(null) }

    if (onBackToSettings != null) {
        BackHandler { onBackToSettings() }
    }

    val contactsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            showContactsPicker = true
        } else {
            Toast.makeText(context, "برای انتخاب مشتری از مخاطبین، مجوز دسترسی به مخاطبین را تایید کنید.", Toast.LENGTH_SHORT).show()
        }
    }

    fun openContactsPickerWithPermission() {
        val hasPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
        if (hasPerm) {
            showContactsPicker = true
        } else {
            contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        if (onBackToSettings != null) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = GamingCardElevated,
                border = BorderStroke(1.dp, CrystalMagenta.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onBackToSettings() }
                    .testTag("customers_back_to_settings_btn")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = CrystalMagenta,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بازگشت به تنظیمات",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = CrystalMagenta,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    Text(
                        text = "باشگاه مشتریان (${customers.size})",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Sub Tabs Header
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val tabs = listOf(
                Pair(CustomerSubTab.DIRECTORY, "لیست مشتریان"),
                Pair(CustomerSubTab.SEND_DEBT_SMS, "ارسال بدهی با پیامک"),
                Pair(CustomerSubTab.SET_DISCOUNT, "تخفیف مشتری"),
                Pair(CustomerSubTab.SEND_DISCOUNT_SMS, "پیامک تخفیف"),
                Pair(CustomerSubTab.LUCKY_WHEEL, "گردونه قرعه‌کشی")
            )
            items(tabs, key = { "cust_subtab_${it.first.name}" }) { (tab, title) ->
                val isSelected = subTab == tab
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) CrystalCyan else GamingCard,
                    border = BorderStroke(1.dp, if (isSelected) CrystalCyan else GamingBorder),
                    modifier = Modifier.clickable { subTab = tab }
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color.Black else TextPrimary,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (subTab) {
            CustomerSubTab.DIRECTORY -> {
                CustomersDirectoryView(
                    customers = customers,
                    debts = debts,
                    credits = credits,
                    voiceSearchHint = if (voiceSearchTarget == CustomerSubTab.DIRECTORY.name) voiceSearchHint else "",
                    onRequestVoiceForSearch = { onRequestVoiceForSearch(CustomerSubTab.DIRECTORY.name) },
                    onAddClick = {
                        prefillContactName = ""
                        prefillContactPhone = ""
                        showAddCustomerDialog = true
                    },
                    onImportFromContactsClick = { openContactsPickerWithPermission() },
                    onEditCustomer = { editingCustomer = it },
                    onDeleteRequest = { deletingCustomer = it },
                    onDebtBreakdownClick = { debtBreakdownCustomer = it }
                )
            }
            CustomerSubTab.SEND_DEBT_SMS -> {
                SendDebtSmsView(
                    customers = customers,
                    debts = debts,
                    credits = credits,
                    bankCards = bankCards,
                    clubName = clubName,
                    voiceSearchHint = if (voiceSearchTarget == CustomerSubTab.SEND_DEBT_SMS.name) voiceSearchHint else "",
                    onRequestVoiceForSearch = { onRequestVoiceForSearch(CustomerSubTab.SEND_DEBT_SMS.name) },
                    onAddBankCard = onAddBankCard,
                    onDeleteBankCard = onDeleteBankCard
                )
            }
            CustomerSubTab.SET_DISCOUNT -> {
                CustomerDiscountView(
                    customers = customers,
                    voiceSearchHint = if (voiceSearchTarget == CustomerSubTab.SET_DISCOUNT.name) voiceSearchHint else "",
                    onRequestVoiceForSearch = { onRequestVoiceForSearch(CustomerSubTab.SET_DISCOUNT.name) },
                    onUpdateCustomer = onUpdateCustomer
                )
            }
            CustomerSubTab.SEND_DISCOUNT_SMS -> {
                SendDiscountSmsView(
                    customers = customers,
                    clubName = clubName,
                    voiceSearchHint = if (voiceSearchTarget == CustomerSubTab.SEND_DISCOUNT_SMS.name) voiceSearchHint else "",
                    onRequestVoiceForSearch = { onRequestVoiceForSearch(CustomerSubTab.SEND_DISCOUNT_SMS.name) }
                )
            }
            CustomerSubTab.LUCKY_WHEEL -> {
                LuckyWheelLotteryView(
                    customers = customers,
                    clubName = clubName,
                    onAwardDiscount = { winner, percent ->
                        onUpdateCustomer(winner.copy(discountPercent = percent))
                        Toast.makeText(context, "تخفیف $percent٪ برای ${winner.name} ثبت گردید.", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }

    if (showContactsPicker) {
        PhoneContactsPickerDialog(
            onDismiss = { showContactsPicker = false },
            onSelectContact = { cName, cPhone ->
                showContactsPicker = false
                prefillContactName = cName
                prefillContactPhone = cPhone
                showAddCustomerDialog = true
            }
        )
    }

    if (showAddCustomerDialog) {
        val suggestedCode = ((customers.mapNotNull { it.customerCode.toIntOrNull() }.maxOrNull() ?: 100) + 1).toString()
        AddCustomerDialog(
            initialCode = if (prefillContactName.isNotBlank()) suggestedCode else "",
            initialName = prefillContactName,
            initialPhone = prefillContactPhone,
            onDismiss = { showAddCustomerDialog = false },
            onConfirm = { code, name, phone, nid ->
                onAddCustomer(code, name, phone, nid, 0)
                showAddCustomerDialog = false
            }
        )
    }

    if (editingCustomer != null) {
        val target = editingCustomer!!
        val customerDebts = remember(target, debts) {
            filterDebtsForCustomer(target, debts)
        }
        EditCustomerDialog(
            customer = target,
            customerDebts = customerDebts,
            onDismiss = { editingCustomer = null },
            onSaveCustomer = onUpdateCustomer,
            onUpdateDebt = onUpdateDebt,
            onDeleteDebt = onDeleteDebt
        )
    }

    if (deletingCustomer != null) {
        ConfirmDeleteDialog(
            title = "تایید حذف مشتری",
            message = "آیا از حذف مشتری «${deletingCustomer!!.name}» با کد ${deletingCustomer!!.customerCode} اطمینان دارید؟",
            onConfirm = {
                onDeleteCustomer(deletingCustomer!!)
                deletingCustomer = null
            },
            onDismiss = { deletingCustomer = null }
        )
    }

    if (debtBreakdownCustomer != null) {
        val target = debtBreakdownCustomer!!
        val customerDebts = remember(target, debts) {
            filterDebtsForCustomer(target, debts)
        }
        CustomerDebtBreakdownDialog(
            customer = target,
            debtsForCustomer = customerDebts,
            onDismiss = { debtBreakdownCustomer = null }
        )
    }
}

private fun filterDebtsForCustomer(
    customer: CustomerEntity,
    debts: List<CustomerDebtEntity>
): List<CustomerDebtEntity> {
    return debts.filter { d ->
        (customer.customerCode.isNotBlank() && d.customerCode.equals(customer.customerCode, ignoreCase = true)) ||
            d.customerName.equals(customer.name, ignoreCase = true)
    }
}

private fun filterCreditsForCustomer(
    customer: CustomerEntity,
    credits: List<CustomerCreditEntity>
): List<CustomerCreditEntity> {
    return credits.filter { cr ->
        cr.amountTomans > 0L && (
            (customer.customerCode.isNotBlank() && cr.customerCode.equals(customer.customerCode, ignoreCase = true)) ||
                cr.customerName.equals(customer.name, ignoreCase = true)
            )
    }
}

@Composable
fun CustomersDirectoryView(
    customers: List<CustomerEntity>,
    debts: List<CustomerDebtEntity>,
    credits: List<CustomerCreditEntity> = emptyList(),
    voiceSearchHint: String = "",
    onRequestVoiceForSearch: () -> Unit = {},
    onAddClick: () -> Unit,
    onImportFromContactsClick: () -> Unit,
    onEditCustomer: (CustomerEntity) -> Unit,
    onDeleteRequest: (CustomerEntity) -> Unit,
    onDebtBreakdownClick: (CustomerEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    LaunchedEffect(voiceSearchHint) {
        if (voiceSearchHint.isNotBlank()) {
            searchQuery = voiceSearchHint
        }
    }
    val filtered = remember(customers, searchQuery) {
        if (searchQuery.isBlank()) customers
        else customers.filter { it.name.contains(searchQuery, true) || it.customerCode.contains(searchQuery, true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("جستجوی نام یا کد مشتری...", fontSize = 12.sp, color = TextTertiary) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
            trailingIcon = {
                IconButton(
                    onClick = onRequestVoiceForSearch,
                    modifier = Modifier.testTag("customers_search_voice_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "جستجوی صوتی مشتری",
                        tint = CrystalCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CrystalCyan,
                unfocusedBorderColor = GamingBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onAddClick,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("add_customer_manual_btn")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("افزودن مشتری", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, softWrap = false)
            }

            OutlinedButton(
                onClick = onImportFromContactsClick,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CrystalGreen),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalGreen),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .testTag("import_from_contacts_btn")
            ) {
                Icon(Icons.Default.Contacts, contentDescription = null, tint = CrystalGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("از مخاطبین گوشی", color = CrystalGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, softWrap = false)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("مشتری ثبت شده‌ای یافت نشد.", color = TextSecondary)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filtered, key = { "cust_${it.id}" }) { c ->
                    val custDebts = remember(c, debts) { filterDebtsForCustomer(c, debts) }
                    val unsettledTotal = remember(custDebts) { custDebts.filter { !it.isSettled }.sumOf { it.amountTomans } }
                    val custCredits = remember(c, credits) { filterCreditsForCustomer(c, credits) }
                    val creditTotal = remember(custCredits) { custCredits.sumOf { it.amountTomans } }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = c.name,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = TextPrimary),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = CrystalCyan.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = "کد: ${c.customerCode}",
                                                color = CrystalCyan,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                softWrap = false,
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                            )
                                        }
                                        if (c.discountPercent > 0) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = CrystalGreen.copy(alpha = 0.2f)
                                            ) {
                                                Text(
                                                    text = "${c.discountPercent}% تخفیف",
                                                    color = CrystalGreen,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    softWrap = false,
                                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "شماره: ${if (c.phone.isNotBlank()) c.phone else "ثبت نشده"} | کدملی: ${if (c.nationalId.isNotBlank()) c.nationalId else "ثبت نشده"}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp)
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onEditCustomer(c) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .testTag("edit_customer_btn_${c.id}")
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "ویرایش مشتری", tint = CrystalCyan, modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        onClick = { onDeleteRequest(c) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .testTag("delete_customer_btn_${c.id}")
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف مشتری", tint = CrystalRed, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            val badgeColor = when {
                                unsettledTotal > 0L -> CrystalAmber
                                creditTotal > 0L -> CrystalCyan
                                else -> CrystalGreen
                            }
                            val badgeText = when {
                                unsettledTotal > 0L && creditTotal > 0L ->
                                    "بدهی: ${formatNumber(unsettledTotal)} | طلب فعال: ${formatNumber(creditTotal)} ت"
                                unsettledTotal > 0L ->
                                    "مجموع بدهی فعال: ${formatNumber(unsettledTotal)} تومان"
                                creditTotal > 0L ->
                                    "طلب فعال: ${formatNumber(creditTotal)} تومان (حساب بستانکار)"
                                else ->
                                    "بدهی فعال: ۰ تومان (حساب تسویه)"
                            }

                            // Cumulative Debt / Credit Badge (Clickable to open timestamp breakdown popup)
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = badgeColor.copy(alpha = 0.14f),
                                border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.45f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onDebtBreakdownClick(c) }
                                    .testTag("customer_debt_badge_${c.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 5.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = badgeText,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = badgeColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        ),
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "جزئیات >",
                                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan, fontSize = 10.sp),
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 1. Send Debt via SMS
@Composable
fun SendDebtSmsView(
    customers: List<CustomerEntity>,
    debts: List<CustomerDebtEntity>,
    bankCards: List<BankCardEntity>,
    clubName: String,
    credits: List<CustomerCreditEntity> = emptyList(),
    voiceSearchHint: String = "",
    onRequestVoiceForSearch: () -> Unit = {},
    onAddBankCard: (bankName: String, cardNumber: String, cardHolder: String) -> Unit,
    onDeleteBankCard: (BankCardEntity) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var selectedCard by remember { mutableStateOf(bankCards.firstOrNull()) }
    var showAddCardDialog by remember { mutableStateOf(false) }

    LaunchedEffect(voiceSearchHint) {
        if (voiceSearchHint.isNotBlank()) {
            query = voiceSearchHint
            selectedCustomer = customers.firstOrNull { c ->
                c.name.contains(voiceSearchHint, true) || c.customerCode.equals(voiceSearchHint, true)
            }
        }
    }

    val customerDebts = remember(selectedCustomer, debts) {
        if (selectedCustomer == null) emptyList()
        else debts.filter {
            !it.isSettled && (it.customerName.equals(selectedCustomer!!.name, true) ||
                (it.customerCode.isNotBlank() && it.customerCode == selectedCustomer!!.customerCode))
        }
    }
    val totalDebt = customerDebts.sumOf { it.amountTomans }
    val customerCredits = remember(selectedCustomer, credits) {
        selectedCustomer?.let { filterCreditsForCustomer(it, credits) } ?: emptyList()
    }
    val totalCredit = customerCredits.sumOf { it.amountTomans }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item(key = "sms_debt_hdr") {
            SectionHeader(
                title = "۱. ارسال بدهی به مشتری با پیامک",
                subtitle = "جستجوی نام یا کد مشتری، انتخاب شماره کارت و ارسال مستقیم با پیامک"
            )
        }

        item(key = "sms_debt_search") {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    selectedCustomer = customers.firstOrNull { c ->
                        c.name.contains(query, true) || c.customerCode.equals(query, true)
                    }
                },
                placeholder = { Text("نام یا کد مشتری را جستجو کنید...", fontSize = 12.sp) },
                trailingIcon = {
                    IconButton(
                        onClick = onRequestVoiceForSearch,
                        modifier = Modifier.testTag("sms_debt_search_voice_btn")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "جستجوی صوتی مشتری", tint = CrystalAmber, modifier = Modifier.size(18.dp))
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CrystalAmber,
                    unfocusedBorderColor = GamingBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        if (selectedCustomer != null) {
            val c = selectedCustomer!!
            item(key = "sms_debt_cust_info") {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, CrystalAmber),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("مشتری انتخاب شده: ${c.name} (کد: ${c.customerCode})", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("شماره همراه: ${if (c.phone.isNotBlank()) c.phone else "ثبت نشده"}", color = TextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "مجموع بدهی پرداخت‌نشده: ${formatNumber(totalDebt)} تومان",
                            color = CrystalAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        if (totalCredit > 0L) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "مجموع طلب فعال: ${formatNumber(totalCredit)} تومان",
                                color = CrystalCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            item(key = "sms_debt_cards_hdr") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("انتخاب شماره کارت واریز:", color = TextPrimary, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { showAddCardDialog = true }) {
                        Text("+ افزودن کارت جدید", color = CrystalCyan)
                    }
                }
            }

            items(bankCards, key = { "bank_card_${it.id}" }) { card ->
                val isSel = selectedCard?.id == card.id
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSel) CrystalCyan.copy(alpha = 0.2f) else GamingCard,
                    border = BorderStroke(1.dp, if (isSel) CrystalCyan else GamingBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedCard = card }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(card.bankName, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(card.cardNumber, color = CrystalCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            if (card.cardHolder.isNotBlank()) Text(card.cardHolder, color = TextSecondary, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onDeleteBankCard(card) }) {
                            Icon(Icons.Default.Close, contentDescription = "حذف کارت", tint = TextTertiary)
                        }
                    }
                }
            }

            item(key = "sms_debt_send_btn") {
                val cardNum = selectedCard?.cardNumber ?: "ثبت نشده"
                val smsText = "مشتری گرامی ${c.name}، مبلغ بدهی شما در ${clubName.ifBlank { "کلوپ بازی" }}: ${formatNumber(totalDebt)} تومان می‌باشد. لطفاً به شماره کارت $cardNum (${selectedCard?.bankName ?: ""}) واریز فرمایید. باتشکر"

                Button(
                    onClick = {
                        if (c.phone.isBlank()) {
                            Toast.makeText(context, "شماره تماس مشتری ثبت نشده است!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        sendSmsViaIntent(context, c.phone, smsText)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ارسال بدهی با پیامک به مشتری", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }
    }

    if (showAddCardDialog) {
        AddBankCardDialog(
            onDismiss = { showAddCardDialog = false },
            onConfirm = { bName, num, holder ->
                onAddBankCard(bName, num, holder)
                showAddCardDialog = false
            }
        )
    }
}

// 2. Customer Discount
@Composable
fun CustomerDiscountView(
    customers: List<CustomerEntity>,
    voiceSearchHint: String = "",
    onRequestVoiceForSearch: () -> Unit = {},
    onUpdateCustomer: (CustomerEntity) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var discountPercentText by remember { mutableStateOf("15") }

    LaunchedEffect(voiceSearchHint) {
        if (voiceSearchHint.isNotBlank()) {
            query = voiceSearchHint
            selectedCustomer = customers.firstOrNull { c ->
                c.name.contains(voiceSearchHint, true) || c.customerCode.equals(voiceSearchHint, true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item(key = "disc_hdr") {
            SectionHeader(
                title = "۲. بخش تخفیف به مشتری",
                subtitle = "تعیین درصد تخفیف جهت اعمال خودکار در هنگام شروع بازی (عدد ۰ برای حذف تخفیف)"
            )
        }

        item(key = "disc_search") {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    selectedCustomer = customers.firstOrNull { c ->
                        c.name.contains(query, true) || c.customerCode.equals(query, true)
                    }
                },
                placeholder = { Text("نام یا کد مشتری را جهت تخفیف سرچ کنید...", fontSize = 12.sp) },
                trailingIcon = {
                    IconButton(
                        onClick = onRequestVoiceForSearch,
                        modifier = Modifier.testTag("discount_search_voice_btn")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "جستجوی صوتی مشتری", tint = CrystalGreen, modifier = Modifier.size(18.dp))
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CrystalGreen,
                    unfocusedBorderColor = GamingBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        if (selectedCustomer != null) {
            val c = selectedCustomer!!
            item(key = "disc_cust_info") {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, CrystalGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("مشتری: ${c.name} (کد: ${c.customerCode})", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("تخفیف فعلی ثبت شده: ${c.discountPercent}%", color = CrystalGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }

            item(key = "disc_presets") {
                Text("درصد تخفیف جدید:", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("0", "10", "15", "20", "30", "50").forEach { p ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (discountPercentText == p) CrystalGreen else GamingCard,
                            border = BorderStroke(1.dp, if (p == "0") CrystalRed else CrystalGreen),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { discountPercentText = p }
                        ) {
                            Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = if (p == "0") "حذف" else "$p%",
                                    color = if (discountPercentText == p) Color.Black else if (p == "0") CrystalRed else TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }
            }

            item(key = "disc_input") {
                OutlinedTextField(
                    value = discountPercentText,
                    onValueChange = { discountPercentText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("یا درصد دلخواه را تایپ کنید (۰ = بدون تخفیف)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalGreen,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }

            item(key = "disc_save") {
                Button(
                    onClick = {
                        val p = (discountPercentText.toIntOrNull() ?: 0).coerceIn(0, 100)
                        val updated = c.copy(discountPercent = p)
                        onUpdateCustomer(updated)
                        selectedCustomer = updated
                        val msg = if (p == 0) "تخفیف ${c.name} حذف شد." else "تخفیف $p٪ برای ${c.name} ثبت شد."
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("ذخیره درصد تخفیف مشتری", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

// 3. Send Discount SMS with 4 Presets
@Composable
fun SendDiscountSmsView(
    customers: List<CustomerEntity>,
    clubName: String,
    voiceSearchHint: String = "",
    onRequestVoiceForSearch: () -> Unit = {}
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var selectedTemplateIndex by remember { mutableStateOf(0) }

    LaunchedEffect(voiceSearchHint) {
        if (voiceSearchHint.isNotBlank()) {
            query = voiceSearchHint
            selectedCustomer = customers.firstOrNull { c ->
                c.name.contains(voiceSearchHint, true) || c.customerCode.equals(voiceSearchHint, true)
            }
        }
    }

    val templates = listOf(
        "به مناسبت این ایام فرخنده و شیرین شما یا یکی از افراد خانواده شما میتوانید به مدت یک ساعت رایگان در این مجموعه بازی کنید.(مدت اعتبار تا یک روز پس از ارسال پیامک)",
        "به پاس قدرانی بابت همراهی و دوستی طولانی مدت شما در این مجموعه میتوانید به مدت یک ساعت رایگان در این گیم نت بازی کنید.(مدت اعتبار تا یک روز پس از ارسال پیامک)",
        "به مناسبت این ایام فرخنده و شیرین شما یا یکی از افراد خانواده شما میتوانید به مدت یک ساعت با ۲۵ درصد تخفیف در این مجموعه بازی کنید.(مدت اعتبار تا یک روز پس از ارسال پیامک)",
        "به پاس قدرانی بابت همراهی و دوستی طولانی مدت شما در این مجموعه میتوانید به مدت یک ساعت با ۲۵ درصد تخفیف در این گیم نت بازی کنید.(مدت اعتبار تا یک روز پس از ارسال پیامک)"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item(key = "sms_disc_hdr") {
            SectionHeader(
                title = "۳. بخش ارسال پیامک تخفیف به مشتری",
                subtitle = "انتخاب مشتری و انتخاب یکی از ۴ قالب پیش‌فرض پیامک تخفیف"
            )
        }

        item(key = "sms_disc_search") {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    selectedCustomer = customers.firstOrNull { c ->
                        c.name.contains(query, true) || c.customerCode.equals(query, true)
                    }
                },
                placeholder = { Text("نام یا کد مشتری را جستجو کنید...", fontSize = 12.sp) },
                trailingIcon = {
                    IconButton(
                        onClick = onRequestVoiceForSearch,
                        modifier = Modifier.testTag("sms_disc_search_voice_btn")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "جستجوی صوتی مشتری", tint = CrystalMagenta, modifier = Modifier.size(18.dp))
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CrystalMagenta,
                    unfocusedBorderColor = GamingBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        if (selectedCustomer != null) {
            val c = selectedCustomer!!
            item(key = "sms_disc_cust") {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, CrystalMagenta),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("مشتری: ${c.name} (کد: ${c.customerCode})", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("شماره همراه: ${if (c.phone.isNotBlank()) c.phone else "ثبت نشده"}", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }

            item(key = "sms_disc_tmpl_hdr") {
                Text("یکی از قالب‌های پیامک تخفیف را انتخاب نمایید:", fontWeight = FontWeight.Bold, color = TextPrimary)
            }

            items(templates.indices.toList(), key = { "tmpl_$it" }) { idx ->
                val isSel = selectedTemplateIndex == idx
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSel) CrystalMagenta.copy(alpha = 0.2f) else GamingCard,
                    border = BorderStroke(1.dp, if (isSel) CrystalMagenta else GamingBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedTemplateIndex = idx }
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                        RadioButton(
                            selected = isSel,
                            onClick = { selectedTemplateIndex = idx },
                            colors = RadioButtonDefaults.colors(selectedColor = CrystalMagenta)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${idx + 1}- ${templates[idx]}",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                        )
                    }
                }
            }

            item(key = "sms_disc_send") {
                Button(
                    onClick = {
                        if (c.phone.isBlank()) {
                            Toast.makeText(context, "شماره تماس مشتری ثبت نشده است!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val chosenMsg = "${c.name} عزیز،\n${templates[selectedTemplateIndex]}\nبا تشکر - ${clubName.ifBlank { "کلوپ بازی" }}"
                        sendSmsViaIntent(context, c.phone, chosenMsg)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalMagenta),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ارسال پیامک تخفیف به مشتری", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

// 4. Lucky Wheel / Lottery
@Composable
fun LuckyWheelLotteryView(
    customers: List<CustomerEntity>,
    clubName: String = "مدیریت گیم‌نت",
    onAwardDiscount: (winner: CustomerEntity, percent: Int) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isSpinning by remember { mutableStateOf(false) }
    var currentRotation by remember { mutableStateOf(0f) }
    var winner by remember { mutableStateOf<CustomerEntity?>(null) }
    var showWinnerDialog by remember { mutableStateOf(false) }

    val rotationAnim = remember { Animatable(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SectionHeader(
            title = "۴. بخش قرعه‌کشی و گردونه شانس",
            subtitle = "برای چرخش گردونه و انتخاب تصادفی یک مشتری، روی خود گردونه ضربه بزنید"
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(170.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(
                                    CrystalCyan,
                                    CrystalMagenta,
                                    CrystalAmber,
                                    CrystalPurple,
                                    CrystalGreen,
                                    CrystalCyan
                                )
                            )
                        )
                        .rotate(rotationAnim.value)
                        .clickable(enabled = !isSpinning && customers.isNotEmpty()) {
                            isSpinning = true
                            winner = null
                            coroutineScope.launch {
                                val targetRotation = currentRotation + 1440f + Random.nextInt(0, 360)
                                rotationAnim.animateTo(
                                    targetValue = targetRotation,
                                    animationSpec = tween(durationMillis = 3200, easing = FastOutSlowInEasing)
                                )
                                currentRotation = targetRotation % 360
                                winner = customers.random()
                                isSpinning = false
                                showWinnerDialog = true
                            }
                        }
                        .testTag("spin_wheel_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(138.dp)
                            .clip(CircleShape)
                            .background(GamingSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
                            Icon(
                                imageVector = Icons.Default.Casino,
                                contentDescription = "شروع قرعه‌کشی",
                                tint = CrystalAmber,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("گردونه شانس", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                            if (clubName.isNotBlank()) {
                                Text(clubName, color = CrystalCyan, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = when {
                        customers.isEmpty() -> "ابتدا حداقل یک مشتری ثبت کنید."
                        isSpinning -> "در حال چرخیدن گردونه..."
                        else -> "روی گردونه ضربه بزنید!"
                    },
                    color = if (customers.isEmpty()) CrystalRed else CrystalAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }

    if (showWinnerDialog && winner != null) {
        val w = winner!!
        Dialog(onDismissRequest = { showWinnerDialog = false }) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = GamingSurface,
                border = BorderStroke(2.dp, CrystalAmber),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Celebration, contentDescription = null, tint = CrystalAmber, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("برنده خوش‌شانس قرعه‌کشی", color = CrystalAmber, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(w.name, style = MaterialTheme.typography.titleLarge.copy(color = CrystalCyan, fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("کد مشتری: ${w.customerCode}", color = TextPrimary, fontWeight = FontWeight.Bold)
                            if (w.phone.isNotBlank()) Text("شماره همراه: ${w.phone}", color = TextSecondary, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("اعمال جایزه روی این مشتری:", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                onAwardDiscount(w, 25)
                                showWinnerDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("۲۵٪ تخفیف", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }

                        Button(
                            onClick = {
                                onAwardDiscount(w, 100)
                                showWinnerDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("۱ ساعت رایگان", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { showWinnerDialog = false },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("بستن")
                    }
                }
            }
        }
    }
}

@Composable
fun AddCustomerDialog(
    initialCode: String = "",
    initialName: String = "",
    initialPhone: String = "",
    onDismiss: () -> Unit,
    onConfirm: (code: String, name: String, phone: String, nationalId: String) -> Unit
) {
    var code by remember(initialCode) { mutableStateOf(initialCode) }
    var name by remember(initialName) { mutableStateOf(initialName) }
    var phone by remember(initialPhone) { mutableStateOf(initialPhone) }
    var nationalId by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("افزودن مشخصات مشتری جدید", style = MaterialTheme.typography.titleLarge.copy(color = CrystalCyan, fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("کد مشتری (اجباری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام و نام خانوادگی مشتری (اجباری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("شماره تماس (اختیاری)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = nationalId,
                    onValueChange = { nationalId = it },
                    label = { Text("کد ملی (اختیاری)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            if (code.isNotBlank() && name.isNotBlank()) {
                                onConfirm(code.trim(), name.trim(), phone.trim(), nationalId.trim())
                            }
                        },
                        enabled = code.isNotBlank() && name.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ثبت مشتری", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
fun AddBankCardDialog(
    onDismiss: () -> Unit,
    onConfirm: (bankName: String, cardNumber: String, cardHolder: String) -> Unit
) {
    var bankName by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var cardHolder by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = GamingSurface,
            border = BorderStroke(1.dp, CrystalCyan),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("افزودن شماره کارت بانکی", color = CrystalCyan, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = bankName,
                    onValueChange = { bankName = it },
                    label = { Text("نام بانک (مثلاً ملت، ملی)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = cardNumber,
                    onValueChange = { cardNumber = it },
                    label = { Text("شماره کارت ۱۶ رقمی") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = cardHolder,
                    onValueChange = { cardHolder = it },
                    label = { Text("نام صاحب حساب (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            if (cardNumber.isNotBlank()) {
                                onConfirm(bankName.ifBlank { "بانک" }, cardNumber, cardHolder)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ثبت کارت", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

fun sendSmsViaIntent(context: Context, phoneNumber: String, message: String) {
    try {
        val uri = Uri.parse("smsto:$phoneNumber")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", message)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "برنامه پیام‌رسان در دستگاه یافت نشد.", Toast.LENGTH_SHORT).show()
    }
}

private fun formatNumber(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
