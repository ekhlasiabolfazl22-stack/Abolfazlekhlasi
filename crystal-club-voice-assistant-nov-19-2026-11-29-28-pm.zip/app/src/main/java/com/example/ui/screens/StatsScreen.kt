package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CashEntryEntity
import com.example.data.model.GameHistoryEntity
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.FullReportDialog
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import java.util.*
import kotlin.math.max

enum class StatsPeriod {
    TODAY,
    WEEKLY,
    MONTHLY,
    ALL
}

enum class StatsRecordFilter {
    ALL,
    GAMES,
    SERVICES,
    CASH
}

private sealed interface StatsRecordItem {
    val sortMillis: Long
    val uniqueKey: String

    data class History(val item: GameHistoryEntity) : StatsRecordItem {
        override val sortMillis: Long get() = item.createdAtMillis
        override val uniqueKey: String get() = "hist_${item.id}"
    }

    data class Cash(val entry: CashEntryEntity) : StatsRecordItem {
        override val sortMillis: Long get() = entry.createdAtMillis
        override val uniqueKey: String get() = "cash_${entry.id}"
    }
}

@Composable
fun StatsScreen(
    historyList: List<GameHistoryEntity>,
    cashEntries: List<CashEntryEntity> = emptyList(),
    onUpdateHistory: (GameHistoryEntity) -> Unit = {},
    onDeleteHistory: (GameHistoryEntity) -> Unit = {},
    onClearAllHistory: () -> Unit = {},
    onAddCashEntry: (amount: Long, note: String, customerName: String) -> Unit = { _, _, _ -> },
    onUpdateCashEntry: (CashEntryEntity) -> Unit = {},
    onDeleteCashEntry: (CashEntryEntity) -> Unit = {},
    onAddService: (title: String, amountTomans: Long, note: String, cashPaidTomans: Long, cardPaidTomans: Long) -> Unit = { _, _, _, _, _ -> },
    modifier: Modifier = Modifier
) {
    var period by remember { mutableStateOf(StatsPeriod.TODAY) }
    var recordFilter by remember { mutableStateOf(StatsRecordFilter.ALL) }
    var editingItem by remember { mutableStateOf<GameHistoryEntity?>(null) }
    var deletingHistoryItem by remember { mutableStateOf<GameHistoryEntity?>(null) }
    var editingCashItem by remember { mutableStateOf<CashEntryEntity?>(null) }
    var deletingCashItem by remember { mutableStateOf<CashEntryEntity?>(null) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var showFullReportDialog by remember { mutableStateOf(false) }
    var showAddCashDialog by remember { mutableStateOf(false) }
    var showHourlyChartDialog by remember { mutableStateOf(false) }
    var showAddServiceDialog by remember { mutableStateOf(false) }

    val now = remember { System.currentTimeMillis() }
    val startOfToday = remember(now) { PersianDateUtils.startOfDayMillis(now) }

    val filteredHistory = remember(historyList, period) {
        when (period) {
            StatsPeriod.TODAY -> historyList.filter { it.createdAtMillis >= startOfToday }
            StatsPeriod.WEEKLY -> historyList.filter { it.createdAtMillis >= now - (7L * 24 * 60 * 60 * 1000L) }
            StatsPeriod.MONTHLY -> historyList.filter { it.createdAtMillis >= now - (30L * 24 * 60 * 60 * 1000L) }
            StatsPeriod.ALL -> historyList
        }
    }

    val filteredCash = remember(cashEntries, period) {
        when (period) {
            StatsPeriod.TODAY -> cashEntries.filter { it.createdAtMillis >= startOfToday }
            StatsPeriod.WEEKLY -> cashEntries.filter { it.createdAtMillis >= now - (7L * 24 * 60 * 60 * 1000L) }
            StatsPeriod.MONTHLY -> cashEntries.filter { it.createdAtMillis >= now - (30L * 24 * 60 * 60 * 1000L) }
            StatsPeriod.ALL -> cashEntries
        }
    }

    val dailyCashTotal = remember(cashEntries, startOfToday) {
        cashEntries.filter { it.createdAtMillis >= startOfToday }.sumOf { it.amountTomans }
    }
    val periodCashTotal = remember(filteredCash) { filteredCash.sumOf { it.amountTomans } }

    val totalRevenue = remember(filteredHistory) { filteredHistory.sumOf { it.totalFee } }
    val totalGameFee = remember(filteredHistory) { filteredHistory.sumOf { it.gameFee } }
    val totalSnacksFee = remember(filteredHistory) { filteredHistory.sumOf { it.snacksFee } }
    val totalPlayedMinutes = remember(filteredHistory) { filteredHistory.sumOf { it.playedMinutes } }
    val combinedRecords = remember(filteredHistory, filteredCash, recordFilter) {
        val list = buildList {
            when (recordFilter) {
                StatsRecordFilter.ALL -> {
                    filteredHistory.forEach { add(StatsRecordItem.History(it)) }
                    filteredCash.forEach { add(StatsRecordItem.Cash(it)) }
                }
                StatsRecordFilter.GAMES -> {
                    filteredHistory.filter { it.entryType != "SERVICE" }.forEach { add(StatsRecordItem.History(it)) }
                }
                StatsRecordFilter.SERVICES -> {
                    filteredHistory.filter { it.entryType == "SERVICE" }.forEach { add(StatsRecordItem.History(it)) }
                }
                StatsRecordFilter.CASH -> {
                    filteredCash.forEach { add(StatsRecordItem.Cash(it)) }
                }
            }
        }
        list.sortedByDescending { it.sortMillis }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Period Selector Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(GamingCard),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val tabs = listOf(
                Pair(StatsPeriod.TODAY, "امروز"),
                Pair(StatsPeriod.WEEKLY, "هفتگی"),
                Pair(StatsPeriod.MONTHLY, "ماهانه"),
                Pair(StatsPeriod.ALL, "کل تاریخچه")
            )
            tabs.forEach { (p, label) ->
                val isSelected = period == p
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) CrystalCyan else Color.Transparent)
                        .clickable { period = p }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.Black else TextSecondary
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // KPI Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = GamingCardElevated,
                border = BorderStroke(1.dp, CrystalGreen.copy(alpha = 0.5f)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("درآمد کل", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "${formatNumber(totalRevenue)} ت",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = CrystalGreen),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = GamingCardElevated,
                border = BorderStroke(1.dp, CrystalCyan.copy(alpha = 0.5f)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("کارکرد بازی‌ها", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "${formatNumber(totalGameFee)} ت",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = CrystalCyan),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = GamingCardElevated,
                border = BorderStroke(1.dp, CrystalAmber.copy(alpha = 0.5f)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("فروش خوراکی", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "${formatNumber(totalSnacksFee)} ت",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = CrystalAmber),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Daily Cash Card + Full Report Button Row
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = GamingCardElevated,
            border = BorderStroke(1.dp, CrystalPurple.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "مبلغ نقدی روزانه: ${formatNumber(dailyCashTotal)} ت",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = CrystalAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        ),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "جمع نقدی این بازه: ${formatNumber(periodCashTotal)} ت",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.5.sp),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(
                        onClick = { showAddCashDialog = true },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = CrystalGreen.copy(alpha = 0.2f),
                            contentColor = CrystalGreen
                        ),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text("+ ثبت نقدی", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }

                    Button(
                        onClick = { showFullReportDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("open_full_report_btn")
                    ) {
                        Text("گزارش کلی", color = Color.Black, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Action Row: «نمودار ساعتی» Button + «خدمات» Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { showHourlyChartDialog = true },
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CrystalCyan.copy(alpha = 0.7f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalCyan),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .testTag("hourly_chart_button")
            ) {
                Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("نمودار ساعتی", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1, softWrap = false)
            }

            Button(
                onClick = { showAddServiceDialog = true },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CrystalMagenta),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .testTag("open_add_service_btn")
            ) {
                Icon(Icons.Default.Build, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("خدمات", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1, softWrap = false)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Header for History + Services + Cash with Clear All Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "ریز بازی‌ها، خدمات و نقدی (${combinedRecords.size} مورد):",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 13.5.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "بازی: ${totalPlayedMinutes / 60}س و ${totalPlayedMinutes % 60}د | خدمات: ${filteredHistory.count { it.entryType == "SERVICE" }} | نقدی: ${filteredCash.size}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary, fontSize = 10.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (filteredHistory.isNotEmpty()) {
                TextButton(
                    onClick = { showClearConfirmDialog = true },
                    colors = ButtonDefaults.textButtonColors(contentColor = CrystalRed),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("حذف کل گزارش ریز بازی", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Quick Filter Chips for All / Games / Services / Cash
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val filterOptions = listOf(
                StatsRecordFilter.ALL to "همه (${filteredHistory.size + filteredCash.size})",
                StatsRecordFilter.GAMES to "بازی‌ها (${filteredHistory.count { it.entryType != "SERVICE" }})",
                StatsRecordFilter.SERVICES to "خدمات (${filteredHistory.count { it.entryType == "SERVICE" }})",
                StatsRecordFilter.CASH to "نقدی (${filteredCash.size})"
            )
            filterOptions.forEach { (flt, lbl) ->
                val active = recordFilter == flt
                val activeColor = when (flt) {
                    StatsRecordFilter.SERVICES -> CrystalMagenta
                    StatsRecordFilter.CASH -> CrystalAmber
                    else -> CrystalCyan
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (active) activeColor.copy(alpha = 0.22f) else GamingCard)
                        .clickable { recordFilter = flt }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = lbl,
                        color = if (active) activeColor else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (combinedRecords.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "در این بازه زمانی موردی ثبت نشده است.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(combinedRecords, key = { it.uniqueKey }) { record ->
                    when (record) {
                        is StatsRecordItem.History -> HistoryItemCard(
                            item = record.item,
                            onEdit = { editingItem = record.item },
                            onDelete = { deletingHistoryItem = record.item }
                        )
                        is StatsRecordItem.Cash -> CashEntryItemCard(
                            entry = record.entry,
                            onEdit = { editingCashItem = record.entry },
                            onDelete = { deletingCashItem = record.entry }
                        )
                    }
                }
            }
        }
    }

    // Edit History / Service Dialog
    if (editingItem != null) {
        val itm = editingItem!!
        val isService = itm.entryType == "SERVICE"
        var titleText by remember(itm.id) { mutableStateOf(itm.systemDisplayName) }
        var gameFeeText by remember(itm.id) { mutableStateOf(itm.gameFee.toString()) }
        var snacksFeeText by remember(itm.id) { mutableStateOf(itm.snacksFee.toString()) }
        var playedMinText by remember(itm.id) { mutableStateOf(itm.playedMinutes.toString()) }
        var custName by remember(itm.id) { mutableStateOf(itm.customerName) }
        var cashPaidText by remember(itm.id) { mutableStateOf(itm.cashPaidTomans.toString()) }
        var cardPaidText by remember(itm.id) { mutableStateOf(itm.cardPaidTomans.toString()) }
        var noteText by remember(itm.id) { mutableStateOf(itm.sessionNote.ifBlank { if (isService) itm.snacksDetail else "" }) }

        Dialog(
            onDismissRequest = { editingItem = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GamingSurface,
                border = BorderStroke(1.dp, if (isService) CrystalMagenta else CrystalCyan),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .heightIn(max = 640.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (isService) "ویرایش خدمت: ${itm.systemDisplayName}" else "ویرایش ریز بازی: ${itm.systemDisplayName}",
                        color = if (isService) CrystalMagenta else CrystalCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp
                    )

                    if (isService) {
                        OutlinedTextField(
                            value = titleText,
                            onValueChange = { titleText = it },
                            label = { Text("عنوان خدمت", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_service_title_input")
                        )
                        OutlinedTextField(
                            value = gameFeeText,
                            onValueChange = { gameFeeText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                            label = { Text("مبلغ کل خدمت (تومان)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_service_amount_input")
                        )
                    } else {
                        OutlinedTextField(
                            value = gameFeeText,
                            onValueChange = { gameFeeText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                            label = { Text("هزینه بازی (تومان)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_history_game_fee_input")
                        )
                        OutlinedTextField(
                            value = snacksFeeText,
                            onValueChange = { snacksFeeText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                            label = { Text("هزینه خوراکی (تومان)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = playedMinText,
                            onValueChange = { playedMinText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                            label = { Text("مدت بازی (دقیقه)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = custName,
                            onValueChange = { custName = it },
                            label = { Text("نام مشتری / کد", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = cashPaidText,
                        onValueChange = { cashPaidText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                        label = { Text("پرداخت نقدی (تومان)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = cardPaidText,
                        onValueChange = { cardPaidText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                        label = { Text("کارتخوان (تومان)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("توضیحات / یادداشت", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { editingItem = null }, modifier = Modifier.weight(1f)) {
                            Text("انصراف", maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = {
                                val gFee = gameFeeText.toLongOrNull() ?: itm.gameFee
                                val sFee = if (isService) 0L else (snacksFeeText.toLongOrNull() ?: itm.snacksFee)
                                val pMin = if (isService) 0 else (playedMinText.toIntOrNull() ?: itm.playedMinutes)
                                val cashPaid = cashPaidText.toLongOrNull() ?: itm.cashPaidTomans
                                val cardPaid = cardPaidText.toLongOrNull() ?: itm.cardPaidTomans
                                val updated = itm.copy(
                                    systemDisplayName = if (isService && titleText.isNotBlank()) titleText.trim() else itm.systemDisplayName,
                                    gameFee = gFee,
                                    snacksFee = sFee,
                                    totalFee = gFee + sFee,
                                    playedMinutes = pMin,
                                    customerName = if (isService) itm.customerName else custName.trim(),
                                    cashPaidTomans = cashPaid,
                                    cardPaidTomans = cardPaid,
                                    sessionNote = noteText.trim(),
                                    snacksDetail = if (isService) noteText.trim() else itm.snacksDetail
                                )
                                onUpdateHistory(updated)
                                editingItem = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isService) CrystalMagenta else CrystalCyan),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_edit_history_btn")
                        ) {
                            Text(
                                text = "ذخیره تغییرات",
                                color = if (isService) Color.White else Color.Black,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog for single History / Service Delete
    if (deletingHistoryItem != null) {
        val target = deletingHistoryItem!!
        val isService = target.entryType == "SERVICE"
        ConfirmDeleteDialog(
            title = if (isService) "تایید حذف خدمت" else "تایید حذف ریز بازی",
            message = "آیا از حذف ${if (isService) "خدمت" else "گزارش"} «${target.systemDisplayName}» به مبلغ ${formatNumber(target.totalFee)} تومان مطمئن هستید؟",
            onConfirm = {
                onDeleteHistory(target)
                deletingHistoryItem = null
            },
            onDismiss = { deletingHistoryItem = null }
        )
    }

    // Edit Cash Entry Dialog
    if (editingCashItem != null) {
        val cashTarget = editingCashItem!!
        var amountText by remember(cashTarget.id) { mutableStateOf(cashTarget.amountTomans.toString()) }
        var custText by remember(cashTarget.id) { mutableStateOf(cashTarget.customerName) }
        var noteText by remember(cashTarget.id) { mutableStateOf(cashTarget.note) }

        Dialog(
            onDismissRequest = { editingCashItem = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalAmber),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .heightIn(max = 560.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "ویرایش مبلغ نقدی",
                        color = CrystalAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp
                    )
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                        label = { Text("مبلغ نقدی (تومان)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_cash_amount_input")
                    )
                    OutlinedTextField(
                        value = custText,
                        onValueChange = { custText = it },
                        label = { Text("نام مشتری (اختیاری)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_cash_customer_input")
                    )
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("توضیحات") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_cash_note_input")
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { editingCashItem = null }, modifier = Modifier.weight(1f)) {
                            Text("انصراف", maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = {
                                val newAmt = amountText.toLongOrNull() ?: cashTarget.amountTomans
                                if (newAmt > 0L) {
                                    onUpdateCashEntry(
                                        cashTarget.copy(
                                            amountTomans = newAmt,
                                            customerName = custText.trim(),
                                            note = noteText.trim()
                                        )
                                    )
                                    editingCashItem = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_edit_cash_btn")
                        ) {
                            Text("ذخیره تغییرات", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog for Cash Delete
    if (deletingCashItem != null) {
        val target = deletingCashItem!!
        ConfirmDeleteDialog(
            title = "تایید حذف مبلغ نقدی",
            message = "آیا از حذف تراکنش نقدی به مبلغ ${formatNumber(target.amountTomans)} تومان مطمئن هستید؟",
            onConfirm = {
                onDeleteCashEntry(target)
                deletingCashItem = null
            },
            onDismiss = { deletingCashItem = null }
        )
    }

    // Confirmation Dialog for Clearing All History
    if (showClearConfirmDialog) {
        ConfirmDeleteDialog(
            title = "حذف کل گزارش ریز بازی",
            message = "آیا مطمئن هستید که می‌خواهید تمامی ریز بازی‌های ثبت شده را حذف کنید؟ این عملیات غیرقابل بازگشت است.",
            confirmText = "بله، حذف کن",
            onConfirm = {
                onClearAllHistory()
                showClearConfirmDialog = false
            },
            onDismiss = { showClearConfirmDialog = false }
        )
    }

    if (showAddCashDialog) {
        var cashAmtText by remember { mutableStateOf("") }
        var cashNoteText by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showAddCashDialog = false }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("ثبت دریافت نقدی روزانه", color = CrystalGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = cashAmtText,
                        onValueChange = { cashAmtText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                        label = { Text("مبلغ نقدی دریافت‌شده (تومان)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = cashNoteText,
                        onValueChange = { cashNoteText = it },
                        label = { Text("توضیحات (اختیاری)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showAddCashDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("انصراف", maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = {
                                val amt = cashAmtText.toLongOrNull() ?: 0L
                                if (amt > 0L) {
                                    onAddCashEntry(amt, cashNoteText.ifBlank { "دریافت نقدی دستی" }, "")
                                    showAddCashDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ثبت مبلغ", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }

    if (showFullReportDialog) {
        FullReportDialog(
            historyList = historyList,
            cashEntries = cashEntries,
            onDismiss = { showFullReportDialog = false }
        )
    }

    if (showHourlyChartDialog) {
        Dialog(onDismissRequest = { showHourlyChartDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalCyan),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نمودار تفکیکی درآمد و نقدی",
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp
                        )
                        IconButton(onClick = { showHourlyChartDialog = false }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                        }
                    }
                    RevenueBarChart(
                        historyList = filteredHistory,
                        cashList = filteredCash,
                        period = period
                    )
                    OutlinedButton(
                        onClick = { showHourlyChartDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("بستن", maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }

    if (showAddServiceDialog) {
        AddServiceDialog(
            onDismiss = { showAddServiceDialog = false },
            onConfirm = { title, amount, note, cashPaid, cardPaid ->
                onAddService(title, amount, note, cashPaid, cardPaid)
                showAddServiceDialog = false
            }
        )
    }
}

@Composable
private fun AddServiceDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, amountTomans: Long, note: String, cashPaidTomans: Long, cardPaidTomans: Long) -> Unit
) {
    val presets = listOf(
        "نصب بازی PS4/PS5",
        "نصب بازی PC",
        "نصب ویندوز",
        "آهنگ و فیلم",
        "تعمیر دسته"
    )
    var title by remember { mutableStateOf(presets.first()) }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var payMethod by remember { mutableStateOf("CARD") } // "CARD" or "CASH"

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalMagenta),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ثبت خدمات جانبی گیم‌نت",
                        color = CrystalMagenta,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                // Preset service pills
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    presets.chunked(3).forEach { rowPresets ->
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                            rowPresets.forEach { preset ->
                                val sel = title == preset
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (sel) CrystalMagenta else GamingCard,
                                    border = BorderStroke(1.dp, if (sel) CrystalMagenta else GamingBorder),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { title = preset }
                                ) {
                                    Text(
                                        text = preset,
                                        color = if (sel) Color.White else TextSecondary,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان خدمت", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("service_title_input")
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                    label = { Text("مبلغ (تومان)", fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("service_amount_input")
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("توضیحات (اختیاری)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("CARD" to "کارتخوان (POS)", "CASH" to "نقدی").forEach { (key, label) ->
                        val sel = payMethod == key
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(9.dp))
                                .background(if (sel) CrystalCyan else GamingCard)
                                .clickable { payMethod = key }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (sel) Color.Black else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            val amt = amountText.toLongOrNull() ?: 0L
                            if (title.isNotBlank() && amt > 0L) {
                                val cash = if (payMethod == "CASH") amt else 0L
                                val card = if (payMethod == "CARD") amt else 0L
                                onConfirm(title.trim(), amt, note.trim(), cash, card)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalMagenta),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_add_service_btn")
                    ) {
                        Text("ثبت خدمات", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
fun RevenueBarChart(
    historyList: List<GameHistoryEntity>,
    period: StatsPeriod,
    cashList: List<CashEntryEntity> = emptyList()
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = GamingCard,
        border = BorderStroke(1.dp, GamingBorder),
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when (period) {
                        StatsPeriod.TODAY -> "ساعات امروز"
                        StatsPeriod.WEEKLY -> "۷ روز گذشته"
                        StatsPeriod.MONTHLY -> "۴ هفته اخیر"
                        StatsPeriod.ALL -> "کل تاریخچه"
                    },
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = CrystalCyan,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1,
                    softWrap = false
                )

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChartLegendDot("بازی", CrystalCyan)
                    ChartLegendDot("خدمات", CrystalMagenta)
                    ChartLegendDot("نقدی", CrystalAmber)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val bucketData = remember(historyList, cashList, period) {
                calculateBuckets(historyList, cashList, period)
            }
            val maxAmount = bucketData.maxOfOrNull {
                max(it.gameAndSnacks, max(it.services, it.cash))
            }?.coerceAtLeast(10_000L) ?: 10_000L

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                bucketData.forEach { bucket ->
                    val gameFrac = if (bucket.gameAndSnacks > 0) (bucket.gameAndSnacks.toFloat() / maxAmount).coerceIn(0.08f, 1f) else 0.03f
                    val svcFrac = if (bucket.services > 0) (bucket.services.toFloat() / maxAmount).coerceIn(0.08f, 1f) else 0.03f
                    val cashFrac = if (bucket.cash > 0) (bucket.cash.toFloat() / maxAmount).coerceIn(0.08f, 1f) else 0.03f
                    val topTotal = bucket.gameAndSnacks + bucket.services

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        if (topTotal > 0L || bucket.cash > 0L) {
                            Text(
                                text = "${max(topTotal, bucket.cash) / 1000}k",
                                color = TextSecondary,
                                fontSize = 8.5.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.Bottom,
                            modifier = Modifier
                                .weight(1f)
                                .padding(top = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(7.dp)
                                    .fillMaxHeight(gameFrac * 0.9f)
                                    .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                    .background(CrystalCyan)
                            )
                            Box(
                                modifier = Modifier
                                    .width(7.dp)
                                    .fillMaxHeight(svcFrac * 0.9f)
                                    .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                    .background(CrystalMagenta)
                            )
                            Box(
                                modifier = Modifier
                                    .width(7.dp)
                                    .fillMaxHeight(cashFrac * 0.9f)
                                    .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                    .background(CrystalAmber)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = bucket.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextTertiary,
                                fontSize = 10.sp
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChartLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(3.dp))
        Text(label, style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.5.sp))
    }
}

data class Bucket(
    val label: String,
    val gameAndSnacks: Long,
    val services: Long,
    val cash: Long
)

private fun calculateBuckets(
    history: List<GameHistoryEntity>,
    cashEntries: List<CashEntryEntity>,
    period: StatsPeriod
): List<Bucket> {
    return when (period) {
        StatsPeriod.TODAY -> {
            val ranges = listOf(
                "صبح" to (0..11),
                "ظهر" to (12..15),
                "عصر" to (16..19),
                "شب" to (20..23)
            )
            ranges.map { (lbl, rng) ->
                val h = history.filter { getHour(it.createdAtMillis) in rng }
                val c = cashEntries.filter { getHour(it.createdAtMillis) in rng }
                makeBucket(lbl, h, c)
            }
        }
        StatsPeriod.WEEKLY -> {
            val dayNames = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")
            (6 downTo 0).map { i ->
                val targetDayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
                val d = targetDayCal.get(Calendar.DAY_OF_YEAR)
                val dayH = history.filter {
                    val c = Calendar.getInstance().apply { timeInMillis = it.createdAtMillis }
                    c.get(Calendar.DAY_OF_YEAR) == d
                }
                val dayC = cashEntries.filter {
                    val c = Calendar.getInstance().apply { timeInMillis = it.createdAtMillis }
                    c.get(Calendar.DAY_OF_YEAR) == d
                }
                val dayOfWeek = targetDayCal.get(Calendar.DAY_OF_WEEK)
                val label = dayNames.getOrElse((dayOfWeek + 1) % 7) { "روز" }
                makeBucket(label, dayH, dayC)
            }
        }
        else -> {
            val chunkSize = max(1, history.size / 4)
            val cashChunk = max(1, cashEntries.size / 4)
            listOf(
                makeBucket("هفته ۱", history.take(chunkSize), cashEntries.take(cashChunk)),
                makeBucket("هفته ۲", history.drop(chunkSize).take(chunkSize), cashEntries.drop(cashChunk).take(cashChunk)),
                makeBucket("هفته ۳", history.drop(chunkSize * 2).take(chunkSize), cashEntries.drop(cashChunk * 2).take(cashChunk)),
                makeBucket("هفته ۴", history.drop(chunkSize * 3), cashEntries.drop(cashChunk * 3))
            )
        }
    }
}

private fun makeBucket(
    label: String,
    list: List<GameHistoryEntity>,
    cashList: List<CashEntryEntity>
): Bucket {
    val svc = list.filter { it.entryType == "SERVICE" }.sumOf { it.totalFee }
    val gameAndSnacks = list.filter { it.entryType != "SERVICE" }.sumOf { it.totalFee }
    val cash = cashList.sumOf { it.amountTomans }
    return Bucket(label, gameAndSnacks, svc, cash)
}

private fun getHour(millis: Long): Int {
    val c = Calendar.getInstance().apply { timeInMillis = millis }
    return c.get(Calendar.HOUR_OF_DAY)
}

@Composable
fun HistoryItemCard(
    item: GameHistoryEntity,
    onEdit: () -> Unit = {},
    onDelete: () -> Unit = {}
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = GamingCard,
        border = BorderStroke(1.dp, GamingBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.systemDisplayName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = CrystalCyan
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CrystalPurple.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "${item.playerCount} نفره",
                            style = MaterialTheme.typography.labelSmall.copy(color = CrystalPurple),
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (item.entryType == "SERVICE") {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CrystalMagenta.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "خدمات",
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalMagenta),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else if (item.entryType == "DEBT_SETTLEMENT") {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CrystalAmber.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "تسویه بدهی",
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else if (item.discountPercent > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CrystalGreen.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "${item.discountPercent}% تخفیف",
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${formatNumber(item.totalFee)} تومان",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = CrystalGreen
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(30.dp)
                            .testTag("edit_history_btn_${item.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "ویرایش", tint = CrystalCyan, modifier = Modifier.size(16.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(30.dp)
                            .testTag("delete_history_btn_${item.id}")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = CrystalRed, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val summaryLine = if (item.entryType == "SERVICE") {
                    "${item.dateIso} | خدمت ثبت‌شده (${formatNumber(item.totalFee)} ت)"
                } else {
                    "${item.dateIso} | بازی: ${item.playedMinutes} دقیقه (${formatNumber(item.gameFee)} ت)${if (item.customerName.isNotBlank()) " | مشتری: ${item.customerName}" else ""}"
                }
                Text(
                    text = summaryLine,
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                    modifier = Modifier.weight(1f)
                )

                if (item.snacksFee > 0) {
                    Text(
                        text = "خوراکی: ${formatNumber(item.snacksFee)} ت",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = CrystalAmber,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            if (item.cashPaidTomans > 0L || item.cardPaidTomans > 0L) {
                Spacer(modifier = Modifier.height(3.dp))
                val paySummary = buildList {
                    if (item.cardPaidTomans > 0L) add("کارتخوان: ${formatNumber(item.cardPaidTomans)} ت")
                    if (item.cashPaidTomans > 0L) add("نقدی: ${formatNumber(item.cashPaidTomans)} ت")
                }.joinToString(" | ")
                Text(
                    text = paySummary,
                    style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber, fontSize = 10.sp)
                )
            }

            if (item.modeConversionNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = item.modeConversionNotes,
                    style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan, fontSize = 10.sp)
                )
            }

            if (item.snacksDetail.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "جزییات: ${item.snacksDetail}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                )
            }
            if (item.sessionNote.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "یادداشت: ${item.sessionNote}",
                    style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan, fontSize = 10.sp)
                )
            }
        }
    }
}

@Composable
fun CashEntryItemCard(
    entry: CashEntryEntity,
    onEdit: () -> Unit = {},
    onDelete: () -> Unit = {}
) {
    val sourceLabel = when (entry.source) {
        "MANUAL" -> "ثبت نقدی دستی"
        "SERVICE" -> "نقدی خدمات"
        "RECEIPT" -> "نقدی فاکتور"
        else -> "دریافت نقدی"
    }
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = GamingCard,
        border = BorderStroke(1.dp, CrystalAmber.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cash_item_card_${entry.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Payments,
                        contentDescription = null,
                        tint = CrystalAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = sourceLabel,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = CrystalAmber,
                            fontSize = 13.5.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CrystalAmber.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "مبلغ نقدی",
                            style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber, fontSize = 10.sp),
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${formatNumber(entry.amountTomans)} تومان",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = CrystalAmber,
                            fontSize = 13.5.sp
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(30.dp)
                            .testTag("edit_cash_btn_${entry.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "ویرایش نقدی", tint = CrystalCyan, modifier = Modifier.size(16.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(30.dp)
                            .testTag("delete_cash_btn_${entry.id}")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف نقدی", tint = CrystalRed, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(5.dp))

            val metaLine = buildList {
                add(PersianDateUtils.formatJalaliDateTime(entry.createdAtMillis))
                if (entry.customerName.isNotBlank()) add("مشتری: ${entry.customerName}")
            }.joinToString(" | ")

            Text(
                text = metaLine,
                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
            )

            if (entry.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "توضیحات: ${entry.note}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                )
            }
        }
    }
}

private fun formatNumber(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
