package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActiveSessionEntity
import com.example.data.model.GameHistoryEntity
import com.example.data.model.GameSystemEntity
import com.example.data.model.SnackItemEntity
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SystemActionBottomSheet(
    system: GameSystemEntity,
    session: ActiveSessionEntity?,
    snacksList: List<SnackItemEntity>,
    currentTimeMillis: Long,
    onDismiss: () -> Unit,
    onStartDuration: (players: Int, minutes: Int, customer: String) -> Unit,
    onStartAmount: (players: Int, amountTomans: Long, customer: String) -> Unit,
    onStartOpenEnded: (players: Int, customer: String) -> Unit,
    onAddSnack: (snackName: String, count: Int) -> Unit,
    onModifyTimer: (additionalMinutes: Int) -> Unit,
    onUpdatePlayers: (newCount: Int) -> Unit,
    onFinishSession: (onFinished: (GameHistoryEntity?) -> Unit) -> Unit
) {
    val modalBottomSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = modalBottomSheetState,
        containerColor = GamingCardElevated,
        dragHandle = {
            Surface(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(44.dp)
                    .height(4.dp),
                shape = RoundedCornerShape(2.dp),
                color = GamingBorder
            ) {}
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "مدیریت ${system.displayName}",
                        style = MaterialTheme.typography.titleLarge,
                        color = CrystalCyan
                    )
                    Text(
                        text = if (session != null) "وضعیت: در حال بازی" else "وضعیت: سیستم آزاد",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (session != null) CrystalMagenta else CrystalGreen
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (session != null) {
                // ================= ACTIVE SESSION MANAGEMENT =================
                ActiveSessionEditSection(
                    system = system,
                    session = session,
                    snacksList = snacksList,
                    currentTimeMillis = currentTimeMillis,
                    onAddSnack = onAddSnack,
                    onModifyTimer = onModifyTimer,
                    onUpdatePlayers = onUpdatePlayers,
                    onFinishSession = onFinishSession
                )
            } else {
                // ================= START NEW SESSION =================
                StartNewSessionSection(
                    system = system,
                    onStartDuration = onStartDuration,
                    onStartAmount = onStartAmount,
                    onStartOpenEnded = onStartOpenEnded
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun ActiveSessionEditSection(
    system: GameSystemEntity,
    session: ActiveSessionEntity?,
    snacksList: List<SnackItemEntity>,
    currentTimeMillis: Long,
    onAddSnack: (String, Int) -> Unit,
    onModifyTimer: (Int) -> Unit,
    onUpdatePlayers: (Int) -> Unit,
    onFinishSession: (onFinished: (GameHistoryEntity?) -> Unit) -> Unit
) {
    if (session == null) return

    val elapsedMillis = max(0L, currentTimeMillis - session.startTimeMillis)
    val playedMinutes = max(1, (elapsedMillis / (60 * 1000)).toInt())
    val remainingMillis = if (session.isCountDown) max(0L, session.expectedEndTimeMillis - currentTimeMillis) else 0L
    val remainingMinutes = (remainingMillis / (60 * 1000)).toInt()

    // FAIR PRICING CALCULATION:
    // Only charge for exact played minutes, not full booked time if leaving early!
    val hourlyRateTotal = session.hourlyRateApplied * session.playerCount
    val gameFee = (playedMinutes * (hourlyRateTotal / 60.0)).toLong()
    val totalFee = gameFee + session.snacksCost

    // 1. Live Accounting Box
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = GamingSurface,
        border = BorderStroke(1.dp, GamingBorderGlow)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "مدت بازی انجام‌شده:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Text(text = "$playedMinutes دقیقه", style = MaterialTheme.typography.titleMedium, color = CrystalCyan)
            }
            if (session.isCountDown) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "زمان باقیمانده:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Text(
                        text = "$remainingMinutes دقیقه",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (remainingMinutes <= 0) CrystalRed else CrystalAmber
                    )
                }
            }
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = GamingBorder)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "هزینه بازی (محاسبه دقیق دقیقه‌ای):", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Text(text = "${formatPrice(gameFee)} تومان", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "هزینه خوراکی و نوشیدنی:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Text(text = "${formatPrice(session.snacksCost)} تومان", style = MaterialTheme.typography.titleMedium, color = CrystalAmber)
            }
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = GamingBorder)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "مجموع قابل پرداخت:", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Text(text = "${formatPrice(totalFee)} تومان", style = MaterialTheme.typography.titleLarge, color = CrystalGreen)
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 2. Player Count Modification
    Text(text = "👥 تغییر تعداد نفرات:", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
    Spacer(modifier = Modifier.height(8.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        listOf(1, 2, 3, 4).forEach { count ->
            val isSelected = session.playerCount == count
            FilterChip(
                selected = isSelected,
                onClick = { onUpdatePlayers(count) },
                label = { Text("$count نفره", style = MaterialTheme.typography.bodyMedium) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CrystalMagenta,
                    selectedLabelColor = Color.Black
                ),
                modifier = Modifier.weight(1f)
            )
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 3. Timer Modification
    Text(text = "⏳ تغییر یا تمدید تایمر:", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
    Spacer(modifier = Modifier.height(8.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        listOf(
            "+۱۰ دقیقه" to 10,
            "+۱۵ دقیقه" to 15,
            "+۳۰ دقیقه" to 30,
            "+۱ ساعت" to 60
        ).forEach { (label, minutes) ->
            OutlinedButton(
                onClick = { onModifyTimer(minutes) },
                border = BorderStroke(1.dp, CrystalCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = label, style = MaterialTheme.typography.labelSmall, color = CrystalCyan)
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 4. Snacks Section
    Text(text = "🥤 افزودن خوراکی به سیستم:", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
    if (session.snacksDetail.isNotBlank()) {
        Text(
            text = "اقلام ثبت‌شده: ${session.snacksDetail}",
            style = MaterialTheme.typography.bodySmall,
            color = CrystalAmber,
            modifier = Modifier.padding(vertical = 4.dp)
        )
    }
    Spacer(modifier = Modifier.height(8.dp))
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(snacksList) { snack ->
            AssistChip(
                onClick = { onAddSnack(snack.name, 1) },
                label = {
                    Column {
                        Text(text = "+ ${snack.name}", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                        Text(text = "${formatPrice(snack.priceTomans)} ت", style = MaterialTheme.typography.bodySmall, color = CrystalAmber)
                    }
                },
                colors = AssistChipDefaults.assistChipColors(containerColor = GamingSurface),
                border = BorderStroke(1.dp, GamingBorder),
                shape = RoundedCornerShape(10.dp)
            )
        }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // 5. Final Checkout Button
    Button(
        onClick = {
            onFinishSession { /* closed */ }
        },
        colors = ButtonDefaults.buttonColors(containerColor = CrystalRed),
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("finish_session_button"),
        shape = RoundedCornerShape(14.dp)
    ) {
        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "پایان بازی و تسویه نهایی (${formatPrice(totalFee)} تومان)",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White
        )
    }
}

@Composable
private fun StartNewSessionSection(
    system: GameSystemEntity,
    onStartDuration: (Int, Int, String) -> Unit,
    onStartAmount: (Int, Long, String) -> Unit,
    onStartOpenEnded: (Int, String) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Custom Duration, 1: Custom Amount, 2: Open-ended
    var selectedPlayers by remember { mutableStateOf(1) }
    var selectedMinutes by remember { mutableStateOf(60) }
    var customMinutesInput by remember { mutableStateOf("") }
    var selectedAmountTomans by remember { mutableStateOf(100000L) }
    var customAmountInput by remember { mutableStateOf("") }
    var customerNameInput by remember { mutableStateOf("") }

    // Player Count Selector
    Text(text = "👥 تعداد نفرات:", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
    Spacer(modifier = Modifier.height(6.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        listOf(1, 2, 3, 4).forEach { count ->
            val isSelected = selectedPlayers == count
            FilterChip(
                selected = isSelected,
                onClick = { selectedPlayers = count },
                label = { Text("$count نفره", style = MaterialTheme.typography.bodyMedium) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CrystalCyan,
                    selectedLabelColor = Color.Black
                ),
                modifier = Modifier.weight(1f)
            )
        }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Start Mode Tabs
    TabRow(
        selectedTabIndex = selectedTab,
        containerColor = GamingSurface,
        contentColor = CrystalCyan,
        divider = {}
    ) {
        Tab(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            text = { Text("تایم دلخواه", style = MaterialTheme.typography.labelMedium) }
        )
        Tab(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            text = { Text("مبلغ دلخواه", style = MaterialTheme.typography.labelMedium) }
        )
        Tab(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            text = { Text("شروع آزاد", style = MaterialTheme.typography.labelMedium) }
        )
    }

    Spacer(modifier = Modifier.height(14.dp))

    when (selectedTab) {
        0 -> {
            // Duration Mode
            Text(text = "مدت زمان بازی:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "۱۵ دقیقه" to 15,
                    "۳۰ دقیقه" to 30,
                    "۴۵ دقیقه" to 45,
                    "۱ ساعت" to 60,
                    "۱.۵ ساعت" to 90,
                    "۲ ساعت" to 120
                ).forEach { (label, min) ->
                    val isSel = selectedMinutes == min && customMinutesInput.isEmpty()
                    FilterChip(
                        selected = isSel,
                        onClick = {
                            selectedMinutes = min
                            customMinutesInput = ""
                        },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CrystalCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = customMinutesInput,
                onValueChange = {
                    customMinutesInput = it
                    it.toIntOrNull()?.let { min -> selectedMinutes = min }
                },
                label = { Text("یا تایم دلخواه به دقیقه (مثلا: ۴۰)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CrystalCyan,
                    unfocusedBorderColor = GamingBorder
                ),
                shape = RoundedCornerShape(10.dp)
            )
        }

        1 -> {
            // Amount Mode
            Text(text = "مبلغ دلخواه (تومان):", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(30000L, 50000L, 70000L, 100000L, 150000L).forEach { amt ->
                    val isSel = selectedAmountTomans == amt && customAmountInput.isEmpty()
                    FilterChip(
                        selected = isSel,
                        onClick = {
                            selectedAmountTomans = amt
                            customAmountInput = ""
                        },
                        label = { Text("${formatPrice(amt)} ت", style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CrystalCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = customAmountInput,
                onValueChange = {
                    customAmountInput = it
                    it.toLongOrNull()?.let { amt -> selectedAmountTomans = amt }
                },
                label = { Text("یا مبلغ دلخواه به تومان (مثلا: ۱۲۰۰۰۰)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CrystalCyan,
                    unfocusedBorderColor = GamingBorder
                ),
                shape = RoundedCornerShape(10.dp)
            )

            // Calculate estimated minutes for this amount
            val ratePerHour = system.hourlyRatePerPlayer * selectedPlayers
            val estimatedMin = if (ratePerHour > 0) ((selectedAmountTomans.toDouble() / ratePerHour) * 60).toInt() else 60
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "⚡ معادل بازی: حدود $estimatedMin دقیقه تایمر معکوس",
                style = MaterialTheme.typography.bodySmall,
                color = CrystalAmber
            )
        }

        2 -> {
            // Open-ended
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = GamingSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "سیستم از همین لحظه شروع به کار می‌کند و تایمر رو به جلو محاسبه خواهد شد تا هر زمان که بازی را به پایان برسانید.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Customer Name Optional
    OutlinedTextField(
        value = customerNameInput,
        onValueChange = { customerNameInput = it },
        label = { Text("نام مشتری یا دسته (اختیاری)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CrystalCyan,
            unfocusedBorderColor = GamingBorder
        ),
        shape = RoundedCornerShape(10.dp)
    )

    Spacer(modifier = Modifier.height(18.dp))

    // Start Button
    Button(
        onClick = {
            when (selectedTab) {
                0 -> onStartDuration(selectedPlayers, selectedMinutes, customerNameInput)
                1 -> onStartAmount(selectedPlayers, selectedAmountTomans, customerNameInput)
                2 -> onStartOpenEnded(selectedPlayers, customerNameInput)
            }
        },
        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("start_session_button"),
        shape = RoundedCornerShape(14.dp)
    ) {
        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "شروع بازی ⚡",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.Black
        )
    }
}

private fun formatPrice(amount: Long): String {
    return NumberFormat.getNumberInstance(Locale.US).format(amount)
}
