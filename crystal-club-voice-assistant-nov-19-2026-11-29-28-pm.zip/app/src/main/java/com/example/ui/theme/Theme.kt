package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CrystalColorScheme = darkColorScheme(
    primary = CrystalCyan,
    onPrimary = Color(0xFF002229),
    primaryContainer = Color(0xFF004D5A),
    onPrimaryContainer = Color(0xFF8CF4FF),

    secondary = CrystalMagenta,
    onSecondary = Color(0xFF3F001D),
    secondaryContainer = Color(0xFF6B0033),
    onSecondaryContainer = Color(0xFFFFB2CB),

    tertiary = CrystalPurple,
    onTertiary = Color(0xFF28004E),
    tertiaryContainer = Color(0xFF55198B),
    onTertiaryContainer = Color(0xFFE2C4FF),

    background = GamingBackground,
    onBackground = TextPrimary,
    surface = GamingSurface,
    onSurface = TextPrimary,
    surfaceVariant = GamingCard,
    onSurfaceVariant = TextSecondary,
    outline = GamingBorder,
    outlineVariant = GamingBorderGlow,
    error = CrystalRed,
    onError = Color.White
)

@Composable
fun CrystalGameClubTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CrystalColorScheme,
        typography = Typography,
        content = content
    )
}
