package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CashEntryEntity
import com.example.data.model.GameHistoryEntity
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import java.util.Locale
import kotlin.math.max

private data class DailySummaryPoint(
    val jalaliDate: String,
    val gameSalesTotal: Long,
    val serviceSalesTotal: Long,
    val salesTotal: Long,
    val cashTotal: Long,
    val combinedCount: Int
)

@Composable
fun FullReportDialog(
    historyList: List<GameHistoryEntity>,
    cashEntries: List<CashEntryEntity>,
    onDismiss: () -> Unit
) {
    val todayJalali = remember { PersianDateUtils.formatJalaliDate(System.currentTimeMillis()) }
    var dateQuery by remember { mutableStateOf(todayJalali) }

    val normalizedTargetDate = remember(dateQuery) {
        PersianDateUtils.normalizeDateQuery(dateQuery)
    }

    // Aggregate ALL recorded dates from earliest day to today for the All-Time chart & quick-picker
    val dailyPoints = remember(historyList, cashEntries) {
        val groupedSales = historyList.groupBy { PersianDateUtils.dayKey(it.createdAtMillis) }
        val groupedCash = cashEntries.groupBy { PersianDateUtils.dayKey(it.createdAtMillis) }
        val allDates = (groupedSales.keys + groupedCash.keys + todayJalali).toSortedSet()
        allDates.map { day ->
            val sales = groupedSales[day].orEmpty()
            val cash = groupedCash[day].orEmpty()
            val gameSales = sales.filter { it.entryType != "SERVICE" }.sumOf { it.totalFee }
            val svcSales = sales.filter { it.entryType == "SERVICE" }.sumOf { it.totalFee }
            DailySummaryPoint(
                jalaliDate = day,
                gameSalesTotal = gameSales,
                serviceSalesTotal = svcSales,
                salesTotal = gameSales + svcSales,
                cashTotal = cash.sumOf { it.amountTomans },
                combinedCount = sales.size + cash.size
            )
        }
    }

    val dayHistory = remember(historyList, normalizedTargetDate) {
        historyList.filter { PersianDateUtils.dayKey(it.createdAtMillis) == normalizedTargetDate }
            .sortedByDescending { it.createdAtMillis }
    }
    val dayCash = remember(cashEntries, normalizedTargetDate) {
        cashEntries.filter { PersianDateUtils.dayKey(it.createdAtMillis) == normalizedTargetDate }
            .sortedByDescending { it.createdAtMillis }
    }

    val dayRevenue = remember(dayHistory) { dayHistory.sumOf { it.totalFee } }
    val daySnacks = remember(dayHistory) { dayHistory.sumOf { it.snacksFee } }
    val dayCashSum = remember(dayCash) { dayCash.sumOf { it.amountTomans } }
    val dayMinutes = remember(dayHistory) { dayHistory.sumOf { it.playedMinutes } }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.9f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مشاهده ریز گزارش کلی و روزانه",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = CrystalCyan,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "جستجوی تاریخ دلخواه + نمودار فروش از روز اول تا امروز",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Jalali Date Search Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = dateQuery,
                        onValueChange = { dateQuery = it },
                        label = { Text("تاریخ شمسی (مثلاً $todayJalali)", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = CrystalCyan) },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("full_report_date_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalCyan,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    FilledTonalButton(
                        onClick = { dateQuery = todayJalali },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = CrystalCyan.copy(alpha = 0.2f),
                            contentColor = CrystalCyan
                        )
                    ) {
                        Text("امروز", fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Recorded Date Quick Selector Chips (newest first)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(dailyPoints.reversed(), key = { "report_date_chip_${it.jalaliDate}" }) { pt ->
                        val sel = pt.jalaliDate == normalizedTargetDate
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (sel) CrystalCyan else GamingCard,
                            border = BorderStroke(1.dp, if (sel) CrystalCyan else GamingBorder),
                            modifier = Modifier.clickable { dateQuery = pt.jalaliDate }
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = PersianDateUtils.toPersianDigits(pt.jalaliDate),
                                    color = if (sel) Color.Black else TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                                if (pt.salesTotal > 0L || pt.cashTotal > 0L) {
                                    Text(
                                        text = "${formatPrice(pt.salesTotal)} ت",
                                        color = if (sel) Color.Black.copy(alpha = 0.75f) else CrystalGreen,
                                        fontSize = 9.5.sp,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // All-Time Daily Chart from Day 1 to Today (3 distinct colors: بازی + خدمات + نقدی)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(165.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "نمودار فروش روزانه کل دوره (${dailyPoints.size} روز)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalAmber,
                                    fontWeight = FontWeight.Bold
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                MiniLegendBadge("بازی", CrystalCyan)
                                MiniLegendBadge("خدمات", CrystalMagenta)
                                MiniLegendBadge("نقدی", CrystalAmber)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        val maxVal = dailyPoints.maxOfOrNull {
                            max(it.gameSalesTotal, max(it.serviceSalesTotal, it.cashTotal))
                        }?.coerceAtLeast(10_000L) ?: 10_000L
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Bottom,
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            items(dailyPoints, key = { "chart_day_${it.jalaliDate}" }) { pt ->
                                val gFrac = if (pt.gameSalesTotal > 0L) (pt.gameSalesTotal.toFloat() / maxVal).coerceIn(0.08f, 1f) else 0.03f
                                val sFrac = if (pt.serviceSalesTotal > 0L) (pt.serviceSalesTotal.toFloat() / maxVal).coerceIn(0.08f, 1f) else 0.03f
                                val cFrac = if (pt.cashTotal > 0L) (pt.cashTotal.toFloat() / maxVal).coerceIn(0.08f, 1f) else 0.03f
                                val isChosen = pt.jalaliDate == normalizedTargetDate
                                val peakVal = max(pt.salesTotal, pt.cashTotal)

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Bottom,
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .width(52.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isChosen) CrystalCyan.copy(alpha = 0.08f) else Color.Transparent)
                                        .clickable { dateQuery = pt.jalaliDate }
                                        .padding(vertical = 2.dp)
                                ) {
                                    if (peakVal > 0L) {
                                        Text(
                                            text = "${peakVal / 1000}k",
                                            fontSize = 8.5.sp,
                                            color = if (isChosen) CrystalAmber else TextSecondary,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                        verticalAlignment = Alignment.Bottom,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .width(7.dp)
                                                .fillMaxHeight(gFrac * 0.9f)
                                                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                                .background(CrystalCyan)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .width(7.dp)
                                                .fillMaxHeight(sFrac * 0.9f)
                                                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                                .background(CrystalMagenta)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .width(7.dp)
                                                .fillMaxHeight(cFrac * 0.9f)
                                                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                                .background(CrystalAmber)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = pt.jalaliDate.takeLast(5),
                                        fontSize = 9.sp,
                                        color = if (isChosen) CrystalCyan else TextTertiary,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Selected Day Totals Strip
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, CrystalGreen.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("فروش تاریخ ${PersianDateUtils.toPersianDigits(normalizedTargetDate)}:", color = TextSecondary, fontSize = 11.sp)
                            Text("${formatPrice(dayRevenue)} تومان", color = CrystalGreen, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            Text("بوفه: ${formatPrice(daySnacks)} ت | ${dayMinutes} دقیقه", color = TextTertiary, fontSize = 10.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("دریافتی نقدی آن روز:", color = TextSecondary, fontSize = 11.sp)
                            Text("${formatPrice(dayCashSum)} تومان", color = CrystalAmber, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            Text("${dayHistory.size} فاکتور | ${dayCash.size} نقدی", color = TextTertiary, fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Day Detailed Items List
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (dayHistory.isEmpty() && dayCash.isEmpty()) {
                        item(key = "empty_day_msg") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("در تاریخ انتخاب‌شده گزارشی ثبت نشده است.", color = TextSecondary)
                            }
                        }
                    } else {
                        if (dayHistory.isNotEmpty()) {
                            item(key = "hdr_day_games") {
                                Text(
                                    text = "فاکتورها و بازی‌های این روز (${dayHistory.size}):",
                                    color = CrystalCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            items(dayHistory, key = { "rep_hist_${it.id}" }) { h ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = GamingCard,
                                    border = BorderStroke(1.dp, GamingBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = h.systemDisplayName,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "${PersianDateUtils.formatTime(h.createdAtMillis)} | ${h.playerCount} نفره | ${h.playedMinutes} دقیقه${if (h.customerName.isNotBlank()) " | ${h.customerName}" else ""}",
                                                color = TextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Text(
                                            text = "${formatPrice(h.totalFee)} ت",
                                            color = CrystalGreen,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                        }

                        if (dayCash.isNotEmpty()) {
                            item(key = "hdr_day_cash") {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "دریافتی‌های نقدی این روز (${dayCash.size}):",
                                    color = CrystalAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            items(dayCash, key = { "rep_cash_${it.id}" }) { c ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = GamingCard,
                                    border = BorderStroke(1.dp, CrystalAmber.copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = c.note.ifBlank { "دریافت نقدی" },
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "${PersianDateUtils.formatTime(c.createdAtMillis)}${if (c.customerName.isNotBlank()) " | مشتری: ${c.customerName}" else ""}",
                                                color = TextSecondary,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Text(
                                            text = "+${formatPrice(c.amountTomans)} ت",
                                            color = CrystalAmber,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniLegendBadge(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(3.dp))
        Text(label, color = TextSecondary, fontSize = 9.sp, maxLines = 1, softWrap = false)
    }
}

private fun formatPrice(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
