package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CustomerCreditEntity
import com.example.data.model.CustomerDebtEntity
import com.example.data.model.DebtItemCodec
import com.example.data.model.DebtLineItem
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import java.util.Locale
import kotlin.math.abs

@Composable
fun DebtsScreen(
    debts: List<CustomerDebtEntity>,
    credits: List<CustomerCreditEntity> = emptyList(),
    voiceSearchHint: String = "",
    onRequestVoiceForSearch: () -> Unit = {},
    onAddDebt: (name: String, amount: Long, note: String) -> Unit,
    onAddCredit: (name: String, amount: Long, note: String) -> Unit = { _, _, _ -> },
    onAddCustomer: (code: String, name: String, phone: String, nationalId: String) -> Unit,
    onSettleDebt: (CustomerDebtEntity) -> Unit,
    onDeleteDebt: (CustomerDebtEntity) -> Unit,
    onDeleteCredit: (CustomerCreditEntity) -> Unit = {},
    onUpdateDebtLineItems: (debtId: Long, updatedItems: List<DebtLineItem>, updatedNote: String) -> Unit = { _, _, _ -> },
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var showAddCreditDialog by remember { mutableStateOf(false) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var debtToSettle by remember { mutableStateOf<CustomerDebtEntity?>(null) }
    var debtToDelete by remember { mutableStateOf<CustomerDebtEntity?>(null) }
    var creditToDelete by remember { mutableStateOf<CustomerCreditEntity?>(null) }
    var debtToEdit by remember { mutableStateOf<CustomerDebtEntity?>(null) }

    LaunchedEffect(voiceSearchHint) {
        if (voiceSearchHint.isNotBlank()) {
            searchQuery = voiceSearchHint
        }
    }

    val filteredDebts = remember(debts, searchQuery) {
        if (searchQuery.isBlank()) debts
        else debts.filter {
            it.customerName.contains(searchQuery, ignoreCase = true) ||
                it.customerCode.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredCredits = remember(credits, searchQuery) {
        val positive = credits.filter { it.amountTomans > 0L }
        if (searchQuery.isBlank()) positive
        else positive.filter {
            it.customerName.contains(searchQuery, ignoreCase = true) ||
                it.customerCode.contains(searchQuery, ignoreCase = true)
        }
    }

    val totalUnsettled = remember(debts) {
        debts.filter { !it.isSettled }.sumOf { it.amountTomans }
    }
    val totalCredits = remember(credits) {
        credits.filter { it.amountTomans > 0L }.sumOf { it.amountTomans }
    }
    val netBalance = totalUnsettled - totalCredits

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Total Net Balance Header Card («دفتر نسیه»)
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = GamingCardElevated,
            border = BorderStroke(
                1.dp,
                if (netBalance < 0L) CrystalCyan.copy(alpha = 0.55f) else CrystalAmber.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "دفتر نسیه",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = CrystalAmber,
                            fontSize = 15.sp
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                    Text(
                        text = "بدهی: ${formatNumber(totalUnsettled)} ت | طلب: ${formatNumber(totalCredits)} ت",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "تراز خالص (بدهی − طلب):",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp),
                        maxLines = 1,
                        softWrap = false
                    )
                    val formattedNet = when {
                        netBalance < 0L -> "-${formatNumber(abs(netBalance))} تومان"
                        else -> "${formatNumber(netBalance)} تومان"
                    }
                    Text(
                        text = formattedNet,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = when {
                                netBalance < 0L -> CrystalCyan
                                netBalance == 0L -> CrystalGreen
                                else -> CrystalAmber
                            },
                            fontSize = 14.5.sp
                        ),
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.testTag("debts_net_balance_text")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Search with Mic Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("جستجوی نام یا کد...", fontSize = 11.5.sp, color = TextTertiary, maxLines = 1, softWrap = false) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "پاک کردن", tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("debts_search_input"),
                shape = RoundedCornerShape(11.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CrystalCyan,
                    unfocusedBorderColor = GamingBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            IconButton(
                onClick = onRequestVoiceForSearch,
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(CrystalPurple.copy(alpha = 0.25f))
                    .testTag("debts_search_voice_btn")
            ) {
                Icon(Icons.Default.Mic, contentDescription = "جستجوی صوتی دفتر نسیه", tint = CrystalCyan)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Action Buttons Row: افزودن مشتری | ثبت بدهی | افزودن طلب
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(
                onClick = { showAddCustomerDialog = true },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .testTag("add_customer_debt_screen")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "افزودن مشتری", tint = Color.Black, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("مشتری", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, maxLines = 1, softWrap = false)
            }

            Button(
                onClick = { showAddDialog = true },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .testTag("add_debt_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "ثبت بدهی", tint = Color.Black, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("ثبت بدهی", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, maxLines = 1, softWrap = false)
            }

            Button(
                onClick = { showAddCreditDialog = true },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
                    .testTag("add_credit_button")
            ) {
                Icon(Icons.Default.AccountBalanceWallet, contentDescription = "افزودن طلب", tint = Color.Black, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("افزودن طلب", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, maxLines = 1, softWrap = false)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Debts & Credits List
        if (filteredDebts.isEmpty() && filteredCredits.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(50.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "هیچ بدهی یا طلبی در دفتر نسیه ثبت نشده است.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                if (filteredCredits.isNotEmpty()) {
                    item(key = "credits_section_header") {
                        Text(
                            text = "طلب‌های مشتریان (کسر خودکار از فاکتور بعدی):",
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                    }
                    items(filteredCredits, key = { "credit_${it.id}" }) { credit ->
                        CreditItemCard(
                            credit = credit,
                            onDeleteClick = { creditToDelete = credit }
                        )
                    }
                }

                items(filteredDebts, key = { "debt_${it.id}" }) { debt ->
                    DebtItemCard(
                        debt = debt,
                        onSettleClick = { debtToSettle = debt },
                        onEditClick = { debtToEdit = debt },
                        onDeleteClick = { debtToDelete = debt }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        AddDebtDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, amount, note ->
                onAddDebt(name, amount, note)
                showAddDialog = false
            }
        )
    }

    if (showAddCreditDialog) {
        AddCreditDialog(
            onDismiss = { showAddCreditDialog = false },
            onConfirm = { name, amount, note ->
                onAddCredit(name, amount, note)
                showAddCreditDialog = false
            }
        )
    }

    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onConfirm = { code, name, phone, nationalId ->
                onAddCustomer(code, name, phone, nationalId)
                showAddCustomerDialog = false
            }
        )
    }

    if (debtToEdit != null) {
        val target = debtToEdit!!
        EditDebtDialog(
            debt = target,
            onDismiss = { debtToEdit = null },
            onSave = { updatedItems, updatedNote ->
                onUpdateDebtLineItems(target.id, updatedItems, updatedNote)
                debtToEdit = null
            }
        )
    }

    if (debtToSettle != null) {
        val target = debtToSettle!!
        ConfirmDeleteDialog(
            title = "تایید تسویه حساب بدهی",
            message = "آیا مطمئن هستید که بدهی «${target.customerName}» به مبلغ ${formatNumber(target.amountTomans)} تومان تسویه شد؟\nبا تایید شما، مبلغ در آمار فروش ثبت شده و این مورد از دفتر نسیه پاک می‌شود.",
            confirmText = "بله، تسویه شد",
            confirmColor = CrystalGreen,
            onConfirm = {
                onSettleDebt(target)
                debtToSettle = null
            },
            onDismiss = { debtToSettle = null }
        )
    }

    if (debtToDelete != null) {
        val target = debtToDelete!!
        ConfirmDeleteDialog(
            title = "تایید حذف بدهی",
            message = "آیا از حذف رکورد بدهی «${target.customerName}» به مبلغ ${formatNumber(target.amountTomans)} تومان مطمئن هستید؟",
            onConfirm = {
                onDeleteDebt(target)
                debtToDelete = null
            },
            onDismiss = { debtToDelete = null }
        )
    }

    if (creditToDelete != null) {
        val target = creditToDelete!!
        ConfirmDeleteDialog(
            title = "تایید حذف طلب",
            message = "آیا از حذف رکورد طلب «${target.customerName}» به مبلغ ${formatNumber(target.amountTomans)} تومان مطمئن هستید؟",
            onConfirm = {
                onDeleteCredit(target)
                creditToDelete = null
            },
            onDismiss = { creditToDelete = null }
        )
    }
}

@Composable
fun CreditItemCard(
    credit: CustomerCreditEntity,
    onDeleteClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = GamingCard,
        border = BorderStroke(1.dp, CrystalCyan.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("credit_card_${credit.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = credit.customerName,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (credit.customerCode.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(shape = RoundedCornerShape(6.dp), color = CrystalCyan.copy(alpha = 0.2f)) {
                            Text(
                                text = "کد ${credit.customerCode}",
                                color = CrystalCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(shape = RoundedCornerShape(6.dp), color = CrystalPurple.copy(alpha = 0.25f)) {
                        Text(
                            text = "طلبکار",
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "${PersianDateUtils.formatJalaliDateTime(credit.createdAtMillis)}${if (credit.note.isNotBlank()) " | ${credit.note}" else ""}",
                    color = TextSecondary,
                    fontSize = 10.sp
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "+${formatNumber(credit.amountTomans)} ت",
                    color = CrystalCyan,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.5.sp,
                    maxLines = 1,
                    softWrap = false
                )
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("delete_credit_button_${credit.id}")
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "حذف طلب", tint = CrystalRed, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun AddCreditDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, amount: Long, note: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("افزودن طلب مشتری", color = CrystalCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "طلب مشتری در فاکتور بعدی او بصورت خودکار کسر می‌شود.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام یا کد مشتری", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_credit_customer_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                    label = { Text("مبلغ طلب (تومان)", fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_credit_amount_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("توضیحات (اختیاری)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            val amt = amountText.toLongOrNull() ?: 0L
                            if (name.isNotBlank() && amt > 0L) {
                                onConfirm(name.trim(), amt, note.trim())
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_add_credit_btn")
                    ) {
                        Text("ثبت طلب", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
fun DebtItemCard(
    debt: CustomerDebtEntity,
    onSettleClick: () -> Unit,
    onEditClick: () -> Unit = {},
    onDeleteClick: () -> Unit
) {
    val lineItems = remember(debt.debtItemsJson, debt.amountTomans) {
        DebtItemCodec.decode(debt.debtItemsJson)
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = GamingCard,
        border = BorderStroke(
            1.dp,
            if (debt.isSettled) CrystalGreen.copy(alpha = 0.3f) else CrystalAmber.copy(alpha = 0.35f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Text(
                        text = debt.customerName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 14.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (debt.customerCode.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = CrystalCyan.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "کد ${debt.customerCode}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (debt.isSettled) CrystalGreen.copy(alpha = 0.2f) else CrystalRed.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = if (debt.isSettled) "تسویه شده" else "بدهکار",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (debt.isSettled) CrystalGreen else CrystalRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = "${formatNumber(debt.amountTomans)} تومان",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = if (debt.isSettled) CrystalGreen else CrystalAmber,
                        fontSize = 14.sp
                    ),
                    maxLines = 1,
                    softWrap = false
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Consolidated Itemized Breakdown (when stored)
            if (lineItems.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = GamingSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        lineItems.forEachIndexed { idx, item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${idx + 1}. ${item.title}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.5.sp),
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${formatNumber(item.amountTomans)} ت",
                                    style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber, fontWeight = FontWeight.Bold, fontSize = 10.5.sp),
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            Text(
                text = "${PersianDateUtils.formatJalaliDateTime(debt.createdAtMillis)}${if (debt.note.isNotBlank()) " | ${debt.note}" else ""}",
                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.5.sp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!debt.isSettled) {
                    OutlinedButton(
                        onClick = onEditClick,
                        border = BorderStroke(1.dp, CrystalCyan),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalCyan),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("edit_debt_button_${debt.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ویرایش", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, softWrap = false)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Button(
                        onClick = onSettleClick,
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("settle_debt_button_${debt.id}")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "تسویه شد",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                } else if (debt.settledAtMillis > 0L) {
                    Text(
                        text = "تسویه در: ${PersianDateUtils.formatJalaliDateTime(debt.settledAtMillis)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen, fontSize = 10.sp),
                        modifier = Modifier.weight(1f)
                    )
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("delete_debt_button_${debt.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف بدهی",
                        tint = CrystalRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun EditDebtDialog(
    debt: CustomerDebtEntity,
    onDismiss: () -> Unit,
    onSave: (updatedItems: List<DebtLineItem>, updatedNote: String) -> Unit
) {
    val initialItems = remember(debt.id) {
        val decoded = DebtItemCodec.decode(debt.debtItemsJson)
        if (decoded.isNotEmpty()) decoded
        else listOf(
            DebtLineItem(
                id = "legacy_${debt.id}",
                title = debt.systemDisplayName.ifBlank { "بدهی ثبت‌شده" },
                amountTomans = debt.amountTomans,
                createdAtMillis = debt.createdAtMillis,
                systemDisplayName = debt.systemDisplayName,
                note = debt.note
            )
        )
    }

    var editableItems by remember(debt.id) { mutableStateOf(initialItems) }
    var noteText by remember(debt.id) { mutableStateOf(debt.note) }
    var showNewItemFields by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newAmountText by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 620.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ویرایش بدهی ${debt.customerName}",
                        color = CrystalCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                editableItems.forEachIndexed { idx, item ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("ردیف ${idx + 1}", color = CrystalAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                IconButton(
                                    onClick = {
                                        editableItems = editableItems.toMutableList().also { it.removeAt(idx) }
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "حذف ردیف", tint = CrystalRed, modifier = Modifier.size(16.dp))
                                }
                            }
                            OutlinedTextField(
                                value = item.title,
                                onValueChange = { txt ->
                                    editableItems = editableItems.toMutableList().also { it[idx] = item.copy(title = txt) }
                                },
                                label = { Text("عنوان", fontSize = 10.5.sp) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = item.amountTomans.toString(),
                                onValueChange = { txt ->
                                    val digits = PersianDateUtils.toAsciiDigits(txt).filter { c -> c.isDigit() || c == '-' }
                                    val amt = digits.toLongOrNull() ?: 0L
                                    editableItems = editableItems.toMutableList().also { it[idx] = item.copy(amountTomans = amt) }
                                },
                                label = { Text("مبلغ (تومان)", fontSize = 10.5.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Add separated new debt item into customer's account
                OutlinedButton(
                    onClick = { showNewItemFields = !showNewItemFields },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, CrystalGreen),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("toggle_add_debt_line_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("افزودن بدهی جدید و مجزا به این حساب", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }

                if (showNewItemFields) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCardElevated,
                        border = BorderStroke(1.dp, CrystalGreen.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = newTitle,
                                onValueChange = { newTitle = it },
                                label = { Text("شرح بدهی جدید (مثلاً نوشابه یا تایم مجزا)", fontSize = 10.5.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("new_debt_line_title_input")
                            )
                            OutlinedTextField(
                                value = newAmountText,
                                onValueChange = { newAmountText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                                label = { Text("مبلغ بدهی جدید (تومان)", fontSize = 10.5.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("new_debt_line_amount_input")
                            )
                            Button(
                                onClick = {
                                    val amt = newAmountText.toLongOrNull() ?: 0L
                                    if (amt > 0L) {
                                        val now = System.currentTimeMillis()
                                        val added = DebtLineItem(
                                            id = "d_add_${now}",
                                            title = newTitle.trim().ifBlank { "بدهی جدید مجزا" },
                                            amountTomans = amt,
                                            createdAtMillis = now,
                                            note = "ثبت‌شده از ویرایش"
                                        )
                                        editableItems = editableItems + added
                                        newTitle = ""
                                        newAmountText = ""
                                        showNewItemFields = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("confirm_add_debt_line_btn")
                            ) {
                                Text("اضافه کردن به لیست بدهی", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("توضیحات کلی حساب", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                val computedTotal = editableItems.sumOf { it.amountTomans }.coerceAtLeast(0L)
                Text(
                    text = "جمع کل نهایی پس از ویرایش: ${formatNumber(computedTotal)} تومان",
                    color = CrystalAmber,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    softWrap = false
                )

                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = { onSave(editableItems, noteText) },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_edit_debt_btn")
                    ) {
                        Text("ذخیره تغییرات", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
fun AddDebtDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, amount: Long, note: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalAmber),
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "ثبت بدهی جدید در دفتر حسابداری",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = CrystalAmber
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام یا کد مشتری (مثلا مبین دهقان یا 101)", fontSize = 11.sp, maxLines = 1) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalAmber,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("مبلغ بدهی (تومان)", fontSize = 12.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalAmber,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("توضیحات یا بابت چی (اختیاری)", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalAmber,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }

                    Button(
                        onClick = {
                            val amt = amountText.toLongOrNull() ?: 0L
                            if (name.isNotBlank() && amt > 0) {
                                onConfirm(name, amt, note)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber)
                    ) {
                        Text("ثبت بدهی", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

private fun formatNumber(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
