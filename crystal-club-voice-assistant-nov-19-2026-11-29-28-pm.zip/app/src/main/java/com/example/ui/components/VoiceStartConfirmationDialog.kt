package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CustomerEntity
import com.example.data.model.GameSystemEntity
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import com.example.viewmodel.PendingVoiceStartCommand
import com.example.viewmodel.VoiceStartMode

@Composable
fun VoiceStartConfirmationDialog(
    pending: PendingVoiceStartCommand,
    systems: List<GameSystemEntity>,
    busySystemIds: Set<Int>,
    customers: List<CustomerEntity>,
    onConfirm: (
        systemId: Int,
        playerCount: Int,
        mode: VoiceStartMode,
        durationMinutes: Int,
        amountTomans: Long,
        customerCode: String
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedSystemId by remember(pending) { mutableIntStateOf(pending.systemId) }
    var playerCount by remember(pending) { mutableIntStateOf(pending.playerCount.coerceIn(1, 6)) }
    var selectedMode by remember(pending) { mutableStateOf(pending.mode) }
    var durationText by remember(pending) { mutableStateOf(pending.durationMinutes.coerceAtLeast(5).toString()) }
    var amountText by remember(pending) { mutableStateOf(pending.amountTomans.coerceAtLeast(10000L).toString()) }
    var customerInput by remember(pending) { mutableStateOf(pending.customerCode) }

    val selectedSystem = remember(selectedSystemId, systems) {
        systems.firstOrNull { it.id == selectedSystemId }
    }
    val isSelectedBusy = busySystemIds.contains(selectedSystemId)

    val matchedCustomer = remember(customerInput, customers) {
        val q = customerInput.trim()
        if (q.isBlank()) null
        else customers.firstOrNull { it.customerCode.equals(q, ignoreCase = true) || it.name.equals(q, ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Mic, contentDescription = null, tint = CrystalCyan, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تایید اجرای دستور صوتی",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (pending.rawTranscript.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "متن شنیده‌شده: «${pending.rawTranscript}»",
                            style = MaterialTheme.typography.bodySmall.copy(color = CrystalAmber, fontWeight = FontWeight.SemiBold),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("انتخاب سیستم:", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(systems, key = { "vconfirm_sys_${it.id}" }) { sys ->
                        val busy = busySystemIds.contains(sys.id)
                        val isSel = selectedSystemId == sys.id
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = when {
                                busy -> GamingCard.copy(alpha = 0.45f)
                                isSel -> CrystalCyan
                                else -> GamingCard
                            },
                            border = BorderStroke(
                                1.dp,
                                when {
                                    busy -> CrystalRed.copy(alpha = 0.4f)
                                    isSel -> CrystalCyan
                                    else -> GamingBorder
                                }
                            ),
                            modifier = Modifier.clickable(enabled = !busy) { selectedSystemId = sys.id }
                        ) {
                            Text(
                                text = if (busy) "${sys.displayName} (مشغول)" else sys.displayName,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = when {
                                        busy -> TextTertiary
                                        isSel -> Color.Black
                                        else -> TextPrimary
                                    },
                                    fontWeight = FontWeight.Bold
                                ),
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("تعداد نفرات:", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    (1..4).forEach { p ->
                        val sel = playerCount == p
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (sel) CrystalPurple else GamingCard,
                            border = BorderStroke(1.dp, if (sel) CrystalPurple else GamingBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { playerCount = p }
                        ) {
                            Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = "$p نفر",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("نوع بازی / زمان‌بندی:", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(GamingCard)
                ) {
                    listOf(
                        VoiceStartMode.TIME to "تایمر معکوس",
                        VoiceStartMode.AMOUNT to "مبلغ دلخواه",
                        VoiceStartMode.OPEN to "ساعت آزاد"
                    ).forEach { (m, label) ->
                        val sel = selectedMode == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (sel) CrystalAmber else Color.Transparent)
                                .clickable { selectedMode = m }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (sel) Color.Black else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (selectedMode) {
                    VoiceStartMode.TIME -> {
                        OutlinedTextField(
                            value = durationText,
                            onValueChange = { durationText = PersianDateUtils.toAsciiDigits(it).filter { ch -> ch.isDigit() } },
                            label = { Text("مدت زمان (دقیقه)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrystalCyan,
                                unfocusedBorderColor = GamingBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                    VoiceStartMode.AMOUNT -> {
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = PersianDateUtils.toAsciiDigits(it).filter { ch -> ch.isDigit() } },
                            label = { Text("مبلغ هدف (تومان)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrystalAmber,
                                unfocusedBorderColor = GamingBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                    VoiceStartMode.OPEN -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = CrystalGreen.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, CrystalGreen.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "✓ بازی روی ${selectedSystem?.displayName ?: "سیستم"} بصورت زمان باز شروع خواهد شد.",
                                style = MaterialTheme.typography.bodySmall.copy(color = CrystalGreen),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = customerInput,
                    onValueChange = { customerInput = it },
                    label = { Text("کد یا نام مشتری (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalCyan,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                if (matchedCustomer != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "✓ مشتری: ${matchedCustomer.name}${if (matchedCustomer.discountPercent > 0) " (تخفیف ${matchedCustomer.discountPercent}٪)" else ""}",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen, fontWeight = FontWeight.Bold)
                    )
                }

                if (isSelectedBusy) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "⚠️ این سیستم هم‌اکنون مشغول است. لطفاً یک سیستم آزاد انتخاب کنید.",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalRed, fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("voice_confirm_cancel_btn")
                    ) {
                        Text("لغو", maxLines = 1, softWrap = false)
                    }

                    Button(
                        onClick = {
                            val dur = durationText.toIntOrNull()?.coerceAtLeast(1) ?: 60
                            val amt = amountText.toLongOrNull()?.coerceAtLeast(1000L) ?: 60000L
                            onConfirm(
                                selectedSystemId,
                                playerCount,
                                selectedMode,
                                dur,
                                amt,
                                customerInput.trim()
                            )
                        },
                        enabled = !isSelectedBusy && selectedSystem != null,
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.4f)
                            .height(46.dp)
                            .testTag("voice_confirm_start_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "تایید و شروع بازی",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }
    }
}
