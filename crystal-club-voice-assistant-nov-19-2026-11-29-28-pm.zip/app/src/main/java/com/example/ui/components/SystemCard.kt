package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SessionSegmentCodec
import com.example.ui.theme.*
import com.example.viewmodel.SystemWithSession
import java.util.Locale

@Composable
fun SystemCard(
    item: SystemWithSession,
    onClick: () -> Unit,
    onStopAlarm: () -> Unit,
    onTransferClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isBusy = item.session != null
    val isPaused = item.session?.isPaused == true
    val isAlarming = item.isExpired
    val hasSegments = remember(item.session?.segmentsJson) {
        SessionSegmentCodec.decode(item.session?.segmentsJson).isNotEmpty()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "card_alarm_anim")
    val alarmGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alarm_glow"
    )

    val borderColor = when {
        isAlarming -> CrystalRed.copy(alpha = alarmGlowAlpha)
        isPaused -> CrystalAmber.copy(alpha = 0.75f)
        isBusy -> CrystalCyan.copy(alpha = 0.6f)
        else -> GamingBorder
    }

    val icon: ImageVector = when (item.system.iconType) {
        "computer" -> Icons.Default.Computer
        "headset" -> Icons.Default.Headset
        "steering_wheel" -> Icons.Default.SportsMotorsports
        else -> Icons.Default.Gamepad
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag("system_card_${item.system.id}"),
        shape = RoundedCornerShape(18.dp),
        color = if (isBusy) GamingCardElevated else GamingCard,
        border = BorderStroke(if (isAlarming) 2.dp else 1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Top Row: System Icon + Name + Code + Status Badge + Overflow Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                when {
                                    isAlarming -> CrystalRed.copy(alpha = 0.2f)
                                    isPaused -> CrystalAmber.copy(alpha = 0.2f)
                                    isBusy -> CrystalCyan.copy(alpha = 0.15f)
                                    else -> Color(0xFF1E293B)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = item.system.displayName,
                            tint = when {
                                isAlarming -> CrystalRed
                                isPaused -> CrystalAmber
                                isBusy -> CrystalCyan
                                else -> TextSecondary
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = CrystalCyan.copy(alpha = 0.16f)
                            ) {
                                Text(
                                    text = "کد ${item.system.code}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = CrystalCyan,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    ),
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = item.system.displayName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontSize = 15.sp
                                ),
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "ساعتی ${formatNumber(item.system.hourlyRatePerPlayer)} ت",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextTertiary
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Status Badge (no 3-dot overflow menu)
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = when {
                        isAlarming -> CrystalRed
                        isPaused -> CrystalAmber.copy(alpha = 0.2f)
                        isBusy -> CrystalCyan.copy(alpha = 0.2f)
                        else -> CrystalGreen.copy(alpha = 0.15f)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isAlarming -> Color.White
                                        isPaused -> CrystalAmber
                                        isBusy -> CrystalCyan
                                        else -> CrystalGreen
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = when {
                                isAlarming -> "پایان وقت!"
                                isPaused -> "توقف موقت"
                                isBusy -> "در حال بازی"
                                else -> "آزاد"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    isAlarming -> Color.White
                                    isPaused -> CrystalAmber
                                    isBusy -> CrystalCyan
                                    else -> CrystalGreen
                                }
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isBusy && item.session != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = when {
                                isPaused -> "زمان متوقف شده:"
                                item.session.isCountDown -> "زمان باقیمانده:"
                                else -> "زمان گذشته:"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                            maxLines = 1,
                            softWrap = false
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (item.session.isCountDown) {
                                formatDuration(item.remainingSeconds)
                            } else {
                                formatDuration(item.elapsedSeconds)
                            },
                            fontFamily = OrbitronFontFamily,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isAlarming -> CrystalRed
                                isPaused -> CrystalAmber
                                item.remainingSeconds < 300 && item.session.isCountDown -> CrystalAmber
                                else -> CrystalCyan
                            },
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (hasSegments) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = CrystalAmber.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "چندمرحله‌ای",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = CrystalAmber,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        ),
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = CrystalPurple.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "${item.session.playerCount} نفره",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = CrystalPurple,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${formatNumber(item.currentCostTomans)} تومان",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = CrystalGreen
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                if (item.session.modeConversionNotes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = item.session.modeConversionNotes,
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan, fontSize = 10.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (item.session.snacksCost > 0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GamingCard,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "خوراکی: ${item.session.snacksDetail}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "+${formatNumber(item.session.snacksCost)} ت",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalAmber,
                                    fontWeight = FontWeight.Bold
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CrystalCyan.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, CrystalCyan.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .clickable(onClick = onTransferClick)
                            .testTag("card_transfer_btn_${item.system.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.SwapHoriz,
                                contentDescription = null,
                                tint = CrystalCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "انتقال به سیستم دیگر",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                if (isAlarming) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onStopAlarm,
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalRed),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("stop_alarm_button_${item.system.id}")
                    ) {
                        Icon(
                            Icons.Default.VolumeOff,
                            contentDescription = "قطع آلارم",
                            modifier = Modifier.size(16.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "قطع آلارم و تسویه",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "برای شروع دستی کلیک کنید یا با صدا بگویید",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "شروع بازی",
                        tint = CrystalGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

private fun formatDuration(seconds: Long): String {
    val sec = kotlin.math.abs(seconds)
    val hrs = sec / 3600
    val mins = (sec % 3600) / 60
    val s = sec % 60
    return if (hrs > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, s)
    } else {
        String.format(Locale.US, "%02d:%02d", mins, s)
    }
}

private fun formatNumber(number: Long): String {
    return String.format(Locale.US, "%,d", number)
}
