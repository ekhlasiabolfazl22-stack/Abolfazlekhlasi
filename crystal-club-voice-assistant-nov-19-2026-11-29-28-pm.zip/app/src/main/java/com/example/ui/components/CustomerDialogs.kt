package com.example.ui.components

import android.content.Context
import android.provider.ContactsContract
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CustomerDebtEntity
import com.example.data.model.CustomerEntity
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

data class PhoneContactItem(
    val id: String,
    val name: String,
    val phone: String
)

@Composable
fun ConfirmDeleteDialog(
    title: String,
    message: String,
    confirmText: String = "بله، حذف شود",
    confirmColor: Color = CrystalRed,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                color = confirmColor,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Text(
                text = message,
                color = TextPrimary,
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = confirmColor),
                modifier = Modifier.testTag("confirm_action_button")
            ) {
                Text(
                    text = confirmText,
                    color = if (confirmColor == CrystalRed) Color.White else Color.Black,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false
                )
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_action_button")
            ) {
                Text("انصراف", maxLines = 1, softWrap = false)
            }
        },
        containerColor = GamingSurface
    )
}

@Composable
fun EditCustomerDialog(
    customer: CustomerEntity,
    customerDebts: List<CustomerDebtEntity>,
    onDismiss: () -> Unit,
    onSaveCustomer: (CustomerEntity) -> Unit,
    onUpdateDebt: (CustomerDebtEntity) -> Unit,
    onDeleteDebt: (CustomerDebtEntity) -> Unit
) {
    var code by remember(customer.id) { mutableStateOf(customer.customerCode) }
    var name by remember(customer.id) { mutableStateOf(customer.name) }
    var phone by remember(customer.id) { mutableStateOf(customer.phone) }
    var nationalId by remember(customer.id) { mutableStateOf(customer.nationalId) }
    var discountText by remember(customer.id) { mutableStateOf(customer.discountPercent.toString()) }

    var editingDebt by remember { mutableStateOf<CustomerDebtEntity?>(null) }
    var debtToDelete by remember { mutableStateOf<CustomerDebtEntity?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 640.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ویرایش مشخصات و سوابق مشتری",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("کد مشتری (اجباری)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_customer_code_input")
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام و نام خانوادگی (اجباری)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_customer_name_input")
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("شماره تماس") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = nationalId,
                    onValueChange = { nationalId = it },
                    label = { Text("کد ملی") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = {
                            discountText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() }
                        },
                        label = { Text("درصد تخفیف (۰ تا ۱۰۰)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("edit_customer_discount_input")
                    )

                    OutlinedButton(
                        onClick = { discountText = "0" },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CrystalRed),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalRed),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                        modifier = Modifier.testTag("clear_customer_discount_btn")
                    ) {
                        Text(
                            text = "حذف تخفیف",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                // Customer's recorded debts management inside Edit Customer dialog
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = GamingBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "بدهی‌های ثبت‌شده برای این مشتری (${customerDebts.size} مورد):",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = CrystalAmber,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))

                if (customerDebts.isEmpty()) {
                    Text(
                        text = "بدهی ثبت‌شده‌ای برای این مشتری وجود ندارد.",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        customerDebts.forEach { d ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = GamingCard,
                                border = BorderStroke(1.dp, if (d.isSettled) CrystalGreen.copy(alpha = 0.3f) else CrystalAmber.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${formatPrice(d.amountTomans)} تومان (${if (d.isSettled) "تسویه‌شده" else "بدهکار"})",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = if (d.isSettled) CrystalGreen else CrystalAmber,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Text(
                                            text = "${PersianDateUtils.formatJalaliDateTime(d.createdAtMillis)}${if (d.note.isNotBlank()) " | ${d.note}" else ""}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Row {
                                        IconButton(
                                            onClick = { editingDebt = d },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "ویرایش بدهی", tint = CrystalCyan, modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(
                                            onClick = { debtToDelete = d },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "حذف بدهی", tint = CrystalRed, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            if (code.isNotBlank() && name.isNotBlank()) {
                                val disc = (discountText.toIntOrNull() ?: 0).coerceIn(0, 100)
                                onSaveCustomer(
                                    customer.copy(
                                        customerCode = code.trim(),
                                        name = name.trim(),
                                        phone = phone.trim(),
                                        nationalId = nationalId.trim(),
                                        discountPercent = disc
                                    )
                                )
                                onDismiss()
                            }
                        },
                        enabled = code.isNotBlank() && name.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_customer_edit_btn")
                    ) {
                        Text("ذخیره تغییرات", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }

    if (editingDebt != null) {
        val targetDebt = editingDebt!!
        var amtText by remember(targetDebt.id) { mutableStateOf(targetDebt.amountTomans.toString()) }
        var noteText by remember(targetDebt.id) { mutableStateOf(targetDebt.note) }
        Dialog(onDismissRequest = { editingDebt = null }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalAmber),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("ویرایش بدهی مشتری", color = CrystalAmber, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = amtText,
                        onValueChange = { amtText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                        label = { Text("مبلغ بدهی (تومان)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("توضیحات") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { editingDebt = null }, modifier = Modifier.weight(1f)) {
                            Text("انصراف", maxLines = 1, softWrap = false)
                        }
                        Button(
                            onClick = {
                                val newAmt = amtText.toLongOrNull() ?: targetDebt.amountTomans
                                if (newAmt >= 0L) {
                                    onUpdateDebt(targetDebt.copy(amountTomans = newAmt, note = noteText.trim()))
                                    editingDebt = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ذخیره", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }

    if (debtToDelete != null) {
        ConfirmDeleteDialog(
            title = "حذف بدهی مشتری",
            message = "آیا از حذف بدهی به مبلغ ${formatPrice(debtToDelete!!.amountTomans)} تومان مطمئن هستید؟",
            onConfirm = {
                onDeleteDebt(debtToDelete!!)
                debtToDelete = null
            },
            onDismiss = { debtToDelete = null }
        )
    }
}

@Composable
fun CustomerDebtBreakdownDialog(
    customer: CustomerEntity,
    debtsForCustomer: List<CustomerDebtEntity>,
    onDismiss: () -> Unit
) {
    val unsettledTotal = debtsForCustomer.filter { !it.isSettled }.sumOf { it.amountTomans }
    val settledTotal = debtsForCustomer.filter { it.isSettled }.sumOf { it.amountTomans }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalAmber),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 540.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "جزئیات زمانی بدهی‌های ${customer.name}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = CrystalAmber,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "جمع بدهی فعال: ${formatPrice(unsettledTotal)} تومان",
                            style = MaterialTheme.typography.labelMedium.copy(color = CrystalRed, fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                if (settledTotal > 0L) {
                    Text(
                        text = "جمع تسویه‌شده قبلی: ${formatPrice(settledTotal)} تومان",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (debtsForCustomer.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("هیچ بدهی برای این مشتری ثبت نشده است.", color = TextSecondary)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                    ) {
                        items(debtsForCustomer.sortedByDescending { it.createdAtMillis }, key = { "cust_debt_log_${it.id}" }) { d ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = GamingCard,
                                border = BorderStroke(1.dp, if (d.isSettled) CrystalGreen.copy(alpha = 0.35f) else CrystalAmber.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = PersianDateUtils.formatJalaliDateTime(d.createdAtMillis),
                                            style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan, fontWeight = FontWeight.Bold)
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (d.isSettled) CrystalGreen.copy(alpha = 0.2f) else CrystalRed.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = if (d.isSettled) "تسویه شد" else "بدهکار",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = if (d.isSettled) CrystalGreen else CrystalRed,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 10.sp
                                                ),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${formatPrice(d.amountTomans)} تومان",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = if (d.isSettled) CrystalGreen else CrystalAmber,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    )
                                    if (d.note.isNotBlank()) {
                                        Text(
                                            text = d.note,
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                        )
                                    }
                                    if (d.isSettled && d.settledAtMillis > 0L) {
                                        Text(
                                            text = "زمان تسویه: ${PersianDateUtils.formatJalaliDateTime(d.settledAtMillis)}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen, fontSize = 10.sp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("بستن", maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

@Composable
fun PhoneContactsPickerDialog(
    onDismiss: () -> Unit,
    onSelectContact: (name: String, phone: String) -> Unit
) {
    val context = LocalContext.current
    var search by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }
    var contacts by remember { mutableStateOf<List<PhoneContactItem>>(emptyList()) }

    LaunchedEffect(Unit) {
        contacts = withContext(Dispatchers.IO) {
            loadPhoneContacts(context)
        }
        isLoading = false
    }

    val filtered = remember(contacts, search) {
        if (search.isBlank()) contacts
        else contacts.filter {
            it.name.contains(search, ignoreCase = true) || it.phone.contains(search, ignoreCase = true)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalGreen),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 540.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "انتخاب مشتری از مخاطبین گوشی",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = CrystalGreen,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text("جستجوی نام یا شماره مخاطب...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                when {
                    isLoading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = CrystalGreen)
                        }
                    }
                    filtered.isEmpty() -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("مخاطبی یافت نشد.", color = TextSecondary)
                        }
                    }
                    else -> {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false)
                        ) {
                            itemsIndexed(filtered, key = { idx, it -> "contact_${idx}_${it.id}" }) { _, contact ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = GamingCard,
                                    border = BorderStroke(1.dp, GamingBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelectContact(contact.name, contact.phone) }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = contact.name,
                                                style = MaterialTheme.typography.bodyLarge.copy(
                                                    color = TextPrimary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            )
                                            Text(
                                                text = contact.phone,
                                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan)
                                            )
                                        }
                                        Icon(Icons.Default.PersonAdd, contentDescription = "انتخاب", tint = CrystalGreen)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("بستن", maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

private fun loadPhoneContacts(context: Context): List<PhoneContactItem> {
    val result = mutableListOf<PhoneContactItem>()
    val seenPhones = mutableSetOf<String>()
    try {
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone._ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null,
            null,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val id = if (idIdx >= 0) cursor.getString(idIdx) ?: "${result.size}" else "${result.size}"
                val name = if (nameIdx >= 0) cursor.getString(nameIdx)?.trim().orEmpty() else ""
                val rawNum = if (numIdx >= 0) cursor.getString(numIdx)?.trim().orEmpty() else ""
                val cleanNum = rawNum.replace(" ", "").replace("-", "")
                if (name.isNotBlank() && cleanNum.isNotBlank() && seenPhones.add("$name|$cleanNum")) {
                    result.add(PhoneContactItem(id = id, name = name, phone = cleanNum))
                }
            }
        }
    } catch (_: Exception) {}
    return result
}

private fun formatPrice(amount: Long): String {
    return String.format(Locale.US, "%,d", amount)
}
