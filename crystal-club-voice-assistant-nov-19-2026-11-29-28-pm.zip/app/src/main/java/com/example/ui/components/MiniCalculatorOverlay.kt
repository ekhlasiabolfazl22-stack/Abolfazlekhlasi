package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

@Composable
fun MiniCalculatorOverlay(
    onDismiss: () -> Unit
) {
    var displayText by remember { mutableStateOf("0") }
    var expressionPreview by remember { mutableStateOf("") }
    var accumulator by remember { mutableStateOf<Double?>(null) }
    var pendingOp by remember { mutableStateOf<String?>(null) }
    var resetOnNextDigit by remember { mutableStateOf(false) }

    fun formatCalcResult(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "خطا"
        val longVal = value.toLong()
        return if (kotlin.math.abs(value - longVal.toDouble()) < 1e-9) {
            longVal.toString()
        } else {
            val df = DecimalFormat("#.####", DecimalFormatSymbols(Locale.US))
            df.format(value)
        }
    }

    fun formatPrettyDisplay(raw: String): String {
        if (raw == "خطا") return raw
        val parts = raw.split(".")
        val intPart = parts[0].toLongOrNull()
        val formattedInt = if (intPart != null) String.format(Locale.US, "%,d", intPart) else parts[0]
        return if (parts.size > 1) "$formattedInt.${parts[1]}" else formattedInt
    }

    fun applyOperation(a: Double, b: Double, op: String): Double {
        return when (op) {
            "+" -> a + b
            "-" -> a - b
            "×" -> a * b
            "÷" -> if (b == 0.0) Double.NaN else a / b
            else -> b
        }
    }

    fun pressDigit(d: String) {
        if (displayText == "خطا") {
            displayText = "0"
            accumulator = null
            pendingOp = null
            expressionPreview = ""
        }
        if (resetOnNextDigit) {
            displayText = if (d == ".") "0." else d
            resetOnNextDigit = false
            return
        }
        if (d == ".") {
            if (!displayText.contains(".")) {
                displayText += "."
            }
        } else {
            displayText = if (displayText == "0") d else (displayText + d).take(14)
        }
    }

    fun pressOp(op: String) {
        val current = displayText.toDoubleOrNull() ?: return
        if (accumulator != null && pendingOp != null && !resetOnNextDigit) {
            val res = applyOperation(accumulator!!, current, pendingOp!!)
            accumulator = if (res.isNaN()) null else res
            displayText = formatCalcResult(res)
        } else {
            accumulator = current
        }
        pendingOp = op
        expressionPreview = "${formatPrettyDisplay(formatCalcResult(accumulator ?: 0.0))} $op"
        resetOnNextDigit = true
    }

    fun pressEquals() {
        val current = displayText.toDoubleOrNull() ?: return
        val acc = accumulator
        val op = pendingOp
        if (acc != null && op != null) {
            val res = applyOperation(acc, current, op)
            expressionPreview = "${formatPrettyDisplay(formatCalcResult(acc))} $op ${formatPrettyDisplay(formatCalcResult(current))} ="
            displayText = formatCalcResult(res)
            accumulator = null
            pendingOp = null
            resetOnNextDigit = true
        }
    }

    fun pressClear() {
        displayText = "0"
        expressionPreview = ""
        accumulator = null
        pendingOp = null
        resetOnNextDigit = false
    }

    fun pressBackspace() {
        if (resetOnNextDigit || displayText == "خطا") {
            displayText = "0"
            resetOnNextDigit = false
            return
        }
        displayText = if (displayText.length <= 1) "0" else displayText.dropLast(1)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            tonalElevation = 12.dp,
            modifier = Modifier
                .widthIn(min = 270.dp, max = 330.dp)
                .fillMaxWidth(0.84f)
                .testTag("mini_calculator_dialog")
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = null,
                            tint = CrystalCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ماشین‌حساب سریع",
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("close_calculator_btn")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "بستن ماشین‌حساب", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }

                // Display Screen
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorderGlow),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = expressionPreview.ifBlank { " " },
                            color = TextTertiary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.End
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = formatPrettyDisplay(displayText),
                            color = CrystalGreen,
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.End,
                            modifier = Modifier.testTag("calc_display_text")
                        )
                    }
                }

                // Top Row: Clear, Backspace, %, ÷
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CalcKeyButton(
                        label = "C",
                        bgColor = CrystalRed.copy(alpha = 0.22f),
                        textColor = CrystalRed,
                        borderColor = CrystalRed.copy(alpha = 0.6f),
                        onClick = { pressClear() },
                        modifier = Modifier.weight(1f).testTag("calc_key_C")
                    )
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCardElevated,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { pressBackspace() }
                            .testTag("calc_key_back")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                contentDescription = "حذف رقم",
                                tint = CrystalAmber,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    CalcKeyButton(
                        label = "000",
                        bgColor = GamingCardElevated,
                        textColor = CrystalAmber,
                        borderColor = GamingBorder,
                        onClick = {
                            if (!resetOnNextDigit && displayText != "0" && displayText != "خطا") {
                                displayText = (displayText + "000").take(14)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                    CalcKeyButton(
                        label = "÷",
                        bgColor = CrystalPurple.copy(alpha = 0.28f),
                        textColor = CrystalCyan,
                        borderColor = CrystalPurple.copy(alpha = 0.6f),
                        onClick = { pressOp("÷") },
                        modifier = Modifier.weight(1f).testTag("calc_key_div")
                    )
                }

                // Digits + Operators Grid (LTR visual numbers order inside rows: 7 8 9 ×)
                val rows = listOf(
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "-"),
                    listOf("1", "2", "3", "+")
                )
                rows.forEach { r ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        r.forEach { key ->
                            val isOp = key in listOf("×", "-", "+")
                            CalcKeyButton(
                                label = key,
                                bgColor = if (isOp) CrystalPurple.copy(alpha = 0.28f) else GamingCard,
                                textColor = if (isOp) CrystalCyan else TextPrimary,
                                borderColor = if (isOp) CrystalPurple.copy(alpha = 0.6f) else GamingBorder,
                                onClick = { if (isOp) pressOp(key) else pressDigit(key) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("calc_key_$key")
                            )
                        }
                    }
                }

                // Bottom Row: 0, ., =
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CalcKeyButton(
                        label = "0",
                        bgColor = GamingCard,
                        textColor = TextPrimary,
                        borderColor = GamingBorder,
                        onClick = { pressDigit("0") },
                        modifier = Modifier.weight(2f).testTag("calc_key_0")
                    )
                    CalcKeyButton(
                        label = ".",
                        bgColor = GamingCard,
                        textColor = TextPrimary,
                        borderColor = GamingBorder,
                        onClick = { pressDigit(".") },
                        modifier = Modifier.weight(1f)
                    )
                    CalcKeyButton(
                        label = "=",
                        bgColor = CrystalGreen,
                        textColor = Color.Black,
                        borderColor = CrystalGreen,
                        onClick = { pressEquals() },
                        modifier = Modifier.weight(1f).testTag("calc_key_eq")
                    )
                }
            }
        }
    }
}

@Composable
private fun CalcKeyButton(
    label: String,
    bgColor: Color,
    textColor: Color,
    borderColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}
