package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ActiveSessionEntity
import com.example.data.model.CustomerEntity
import com.example.data.model.GameHistoryEntity
import com.example.data.model.GameSystemEntity
import com.example.data.repository.MiniPlayerCheckoutData
import com.example.data.repository.SessionCostCalculator
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import java.util.Locale
import kotlin.math.max

@Composable
fun TransferSystemDialog(
    sourceSystem: GameSystemEntity,
    sourceSession: ActiveSessionEntity?,
    allSystems: List<GameSystemEntity>,
    activeSessionsBySystemId: Map<Int, ActiveSessionEntity>,
    customers: List<CustomerEntity> = emptyList(),
    voiceTranscriptHint: String = "",
    onRequestVoiceForCustomer: () -> Unit = {},
    onDismiss: () -> Unit,
    onConfirmTransfer: (
        selectedSeatIdsOrNullForAll: List<String>?,
        customerNameOrCode: String,
        targetSystem: GameSystemEntity
    ) -> Unit
) {
    var customerInput by remember(sourceSystem.id) { mutableStateOf("") }
    var transferAllPlayers by remember(sourceSystem.id) { mutableStateOf(true) }
    var selectedSeatIds by remember(sourceSystem.id) { mutableStateOf<Set<String>>(emptySet()) }

    LaunchedEffect(voiceTranscriptHint) {
        if (voiceTranscriptHint.isNotBlank()) {
            customerInput = voiceTranscriptHint
        }
    }

    val seats = remember(sourceSession) {
        if (sourceSession != null) SessionCostCalculator.ensureSeats(sourceSession) else emptyList()
    }

    val targetCandidates = remember(allSystems, sourceSystem.id) {
        allSystems.filter { it.id != sourceSystem.id }
    }

    val matchedCustomer = remember(customerInput, customers) {
        val q = customerInput.trim()
        if (q.isBlank()) null
        else customers.firstOrNull { it.customerCode.equals(q, ignoreCase = true) }
            ?: customers.firstOrNull { it.name.equals(q, ignoreCase = true) }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyan),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 620.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "انتقال از ${sourceSystem.displayName} (کد ${sourceSystem.code})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        ),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                if (sourceSession == null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "این سیستم در حال حاضر بازی فعالی ندارد. برای انتقال و ادغام، ابتدا بازی را شروع کنید یا از منوی سیستم در حال بازی اقدام نمایید.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("بستن", maxLines = 1, softWrap = false)
                    }
                    return@Column
                }

                Text(
                    text = "فاکتور فعلی نفر انتقالی حفظ و با تفکیک اسم در فاکتور سیستم مقصد (حتی اگر مشغول باشد) ادغام می‌شود.",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 11.sp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Player seat selection when session has multiple seats
                if (seats.size > 1) {
                    Text(
                        text = "انتخاب فرد برای انتقال:",
                        style = MaterialTheme.typography.labelMedium.copy(color = CrystalAmber, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item(key = "seat_all") {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (transferAllPlayers) CrystalCyan else GamingCard,
                                border = BorderStroke(1.dp, if (transferAllPlayers) CrystalCyan else GamingBorder),
                                modifier = Modifier.clickable {
                                    transferAllPlayers = true
                                    selectedSeatIds = emptySet()
                                }
                            ) {
                                Text(
                                    text = "همه (${seats.size} نفر)",
                                    color = if (transferAllPlayers) Color.Black else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                        itemsIndexed(seats, key = { idx, it -> "tr_seat_${idx}_${it.seatId}" }) { _, seat ->
                            val isSel = !transferAllPlayers && selectedSeatIds.contains(seat.seatId)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) CrystalAmber else GamingCard,
                                border = BorderStroke(1.dp, if (isSel) CrystalAmber else GamingBorder),
                                modifier = Modifier.clickable {
                                    transferAllPlayers = false
                                    selectedSeatIds = if (isSel) {
                                        val next = selectedSeatIds - seat.seatId
                                        if (next.isEmpty()) {
                                            transferAllPlayers = true
                                            emptySet()
                                        } else next
                                    } else {
                                        selectedSeatIds + seat.seatId
                                    }
                                }
                            ) {
                                Text(
                                    text = seat.displayName,
                                    color = if (isSel) Color.Black else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Customer Name / Code Input + Voice Mic Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = customerInput,
                        onValueChange = { customerInput = it },
                        label = {
                            Text(
                                text = "نام یا کد مشتری انتقالی (خالی = ناشناس)",
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("transfer_customer_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalCyan,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    IconButton(
                        onClick = onRequestVoiceForCustomer,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CrystalPurple.copy(alpha = 0.25f))
                            .testTag("transfer_customer_voice_btn")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "نام مشتری با صدا", tint = CrystalCyan)
                    }
                }

                if (matchedCustomer != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "✓ مشتری شناسایی شد: ${matchedCustomer.name} (کد ${matchedCustomer.customerCode})",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen, fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "انتخاب سیستم مقصد (آزاد یا مشغول برای ادغام):",
                    style = MaterialTheme.typography.labelMedium.copy(color = CrystalCyan, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                ) {
                    itemsIndexed(targetCandidates, key = { idx, it -> "transfer_target_${idx}_${it.id}" }) { _, target ->
                        val targetSess = activeSessionsBySystemId[target.id]
                        val isTargetBusy = targetSess != null
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GamingCard,
                            border = BorderStroke(
                                1.dp,
                                if (isTargetBusy) CrystalAmber.copy(alpha = 0.65f) else CrystalGreen.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val seatSelection = if (transferAllPlayers || selectedSeatIds.isEmpty()) {
                                        null
                                    } else {
                                        selectedSeatIds.toList()
                                    }
                                    onConfirmTransfer(seatSelection, customerInput.trim(), target)
                                }
                                .testTag("transfer_target_${target.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${target.displayName} (کد ${target.code})",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        ),
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (isTargetBusy) {
                                            "مشغول (${targetSess!!.playerCount} نفره) • ادغام با حفظ فاکتور قبلی"
                                        } else {
                                            "سیستم آزاد • نرخ ساعتی ${formatPrice(target.hourlyRatePerPlayer)} ت"
                                        },
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isTargetBusy) CrystalAmber else CrystalGreen,
                                            fontSize = 10.5.sp
                                        ),
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (isTargetBusy) Icons.Default.GroupAdd else Icons.Default.SwapHoriz,
                                    contentDescription = null,
                                    tint = if (isTargetBusy) CrystalAmber else CrystalCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("انصراف", maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

@Composable
fun MiniPlayerCheckoutDialog(
    data: MiniPlayerCheckoutData,
    customers: List<CustomerEntity> = emptyList(),
    onDismiss: () -> Unit,
    onConfirmPaid: (
        editedHistory: GameHistoryEntity,
        customerInput: String,
        cashPaidTomans: Long,
        cardPaidTomans: Long
    ) -> Unit,
    onConfirmDebt: (
        editedHistory: GameHistoryEntity,
        customerInput: String,
        cashPaidTomans: Long,
        cardPaidTomans: Long
    ) -> Unit
) {
    var customerInput by remember(data.departingSeat.seatId) {
        mutableStateOf(data.departingSeat.customerCode.ifBlank { data.departingSeat.displayName })
    }
    var feeText by remember(data.departingSeat.seatId) {
        mutableStateOf(data.previewHistory.totalFee.toString())
    }
    var cardPaidText by remember { mutableStateOf("") }
    var cashPaidText by remember { mutableStateOf("") }

    val totalFee = feeText.toLongOrNull()?.coerceAtLeast(0L) ?: data.previewHistory.totalFee
    val cardPaid = cardPaidText.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
    val cashPaid = cashPaidText.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
    val remaining = max(0L, totalFee - cardPaid - cashPaid)

    val editedHist = remember(totalFee, customerInput, data) {
        val gFee = max(0L, totalFee - data.previewHistory.snacksFee)
        data.previewHistory.copy(
            totalFee = totalFee,
            gameFee = gFee,
            customerName = customerInput.trim().ifBlank { data.departingSeat.displayName }
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalMagenta),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 600.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "فاکتور خروج: ${data.departingSeat.displayName}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = CrystalMagenta,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "انصراف", tint = TextSecondary)
                    }
                }

                Text(
                    text = "پس از تسویه، سهم این فرد از فاکتور اصلی ${data.systemDisplayName} کسر شده و بقیه بازی را ادامه می‌دهند.",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 11.sp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        data.breakdown.detailLines.forEach { line ->
                            Text(line, style = MaterialTheme.typography.labelSmall.copy(color = TextPrimary))
                        }
                        HorizontalDivider(color = GamingBorder, modifier = Modifier.padding(vertical = 4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("سهم قابل پرداخت این نفر:", color = TextSecondary, fontSize = 12.sp)
                            Text(
                                text = "${formatPrice(totalFee)} ت",
                                color = CrystalGreen,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = customerInput,
                    onValueChange = { customerInput = it },
                    label = { Text("نام یا کد مشتری", fontSize = 11.sp, maxLines = 1) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = feeText,
                    onValueChange = { feeText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                    label = { Text("مبلغ فاکتور کوچک (تومان)", fontSize = 11.sp, maxLines = 1) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = cardPaidText,
                        onValueChange = { cardPaidText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                        label = { Text("کسر کارتخوان (ت)", fontSize = 10.sp, maxLines = 1) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = cashPaidText,
                        onValueChange = { cashPaidText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                        label = { Text("کسر نقدی (ت)", fontSize = 10.sp, maxLines = 1) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                if (cardPaid > 0L || cashPaid > 0L) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "باقیمانده: ${formatPrice(remaining)} ت",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber, fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { onConfirmPaid(editedHist, customerInput.trim(), cashPaid, cardPaid) },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("mini_checkout_paid_btn")
                    ) {
                        Text("تسویه شد", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, softWrap = false)
                    }

                    OutlinedButton(
                        onClick = { onConfirmDebt(editedHist, customerInput.trim(), cashPaid, cardPaid) },
                        border = BorderStroke(1.dp, CrystalAmber),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalAmber),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("mini_checkout_debt_btn")
                    ) {
                        Text("ثبت در بدهی", fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

private fun formatPrice(amount: Long): String {
    return String.format(Locale.US, "%,d", amount)
}
