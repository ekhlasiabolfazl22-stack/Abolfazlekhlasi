package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ActiveSessionEntity
import com.example.data.model.CustomerEntity
import com.example.data.model.GameSystemEntity
import com.example.data.model.PlayerSeat
import com.example.data.model.SessionSnackCodec
import com.example.data.model.SnackItemEntity
import com.example.data.repository.SessionCostCalculator
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SystemDetailPopupSheet(
    system: GameSystemEntity,
    session: ActiveSessionEntity?,
    snacksList: List<SnackItemEntity>,
    allSystems: List<GameSystemEntity> = emptyList(),
    busySystemIds: Set<Int> = emptySet(),
    activeSessionsBySystemId: Map<Int, ActiveSessionEntity> = emptyMap(),
    customers: List<CustomerEntity> = emptyList(),
    voiceTranscriptHint: String = "",
    onRequestVoiceForCustomer: () -> Unit = {},
    onDismiss: () -> Unit,
    onAddSnack: (snackName: String, count: Int, targetSeatId: String?) -> Unit,
    onRemoveSnackLine: (lineId: String) -> Unit = {},
    onUpdateSessionNote: (note: String) -> Unit = {},
    onUpdateSeatCustomerName: (seatId: String, newNameOrCode: String) -> Unit = { _, _ -> },
    onModifyTimer: (additionalMinutes: Int) -> Unit,
    onUpdatePlayersFromStart: (newCount: Int, addedNames: List<String>) -> Unit = { _, _ -> },
    onAddPlayersFromNow: (addedNames: List<String>) -> Unit = {},
    onRequestMiniCheckoutForSeat: (seatId: String) -> Unit = {},
    onConvertCountdownToOpen: () -> Unit = {},
    onConvertOpenToCountdown: (targetDurationMinutes: Int) -> Unit = {},
    onConvertAmountToTime: (amountTomans: Long) -> Unit = {},
    onTransferOrMerge: (selectedSeatIdsOrNullForAll: List<String>?, customerInput: String, targetSystem: GameSystemEntity) -> Unit = { _, _, _ -> },
    onPauseSession: () -> Unit = {},
    onResumeSession: () -> Unit = {},
    onFinishSession: () -> Unit
) {
    val modalBottomSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showTransferDialog by remember { mutableStateOf(false) }
    var pendingSnackForAssign by remember { mutableStateOf<SnackItemEntity?>(null) }
    var editingSeatForRename by remember { mutableStateOf<PlayerSeat?>(null) }
    var noteInput by remember(session?.id, session?.sessionNote) {
        mutableStateOf(session?.sessionNote ?: "")
    }

    // Explicit player count change confirmation states
    var pendingPlayerCount by remember(session?.id, session?.playerCount) {
        mutableIntStateOf(session?.playerCount ?: 1)
    }
    var showPlayerChangeDialog by remember { mutableStateOf(false) }
    var showDepartingSeatPicker by remember { mutableStateOf(false) }
    var addedPlayerInputs by remember { mutableStateOf<List<String>>(emptyList()) }

    // Game mode conversion dialog
    var showModeConvertDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = modalBottomSheetState,
        containerColor = GamingSurface,
        scrimColor = Color.Black.copy(alpha = 0.65f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 10.dp)
                .navigationBarsPadding()
        ) {
            // Header: System name + Code + Close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CrystalCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Gamepad, contentDescription = null, tint = CrystalCyan)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${system.displayName} (کد ${system.code})",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = CrystalCyan,
                                fontSize = 16.sp
                            ),
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = when {
                                session == null -> "سیستم آزاد است"
                                session.isPaused -> "توقف موقت (${session.playerCount} نفره)"
                                else -> "در حال بازی (${session.playerCount} نفره)"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (session?.isPaused == true) CrystalAmber else TextSecondary
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                }
            }

            if (session == null) {
                Spacer(modifier = Modifier.height(24.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = GamingCard,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "این سیستم در حال حاضر بازی فعالی ندارد. برای شروع بازی از صفحه اصلی روی کارت سیستم کلیک کنید.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
                        modifier = Modifier.padding(16.dp)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
                return@ModalBottomSheet
            }

            val seats = remember(session) { SessionCostCalculator.ensureSeats(session) }
            val effectiveNow = if (session.isPaused && session.pausedAtMillis > 0L) {
                session.pausedAtMillis
            } else {
                System.currentTimeMillis()
            }
            val billing = SessionCostCalculator.calculateLiveBilling(
                session = session,
                effectiveNowMillis = effectiveNow,
                forFinalReceipt = false
            )
            val seatBreakdowns = remember(session, effectiveNow) {
                SessionCostCalculator.calculateSeatBreakdowns(session, effectiveNow, forFinalReceipt = false)
            }
            val totalFee = billing.totalFeeWithSnacks

            Spacer(modifier = Modifier.height(12.dp))

            // Current Session Overview Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = GamingCardElevated,
                border = BorderStroke(1.dp, GamingBorderGlow),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "شروع: ${PersianDateUtils.formatTime(session.startTimeMillis)}",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                                maxLines = 1,
                                softWrap = false
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "بازی تا الان: ${billing.totalPlayedMinutes} دقیقه",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "مجموع حساب تا الان:",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                                maxLines = 1,
                                softWrap = false
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${formatNumber(totalFee)} تومان",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CrystalGreen
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    if (session.modeConversionNotes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CrystalCyan.copy(alpha = 0.1f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = session.modeConversionNotes,
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan, fontSize = 10.5.sp),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = GamingBorder)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "نفرات حاضر (${seatBreakdowns.size} نفر):",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalPurple, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    seatBreakdowns.forEach { bd ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• ${bd.seat.displayName}${if (bd.priorGameFee > 0L) " (انتقالی: ${formatNumber(bd.priorGameFee)} ت)" else ""}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 11.sp),
                                    modifier = Modifier.weight(1f, fill = false),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                IconButton(
                                    onClick = { editingSeatForRename = bd.seat },
                                    modifier = Modifier
                                        .size(26.dp)
                                        .testTag("edit_seat_name_btn_${bd.seat.seatId}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "ویرایش نام مشتری",
                                        tint = CrystalCyan,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            Text(
                                text = "${formatNumber(bd.totalShare)} ت",
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }

                    if (billing.completedSegments.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = GamingBorder)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "مراحل قبلی ثبت‌شده (${billing.completedSegments.size} مرحله):",
                            style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber, fontWeight = FontWeight.Bold)
                        )
                        billing.completedSegments.forEachIndexed { index, seg ->
                            Text(
                                text = "${index + 1}) ${seg.systemDisplayName} (${seg.playerCount} نفره) | ${PersianDateUtils.formatTime(seg.startTimeMillis)} تا ${PersianDateUtils.formatTime(seg.endTimeMillis)} = ${formatNumber(seg.costTomans)} ت",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.5.sp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Pause / Resume + Transfer System Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (session.isPaused) onResumeSession() else onPauseSession()
                    },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, if (session.isPaused) CrystalGreen else CrystalAmber),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (session.isPaused) CrystalGreen else CrystalAmber
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                ) {
                    Icon(
                        imageVector = if (session.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (session.isPaused) "ادامه تایمر" else "توقف موقت",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                OutlinedButton(
                    onClick = { showTransferDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CrystalCyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalCyan),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("transfer_system_button")
                ) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "انتقال به سیستم دیگر",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Mode conversion button («تغییر تایم بازی»)
            OutlinedButton(
                onClick = { showModeConvertDialog = true },
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CrystalPurple),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalPurple),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .testTag("change_game_mode_btn")
            ) {
                Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(17.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "تغییر تایم بازی (معکوس ↔ آزاد / مبلغ به تایم)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 1: Snacks quick-add
            Text(
                text = "افزودن خوراکی به سیستم:",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = CrystalAmber,
                    fontSize = 14.sp
                )
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(snacksList, key = { "popup_snack_${it.id}" }) { snack ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier
                            .clickable {
                                if (seats.size > 1) {
                                    pendingSnackForAssign = snack
                                } else {
                                    onAddSnack(snack.name, 1, null)
                                }
                            }
                            .testTag("add_snack_${snack.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "+ ${snack.name}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                            Text(
                                text = "${formatNumber(snack.priceTomans)} ت",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalCyan
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            val snackLines = remember(session.snacksItemsJson) {
                SessionSnackCodec.decode(session.snacksItemsJson)
            }
            if (snackLines.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, CrystalAmber.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "خوراکی‌های ثبت‌شده (${snackLines.size}):",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalAmber,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "جمع: ${formatNumber(session.snacksCost)} ت",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CrystalAmber,
                                    fontWeight = FontWeight.ExtraBold
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                        snackLines.forEach { line ->
                            val seatLabel = seats.firstOrNull { it.seatId == line.targetSeatId }?.displayName
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• ${line.snackName} × ${line.count}${if (seatLabel != null) " ($seatLabel)" else ""}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 11.sp),
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${formatNumber(line.totalPrice)} ت",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = CrystalCyan,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        ),
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { onRemoveSnackLine(line.id) },
                                        modifier = Modifier
                                            .size(26.dp)
                                            .testTag("delete_snack_line_${line.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "حذف خوراکی",
                                            tint = CrystalRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (session.snacksCost > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = GamingCard,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "خوراکی‌ها: ${session.snacksDetail}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${formatNumber(session.snacksCost)} ت",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = CrystalAmber
                            ),
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Editable Session Note («یادداشت»)
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = GamingCard,
                border = BorderStroke(1.dp, GamingBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = noteInput,
                        onValueChange = { noteInput = it },
                        label = { Text("یادداشت (اختیاری)", fontSize = 10.5.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("session_note_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalCyan,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Button(
                        onClick = { onUpdateSessionNote(noteInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("save_session_note_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "ذخیره یادداشت", tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("ثبت", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, softWrap = false)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 2: Timer Modification (+10, +15, +30, -10)
            Text(
                text = "تغییر و اصلاح تایمر معکوس:",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = CrystalCyan,
                    fontSize = 14.sp
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(10, 15, 30, -10).forEach { delta ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (delta > 0) CrystalCyan.copy(alpha = 0.15f) else CrystalRed.copy(alpha = 0.15f),
                        border = BorderStroke(
                            1.dp,
                            if (delta > 0) CrystalCyan else CrystalRed
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onModifyTimer(delta) }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (delta > 0) "+$delta د" else "$delta د",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (delta > 0) CrystalCyan else CrystalRed,
                                    fontWeight = FontWeight.Bold
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 3: Explicit Player count adjustment (+ / - plus Confirm «تایید»)
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = GamingCard,
                border = BorderStroke(1.dp, GamingBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تعداد نفرات فعلی (${session.playerCount} نفر):",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontSize = 13.sp
                                ),
                                maxLines = 1,
                                softWrap = false
                            )
                            Text(
                                text = "با +/- تغییر دهید و «تایید» را بزنید",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary, fontSize = 10.sp)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { if (pendingPlayerCount > 1) pendingPlayerCount-- },
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("dec_player_btn")
                            ) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "کاهش نفرات", tint = CrystalMagenta)
                            }
                            Text(
                                text = "$pendingPlayerCount",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CrystalPurple
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp),
                                maxLines = 1,
                                softWrap = false
                            )
                            IconButton(
                                onClick = { if (pendingPlayerCount < 8) pendingPlayerCount++ },
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("inc_player_btn")
                            ) {
                                Icon(Icons.Default.AddCircleOutline, contentDescription = "افزایش نفرات", tint = CrystalCyan)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = {
                                    val delta = pendingPlayerCount - session.playerCount
                                    if (delta > 0) {
                                        addedPlayerInputs = List(delta) { "" }
                                        showPlayerChangeDialog = true
                                    } else if (delta < 0) {
                                        showPlayerChangeDialog = true
                                    }
                                },
                                enabled = pendingPlayerCount != session.playerCount,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CrystalGreen,
                                    disabledContainerColor = GamingBorder
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("confirm_player_count_btn")
                            ) {
                                Text(
                                    text = "تایید",
                                    color = if (pendingPlayerCount != session.playerCount) Color.Black else TextTertiary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    if (seats.size > 1) {
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { showDepartingSeatPicker = true },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, CrystalAmber.copy(alpha = 0.6f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalAmber),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(34.dp)
                                .testTag("departing_seat_checkout_btn")
                        ) {
                            Icon(Icons.Default.PersonRemove, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تسویه و خروج یک نفر (ادامه بازی سایرین)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Section 4: Finish Button
            Button(
                onClick = onFinishSession,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("finish_session_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CrystalMagenta)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "پایان بازی و تسویه (${formatNumber(totalFee)} ت)",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "محاسبه منصفانه: ${billing.totalPlayedMinutes} دقیقه بازی واقعی تا این لحظه",
                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                maxLines = 1,
                softWrap = false
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    // 1. Snack Assignment Dialog (when > 1 player)
    if (pendingSnackForAssign != null && session != null) {
        val targetSnack = pendingSnackForAssign!!
        val currentSeats = SessionCostCalculator.ensureSeats(session)
        Dialog(
            onDismissRequest = { pendingSnackForAssign = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalAmber),
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .heightIn(max = 460.dp)
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Text(
                        text = "خوراکی «${targetSnack.name}» متعلق به کیست؟",
                        color = CrystalAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            onAddSnack(targetSnack.name, 1, null)
                            pendingSnackForAssign = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("مشترک بین همه (${currentSeats.size} نفر)", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    currentSeats.forEach { seat ->
                        OutlinedButton(
                            onClick = {
                                onAddSnack(targetSnack.name, 1, seat.seatId)
                                pendingSnackForAssign = null
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        ) {
                            Text("فقط برای ${seat.displayName}", color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    TextButton(onClick = { pendingSnackForAssign = null }, modifier = Modifier.align(Alignment.End)) {
                        Text("انصراف", color = TextSecondary, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }

    // 2. Explicit Player Count Change Dialog («از ابتدا» vs «از الان»)
    if (showPlayerChangeDialog && session != null) {
        val currentSeats = SessionCostCalculator.ensureSeats(session)
        val isIncreasing = pendingPlayerCount > session.playerCount
        Dialog(
            onDismissRequest = {
                showPlayerChangeDialog = false
                pendingPlayerCount = session.playerCount
            },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = GamingSurface,
                border = BorderStroke(1.5.dp, CrystalGreen),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .heightIn(max = 560.dp)
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp)
                ) {
                    Text(
                        text = "تغییر تعداد نفرات (${session.playerCount} به $pendingPlayerCount نفر)",
                        color = CrystalGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isIncreasing) {
                            "آیا افزایش نفر از ابتدای بازی لحاظ شود یا از همین لحظه؟ نام فرد جدید اختیاری است (خالی = ناشناس)."
                        } else {
                            "اگر نفر از ابتدا اشتباه بوده «از ابتدا» و اگر الآن بلند شده «از الان» را بزنید تا فاکتور خروج وی صادر شود."
                        },
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )

                    if (isIncreasing && addedPlayerInputs.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        addedPlayerInputs.forEachIndexed { idx, txt ->
                            OutlinedTextField(
                                value = txt,
                                onValueChange = { newVal ->
                                    addedPlayerInputs = addedPlayerInputs.toMutableList().also { it[idx] = newVal }
                                },
                                label = { Text("نام یا کد فرد جدید ${idx + 1} (خالی = ناشناس)", fontSize = 11.sp, maxLines = 1) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                showPlayerChangeDialog = false
                                onUpdatePlayersFromStart(pendingPlayerCount, addedPlayerInputs)
                            },
                            border = BorderStroke(1.dp, CrystalAmber),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalAmber),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("player_change_from_start_btn")
                        ) {
                            Text("از ابتدا", fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }

                        Button(
                            onClick = {
                                showPlayerChangeDialog = false
                                if (isIncreasing) {
                                    onAddPlayersFromNow(addedPlayerInputs)
                                } else {
                                    if (currentSeats.size <= 1) {
                                        onFinishSession()
                                    } else {
                                        showDepartingSeatPicker = true
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("player_change_from_now_btn")
                        ) {
                            Text("از الان", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    TextButton(
                        onClick = {
                            showPlayerChangeDialog = false
                            pendingPlayerCount = session.playerCount
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("انصراف", color = TextSecondary, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }

    // 3. Pick which player is leaving («از الان» -> MiniPlayerCheckoutDialog)
    if (showDepartingSeatPicker && session != null) {
        val currentSeats = SessionCostCalculator.ensureSeats(session)
        DepartingSeatPickerDialog(
            seats = currentSeats,
            onDismiss = {
                showDepartingSeatPicker = false
                pendingPlayerCount = session.playerCount
            },
            onSelectSeat = { seat ->
                showDepartingSeatPicker = false
                onRequestMiniCheckoutForSeat(seat.seatId)
            }
        )
    }

    // 4. Game Mode Conversion Dialog («تغییر تایم بازی»)
    if (showModeConvertDialog && session != null) {
        GameModeConversionDialog(
            session = session,
            onDismiss = { showModeConvertDialog = false },
            onCountdownToOpen = {
                showModeConvertDialog = false
                onConvertCountdownToOpen()
            },
            onOpenToCountdown = { mins ->
                showModeConvertDialog = false
                onConvertOpenToCountdown(mins)
            },
            onAmountToTime = { amt ->
                showModeConvertDialog = false
                onConvertAmountToTime(amt)
            }
        )
    }

    // 5. Full Multi-System Merge & Transfer Dialog
    if (showTransferDialog) {
        TransferSystemDialog(
            sourceSystem = system,
            sourceSession = session,
            allSystems = allSystems,
            activeSessionsBySystemId = activeSessionsBySystemId,
            customers = customers,
            voiceTranscriptHint = voiceTranscriptHint,
            onRequestVoiceForCustomer = onRequestVoiceForCustomer,
            onDismiss = { showTransferDialog = false },
                onConfirmTransfer = { seatIds, customerInput, target ->
                    showTransferDialog = false
                    onTransferOrMerge(seatIds, customerInput, target)
                }
            )
        }

    // 6. Rename Active Player Seat Dialog
    if (editingSeatForRename != null && session != null) {
        val targetSeat = editingSeatForRename!!
        var newNameText by remember(targetSeat.seatId) {
            mutableStateOf(targetSeat.customerCode.ifBlank { targetSeat.displayName })
        }
        AlertDialog(
            onDismissRequest = { editingSeatForRename = null },
            containerColor = GamingSurface,
            title = {
                Text("ویرایش نام یا کد بازیکن", color = CrystalCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "نام فعلی: ${targetSeat.displayName}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = newNameText,
                        onValueChange = { newNameText = it },
                        label = { Text("نام یا کد مشتری جدید", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rename_seat_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateSeatCustomerName(targetSeat.seatId, newNameText)
                        editingSeatForRename = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                    modifier = Modifier.testTag("confirm_rename_seat_btn")
                ) {
                    Text("ذخیره", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { editingSeatForRename = null }) {
                    Text("انصراف", maxLines = 1, softWrap = false)
                }
            }
        )
    }
}

@Composable
private fun DepartingSeatPickerDialog(
    seats: List<PlayerSeat>,
    onDismiss: () -> Unit,
    onSelectSeat: (PlayerSeat) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalMagenta),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .heightIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Text(
                    text = "کدام بازیکن از سیستم بلند شده است؟",
                    color = CrystalMagenta,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "پس از انتخاب، فاکتور کوچک همان نفر صادر می‌شود و بعد از تسویه از فاکتور اصلی کسر خواهد شد.",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                )
                Spacer(modifier = Modifier.height(10.dp))
                seats.forEach { seat ->
                    OutlinedButton(
                        onClick = { onSelectSeat(seat) },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CrystalCyan),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .testTag("pick_departing_seat_${seat.seatId}")
                    ) {
                        Text(
                            text = "${seat.displayName} (صدور فاکتور خروج)",
                            color = CrystalCyan,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("انصراف", color = TextSecondary, maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

@Composable
private fun GameModeConversionDialog(
    session: ActiveSessionEntity,
    onDismiss: () -> Unit,
    onCountdownToOpen: () -> Unit,
    onOpenToCountdown: (minutes: Int) -> Unit,
    onAmountToTime: (amountTomans: Long) -> Unit
) {
    var countdownMinutesText by remember { mutableStateOf("60") }
    var amountText by remember { mutableStateOf("100000") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalPurple),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 580.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تغییر تایم بازی",
                        color = CrystalPurple,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 1. Countdown -> Open
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, CrystalCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("۱. معکوس به آزاد", color = CrystalCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            text = "زمان شروع قبلی (${PersianDateUtils.formatTime(session.startTimeMillis)}) حفظ می‌شود و تایمر از محدودیت خارج شده و آزاد می‌چرخد.",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.5.sp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onCountdownToOpen,
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("convert_countdown_to_open_btn")
                        ) {
                            Text("تبدیل معکوس به آزاد", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Open -> Countdown
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, CrystalGreen.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("۲. آزاد به معکوس", color = CrystalGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            text = "مدت کل مدنظر را وارد کنید؛ زمان بازی‌شده تا الآن کسر و باقیمانده روی تایمر معکوس تنظیم می‌شود.",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.5.sp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(30, 60, 90, 120).forEach { m ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = CrystalGreen.copy(alpha = 0.14f),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { countdownMinutesText = m.toString() }
                                ) {
                                    Box(modifier = Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                        Text("$m د", color = CrystalGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = countdownMinutesText,
                                onValueChange = { countdownMinutesText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                                label = { Text("کل دقیقه", fontSize = 11.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    val mins = countdownMinutesText.toIntOrNull() ?: 60
                                    if (mins > 0) onOpenToCountdown(mins)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("convert_open_to_countdown_btn")
                            ) {
                                Text("تبدیل", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 3. Amount -> Time
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, CrystalAmber.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("۳. مبلغ به تایم", color = CrystalAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            text = "مبلغ کل بودجه مشتری را وارد کنید؛ زمان معادل محاسبه، زمان قبلی کسر و باقیمانده تایمر معکوس می‌شود.",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.5.sp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = amountText,
                                onValueChange = { amountText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                                label = { Text("مبلغ (تومان)", fontSize = 11.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    val amt = amountText.toLongOrNull() ?: 0L
                                    if (amt > 0L) onAmountToTime(amt)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("convert_amount_to_time_btn")
                            ) {
                                Text("اعمال مبلغ", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatNumber(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
