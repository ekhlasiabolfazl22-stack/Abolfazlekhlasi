package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CustomerCreditEntity
import com.example.data.model.CustomerDebtEntity
import com.example.data.model.CustomerEntity
import com.example.data.model.GameHistoryEntity
import com.example.data.model.SessionSegmentCodec
import com.example.data.repository.PlayerSeatBreakdown
import com.example.data.repository.SeatResolutionInput
import com.example.data.repository.SessionCostCalculator
import com.example.ui.theme.*
import com.example.util.PersianDateUtils
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private enum class PastDebtOption {
    NONE,
    FULL,
    PARTIAL
}

@Composable
fun FinishedReceiptDialog(
    history: GameHistoryEntity,
    customers: List<CustomerEntity> = emptyList(),
    debts: List<CustomerDebtEntity> = emptyList(),
    credits: List<CustomerCreditEntity> = emptyList(),
    voiceTranscriptHint: String = "",
    onRequestVoiceForCustomer: () -> Unit = {},
    onQuickAddCustomer: (code: String, name: String, phone: String, nationalId: String) -> Unit = { _, _, _, _ -> },
    onConfirmSave: (
        editedHistory: GameHistoryEntity,
        cashPaidTomans: Long,
        debtSettlementAmountTomans: Long,
        customerCodeOrName: String,
        cardPaidTomans: Long,
        seatResolutions: List<SeatResolutionInput>
    ) -> Unit,
    onCancelAndResume: () -> Unit,
    onDiscard: () -> Unit,
    onRegisterAsDebt: (
        editedHistory: GameHistoryEntity,
        customerInput: String,
        cashPaidTomans: Long,
        debtSettlementAmountTomans: Long,
        cardPaidTomans: Long,
        seatResolutions: List<SeatResolutionInput>
    ) -> Unit,
    onConfirmSaveWithCredit: ((
        editedHistory: GameHistoryEntity,
        cashPaidTomans: Long,
        debtSettlementAmountTomans: Long,
        customerCodeOrName: String,
        cardPaidTomans: Long,
        seatResolutions: List<SeatResolutionInput>,
        creditUsedTomans: Long
    ) -> Unit)? = null,
    onRegisterAsDebtWithCredit: ((
        editedHistory: GameHistoryEntity,
        customerInput: String,
        cashPaidTomans: Long,
        debtSettlementAmountTomans: Long,
        cardPaidTomans: Long,
        seatResolutions: List<SeatResolutionInput>,
        creditUsedTomans: Long
    ) -> Unit)? = null
) {
    var customerNameInput by remember { mutableStateOf(history.customerName.ifBlank { "" }) }
    var totalFeeText by remember(history.id, history.totalFee) {
        mutableStateOf(history.totalFee.toString())
    }
    var cardPaidText by remember { mutableStateOf("") }
    var cashPaidText by remember { mutableStateOf("") }
    var pastDebtOption by remember { mutableStateOf(PastDebtOption.NONE) }
    var partialDebtSettleText by remember { mutableStateOf("") }
    var showInlineAddCustomer by remember { mutableStateOf(false) }

    // Per-player individual settle/debt resolutions
    val seatResolutions = remember(history.id) { mutableStateMapOf<String, SeatResolutionInput>() }
    var pendingSeatSettleConfirm by remember { mutableStateOf<PlayerSeatBreakdown?>(null) }
    var pendingSeatDebtConfirm by remember { mutableStateOf<PlayerSeatBreakdown?>(null) }

    LaunchedEffect(voiceTranscriptHint) {
        if (voiceTranscriptHint.isNotBlank()) {
            customerNameInput = voiceTranscriptHint
        }
    }

    val segments = remember(history.segmentsDetailJson) {
        SessionSegmentCodec.decode(history.segmentsDetailJson)
    }
    val seatBreakdowns = remember(history) {
        SessionCostCalculator.calculateSeatBreakdownsFromHistory(history)
    }

    val parsedTotalFee = totalFeeText.toLongOrNull()?.coerceAtLeast(0L) ?: history.totalFee
    val cardPaid = cardPaidText.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
    val cashPaid = cashPaidText.toLongOrNull()?.coerceAtLeast(0L) ?: 0L

    val matchedCustomer = remember(customerNameInput, customers) {
        val q = customerNameInput.trim()
        if (q.isBlank()) null
        else customers.firstOrNull { it.customerCode.equals(q, ignoreCase = true) }
            ?: customers.firstOrNull { it.name.equals(q, ignoreCase = true) }
            ?: customers.firstOrNull { it.name.contains(q, ignoreCase = true) || it.customerCode.contains(q, ignoreCase = true) }
    }

    val pastUnsettledDebts = remember(customerNameInput, matchedCustomer, debts) {
        val q = customerNameInput.trim()
        if (q.isBlank() && matchedCustomer == null) emptyList()
        else debts.filter { d ->
            !d.isSettled && (
                (matchedCustomer != null && (
                    (matchedCustomer.customerCode.isNotBlank() && d.customerCode.equals(matchedCustomer.customerCode, true)) ||
                        d.customerName.equals(matchedCustomer.name, true)
                    )) ||
                    (q.isNotBlank() && (d.customerName.equals(q, true) || d.customerCode.equals(q, true)))
                )
        }
    }
    val totalPastDebt = remember(pastUnsettledDebts) { pastUnsettledDebts.sumOf { it.amountTomans } }

    val matchingCredits = remember(customerNameInput, matchedCustomer, credits) {
        val q = customerNameInput.trim()
        if (q.isBlank() && matchedCustomer == null) emptyList()
        else credits.filter { cr ->
            cr.amountTomans > 0L && (
                (matchedCustomer != null && (
                    (matchedCustomer.customerCode.isNotBlank() && cr.customerCode.equals(matchedCustomer.customerCode, true)) ||
                        cr.customerName.equals(matchedCustomer.name, true)
                    )) ||
                    (q.isNotBlank() && (cr.customerName.equals(q, true) || cr.customerCode.equals(q, true)))
                )
        }
    }
    val totalAvailableCredit = remember(matchingCredits) { matchingCredits.sumOf { it.amountTomans } }

    LaunchedEffect(totalPastDebt) {
        if (totalPastDebt <= 0L) {
            pastDebtOption = PastDebtOption.NONE
            partialDebtSettleText = ""
        }
    }

    val selectedDebtSettlement = when (pastDebtOption) {
        PastDebtOption.NONE -> 0L
        PastDebtOption.FULL -> totalPastDebt
        PastDebtOption.PARTIAL -> (partialDebtSettleText.toLongOrNull() ?: 0L).coerceIn(0L, totalPastDebt)
    }

    val resolvedSeatsTotal = seatResolutions.values.sumOf { it.amountTomans }
    val remainingAfterSeats = max(0L, parsedTotalFee - resolvedSeatsTotal)
    val grandTotalWithPastDebt = remainingAfterSeats + selectedDebtSettlement
    val creditApplied = min(totalAvailableCredit, grandTotalWithPastDebt)
    val netPayableAfterCredit = max(0L, grandTotalWithPastDebt - creditApplied)
    val remainingBalance = max(0L, netPayableAfterCredit - cardPaid - cashPaid)

    fun buildEditedHistory(): GameHistoryEntity {
        val newTotal = parsedTotalFee
        val newGameFee = max(0L, newTotal - history.snacksFee)
        val resolvedName = matchedCustomer?.name ?: customerNameInput.trim().ifBlank { history.customerName }
        return history.copy(
            totalFee = newTotal,
            gameFee = newGameFee,
            customerName = resolvedName
        )
    }

    Dialog(
        onDismissRequest = onCancelAndResume,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = GamingSurface,
            border = BorderStroke(
                1.5.dp,
                Brush.linearGradient(listOf(CrystalCyan, CrystalGreen, CrystalPurple))
            ),
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .heightIn(max = 640.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Gaming Neon Compact Header Strip
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCardElevated,
                    border = BorderStroke(1.dp, CrystalCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        CrystalPurple.copy(alpha = 0.25f),
                                        CrystalCyan.copy(alpha = 0.16f),
                                        CrystalGreen.copy(alpha = 0.18f)
                                    )
                                )
                            )
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.SportsEsports,
                                contentDescription = null,
                                tint = CrystalCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "فاکتور نهایی: ${history.systemDisplayName}",
                                    color = CrystalGreen,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.5.sp,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${history.dateIso} • ${history.playedMinutes}د • ${history.playerCount} نفر",
                                    color = TextSecondary,
                                    fontSize = 9.5.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = CrystalGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Compact Cost Breakdown + Inline Total Edit Row
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "بازی (${history.playedMinutes}د): ${formatNumber(history.gameFee)} ت" +
                                    if (history.snacksFee > 0) " + خوراکی: ${formatNumber(history.snacksFee)} ت" else "",
                                color = TextSecondary,
                                fontSize = 10.sp,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${formatNumber(parsedTotalFee)} ت",
                                color = CrystalGreen,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        if (history.modeConversionNotes.isNotBlank()) {
                            Text(
                                text = history.modeConversionNotes,
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalCyan, fontSize = 9.5.sp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (segments.size >= 2) {
                            segments.forEachIndexed { idx, seg ->
                                val tStart = PersianDateUtils.formatTime(seg.startTimeMillis)
                                val tEnd = PersianDateUtils.formatTime(seg.endTimeMillis)
                                Text(
                                    text = "${idx + 1}. ${seg.systemDisplayName} (${seg.playerCount}ن) $tStart-$tEnd = ${formatNumber(seg.costTomans)} ت",
                                    color = TextTertiary,
                                    fontSize = 9.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        OutlinedTextField(
                            value = totalFeeText,
                            onValueChange = { input ->
                                totalFeeText = PersianDateUtils.toAsciiDigits(input).filter { it.isDigit() }
                            },
                            label = { Text("ویرایش جمع کل (تومان)", fontSize = 10.sp, maxLines = 1) },
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, fontWeight = FontWeight.Bold),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_receipt_total_fee"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrystalGreen,
                                unfocusedBorderColor = GamingBorder,
                                focusedTextColor = CrystalGreen,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(9.dp)
                        )
                    }
                }

                // Compact Per-Player Breakdown Card
                if (seatBreakdowns.size > 1 || seatBreakdowns.any { it.priorGameFee > 0L || it.priorSnacksFee > 0L || it.assignedSnacksFee > 0L }) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, CrystalPurple.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "تفکیک سهم هر نفر (${seatBreakdowns.size} بازیکن):",
                                color = CrystalPurple,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            )
                            seatBreakdowns.forEach { bd ->
                                val res = seatResolutions[bd.seat.seatId]
                                Surface(
                                    shape = RoundedCornerShape(7.dp),
                                    color = GamingSurface,
                                    border = BorderStroke(
                                        1.dp,
                                        when (res?.status) {
                                            "PAID" -> CrystalGreen
                                            "DEBT" -> CrystalAmber
                                            else -> GamingBorder
                                        }
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 7.dp, vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${bd.seat.displayName} (${formatNumber(bd.totalShare)} ت)",
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.5.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (bd.detailLines.isNotEmpty()) {
                                                Text(
                                                    text = bd.detailLines.joinToString(" | "),
                                                    color = TextTertiary,
                                                    fontSize = 8.5.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        if (res == null) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Surface(
                                                    shape = RoundedCornerShape(5.dp),
                                                    color = CrystalGreen,
                                                    modifier = Modifier
                                                        .clickable { pendingSeatSettleConfirm = bd }
                                                        .testTag("seat_settle_btn_${bd.seat.seatId}")
                                                ) {
                                                    Text(
                                                        text = "تسویه شد",
                                                        color = Color.Black,
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        softWrap = false,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                    )
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(5.dp),
                                                    color = CrystalAmber.copy(alpha = 0.25f),
                                                    border = BorderStroke(1.dp, CrystalAmber),
                                                    modifier = Modifier
                                                        .clickable { pendingSeatDebtConfirm = bd }
                                                        .testTag("seat_debt_btn_${bd.seat.seatId}")
                                                ) {
                                                    Text(
                                                        text = "نسیه",
                                                        color = CrystalAmber,
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        softWrap = false,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                    )
                                                }
                                            }
                                        } else {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(
                                                    text = if (res.status == "PAID") "تسویه ✓" else "نسیه",
                                                    color = if (res.status == "PAID") CrystalGreen else CrystalAmber,
                                                    fontSize = 9.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    softWrap = false
                                                )
                                                Text(
                                                    text = "برگشت",
                                                    color = TextTertiary,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.clickable { seatResolutions.remove(bd.seat.seatId) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Compact Customer Search + Mic + Quick Add + Past Debt / Credit Auto-Detection
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "مشتری / بدهی و طلب قبلی:",
                                color = CrystalCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            )
                            TextButton(
                                onClick = { showInlineAddCustomer = true },
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                modifier = Modifier
                                    .height(22.dp)
                                    .testTag("receipt_add_customer_btn")
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, tint = CrystalGreen, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("افزودن مشتری", color = CrystalGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            OutlinedTextField(
                                value = customerNameInput,
                                onValueChange = { customerNameInput = it },
                                label = { Text("نام یا کد مشتری", fontSize = 10.sp, maxLines = 1, softWrap = false) },
                                textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("debtor_name_or_code_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CrystalCyan,
                                    unfocusedBorderColor = GamingBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(9.dp)
                            )

                            IconButton(
                                onClick = onRequestVoiceForCustomer,
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(CrystalPurple.copy(alpha = 0.25f))
                                    .testTag("receipt_customer_voice_btn")
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = "ورود صوتی مشتری", tint = CrystalCyan, modifier = Modifier.size(18.dp))
                            }
                        }

                        if (matchedCustomer != null) {
                            Text(
                                text = "✓ ${matchedCustomer.name} (کد ${matchedCustomer.customerCode})",
                                color = CrystalGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }

                        if (totalAvailableCredit > 0L) {
                            Surface(
                                shape = RoundedCornerShape(7.dp),
                                color = CrystalPurple.copy(alpha = 0.16f),
                                border = BorderStroke(1.dp, CrystalPurple.copy(alpha = 0.7f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "طلب قبلی موجود: ${formatNumber(totalAvailableCredit)} ت | کسر خودکار: ${formatNumber(creditApplied)} ت",
                                    color = CrystalCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        if (totalPastDebt > 0L) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = CrystalAmber.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, CrystalAmber.copy(alpha = 0.6f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(7.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "بدهی قبلی تسویه‌نشده: ${formatNumber(totalPastDebt)} تومان (${pastUnsettledDebts.size} مورد)",
                                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        listOf(
                                            PastDebtOption.NONE to "عدم تسویه قبلی",
                                            PastDebtOption.FULL to "تسویه کل بدهی",
                                            PastDebtOption.PARTIAL to "تسویه بخشی"
                                        ).forEach { (opt, lbl) ->
                                            val sel = pastDebtOption == opt
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (sel) CrystalAmber else GamingSurface)
                                                    .clickable { pastDebtOption = opt }
                                                    .padding(vertical = 4.dp, horizontal = 2.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = lbl,
                                                    color = if (sel) Color.Black else TextSecondary,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    softWrap = false
                                                )
                                            }
                                        }
                                    }

                                    if (pastDebtOption == PastDebtOption.PARTIAL) {
                                        OutlinedTextField(
                                            value = partialDebtSettleText,
                                            onValueChange = {
                                                partialDebtSettleText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() }
                                            },
                                            label = { Text("مبلغ تسویه بدهی قبلی (تومان)", fontSize = 9.5.sp) },
                                            textStyle = LocalTextStyle.current.copy(fontSize = 11.5.sp),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("partial_past_debt_input")
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Side-by-Side POS Card + Cash Inputs (Compact Height)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GamingCard,
                    border = BorderStroke(1.dp, GamingBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // POS column
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("کارتخوان (POS)", color = CrystalCyan, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    Text(
                                        text = "کل با کارت",
                                        color = CrystalCyan,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .clickable { cardPaidText = max(0L, netPayableAfterCredit - cashPaid).toString() }
                                            .padding(horizontal = 3.dp, vertical = 2.dp)
                                            .testTag("pos_full_btn")
                                    )
                                }
                                OutlinedTextField(
                                    value = cardPaidText,
                                    onValueChange = { cardPaidText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                                    placeholder = { Text("۰ ت", fontSize = 10.sp) },
                                    textStyle = LocalTextStyle.current.copy(fontSize = 11.5.sp, fontWeight = FontWeight.Bold),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("pos_paid_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CrystalCyan,
                                        unfocusedBorderColor = GamingBorder,
                                        focusedTextColor = CrystalCyan,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    shape = RoundedCornerShape(9.dp)
                                )
                            }

                            // Cash column
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("نقدی دریافتی", color = CrystalGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    Text(
                                        text = "کل نقدی",
                                        color = CrystalGreen,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .clickable { cashPaidText = max(0L, netPayableAfterCredit - cardPaid).toString() }
                                            .padding(horizontal = 3.dp, vertical = 2.dp)
                                    )
                                }
                                OutlinedTextField(
                                    value = cashPaidText,
                                    onValueChange = { cashPaidText = PersianDateUtils.toAsciiDigits(it).filter { c -> c.isDigit() } },
                                    placeholder = { Text("۰ ت", fontSize = 10.sp) },
                                    textStyle = LocalTextStyle.current.copy(fontSize = 11.5.sp, fontWeight = FontWeight.Bold),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("cash_paid_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CrystalGreen,
                                        unfocusedBorderColor = GamingBorder,
                                        focusedTextColor = CrystalGreen,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    shape = RoundedCornerShape(9.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = GamingBorder)
                        ReceiptRow(
                            label = "باقیمانده جهت تسویه:",
                            value = "${formatNumber(remainingBalance)} ت",
                            valueColor = if (remainingBalance == 0L) CrystalGreen else CrystalAmber
                        )
                    }
                }

                // Action Buttons
                Button(
                    onClick = {
                        val edited = buildEditedHistory()
                        val custTrim = customerNameInput.trim()
                        val seatsList = seatResolutions.values.toList()
                        if (onConfirmSaveWithCredit != null) {
                            onConfirmSaveWithCredit(edited, cashPaid, selectedDebtSettlement, custTrim, cardPaid, seatsList, creditApplied)
                        } else {
                            onConfirmSave(edited, cashPaid, selectedDebtSettlement, custTrim, cardPaid, seatsList)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .testTag("dismiss_receipt_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (remainingBalance == 0L) CrystalGreen else CrystalCyan)
                ) {
                    Text(
                        text = if (remainingBalance == 0L) "بستن فاکتور" else "تایید دریافت و بستن فاکتور",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                val unpaidForDebt = max(0L, max(0L, remainingAfterSeats - creditApplied) - cardPaid - cashPaid)
                OutlinedButton(
                    onClick = {
                        if (customerNameInput.isNotBlank()) {
                            val edited = buildEditedHistory()
                            val custTrim = customerNameInput.trim()
                            val seatsList = seatResolutions.values.toList()
                            if (onRegisterAsDebtWithCredit != null) {
                                onRegisterAsDebtWithCredit(edited, custTrim, cashPaid, selectedDebtSettlement, cardPaid, seatsList, creditApplied)
                            } else {
                                onRegisterAsDebt(edited, custTrim, cashPaid, selectedDebtSettlement, cardPaid, seatsList)
                            }
                        }
                    },
                    enabled = customerNameInput.isNotBlank(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalAmber),
                    border = BorderStroke(1.dp, if (customerNameInput.isNotBlank()) CrystalAmber else GamingBorder),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .testTag("register_receipt_debt_button")
                ) {
                    Text(
                        text = if (customerNameInput.isBlank()) "نام/کد مشتری را بالا وارد کنید تا نسیه ثبت شود"
                        else "ثبت باقیمانده در نسیه (${formatNumber(unpaidForDebt)} ت)",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = onCancelAndResume,
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, CrystalPurple),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalPurple),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("cancel_checkout_resume_button")
                    ) {
                        Text(
                            text = "انصراف و ادامه بازی",
                            color = CrystalPurple,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    OutlinedButton(
                        onClick = onDiscard,
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, CrystalRed),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalRed),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("discard_receipt_button")
                    ) {
                        Text(
                            text = "عدم ثبت فاکتور",
                            color = CrystalRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }
    }

    // Confirm Single Player Paid
    if (pendingSeatSettleConfirm != null) {
        val bd = pendingSeatSettleConfirm!!
        AlertDialog(
            onDismissRequest = { pendingSeatSettleConfirm = null },
            containerColor = GamingSurface,
            title = { Text("تایید تسویه بازیکن", color = CrystalGreen, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "آیا سهم «${bd.seat.displayName}» به مبلغ ${formatNumber(bd.totalShare)} تومان تسویه شد؟",
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        seatResolutions[bd.seat.seatId] = SeatResolutionInput(
                            seatId = bd.seat.seatId,
                            displayName = bd.seat.displayName,
                            status = "PAID",
                            customerInput = bd.seat.customerCode.ifBlank { bd.seat.displayName },
                            amountTomans = bd.totalShare
                        )
                        pendingSeatSettleConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                    modifier = Modifier.testTag("confirm_seat_settle_btn")
                ) {
                    Text("بله، تسویه شد", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pendingSeatSettleConfirm = null }) {
                    Text("انصراف", maxLines = 1, softWrap = false)
                }
            }
        )
    }

    // Confirm Single Player Debt
    if (pendingSeatDebtConfirm != null) {
        val bd = pendingSeatDebtConfirm!!
        var seatCustomerInput by remember(bd.seat.seatId) {
            mutableStateOf(bd.seat.customerCode.ifBlank { bd.seat.displayName })
        }
        AlertDialog(
            onDismissRequest = { pendingSeatDebtConfirm = null },
            containerColor = GamingSurface,
            title = { Text("ثبت سهم بازیکن در بدهی", color = CrystalAmber, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "سهم ${bd.seat.displayName} (${formatNumber(bd.totalShare)} ت) به حساب چه مشتری ثبت شود؟",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = seatCustomerInput,
                        onValueChange = { seatCustomerInput = it },
                        label = { Text("نام یا کد مشتری") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        seatResolutions[bd.seat.seatId] = SeatResolutionInput(
                            seatId = bd.seat.seatId,
                            displayName = bd.seat.displayName,
                            status = "DEBT",
                            customerInput = seatCustomerInput.trim().ifBlank { bd.seat.displayName },
                            amountTomans = bd.totalShare
                        )
                        pendingSeatDebtConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber)
                ) {
                    Text("ثبت در بدهی", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pendingSeatDebtConfirm = null }) {
                    Text("انصراف", maxLines = 1, softWrap = false)
                }
            }
        )
    }

    if (showInlineAddCustomer) {
        val suggestedCode = ((customers.mapNotNull { it.customerCode.toIntOrNull() }.maxOrNull() ?: 100) + 1).toString()
        QuickAddCustomerInReceiptDialog(
            initialName = customerNameInput,
            suggestedCode = suggestedCode,
            onDismiss = { showInlineAddCustomer = false },
            onSave = { code, name, phone, nationalId ->
                onQuickAddCustomer(code, name, phone, nationalId)
                customerNameInput = name
                showInlineAddCustomer = false
            }
        )
    }
}

@Composable
private fun QuickAddCustomerInReceiptDialog(
    initialName: String,
    suggestedCode: String,
    onDismiss: () -> Unit,
    onSave: (code: String, name: String, phone: String, nationalId: String) -> Unit
) {
    var code by remember { mutableStateOf(suggestedCode) }
    var name by remember { mutableStateOf(initialName) }
    var phone by remember { mutableStateOf("") }
    var nationalId by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalGreen),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("افزودن سریع مشتری جدید", color = CrystalGreen, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("کد مشتری (اجباری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام و نام خانوادگی (اجباری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("شماره تماس (اختیاری)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = nationalId,
                    onValueChange = { nationalId = it },
                    label = { Text("کد ملی (اختیاری)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            if (code.isNotBlank() && name.isNotBlank()) {
                                onSave(code.trim(), name.trim(), phone.trim(), nationalId.trim())
                            }
                        },
                        enabled = code.isNotBlank() && name.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalGreen),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ثبت و انتخاب", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = TextSecondary,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = value,
            color = valueColor,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
            maxLines = 1,
            softWrap = false
        )
    }
}

private fun formatNumber(num: Long): String {
    return String.format(Locale.US, "%,d", num)
}
