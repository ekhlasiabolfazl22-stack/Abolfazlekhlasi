package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CustomVoiceCommandEntity
import com.example.data.model.GameSystemEntity
import com.example.ui.theme.*
import com.example.voice.VoiceEngineMode
import java.util.Locale

@Composable
fun VoiceAssistantDialog(
    isListening: Boolean,
    transcript: String,
    feedbackMessage: String?,
    customCommands: List<CustomVoiceCommandEntity> = emptyList(),
    systems: List<GameSystemEntity> = emptyList(),
    voiceEngineMode: VoiceEngineMode = VoiceEngineMode.HYBRID,
    activeEngineBadge: String = "",
    onVoiceEngineModeChange: (VoiceEngineMode) -> Unit = {},
    onDismiss: () -> Unit,
    onStartListening: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onAddCustomCommand: (
        phrase: String,
        targetSystemId: Int,
        targetSystemName: String,
        players: Int,
        durationMin: Int,
        mode: String,
        amountTomans: Long
    ) -> Unit = { _, _, _, _, _, _, _ -> },
    onDeleteCustomCommand: (CustomVoiceCommandEntity) -> Unit = {},
    onDeleteCustomCommandsByIds: (List<Long>) -> Unit = {},
    onClearAllCustomCommands: () -> Unit = {}
) {
    var textInput by remember { mutableStateOf("") }
    var showAddCommandDialog by remember { mutableStateOf(false) }
    var showManageCommandsDialog by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "mic_waves")
    val waveScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave_scale"
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalCyanDark)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "دستیار صوتی هوشمند",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = CrystalCyan,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (activeEngineBadge.isNotBlank()) {
                            Text(
                                text = activeEngineBadge,
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "بستن",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Engine Mode Selector: Smart Hybrid (Online priority + Offline fallback), Offline Only, Online Only
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(GamingCard),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val modes = listOf(
                        VoiceEngineMode.HYBRID to "آنلاین + آفلاین",
                        VoiceEngineMode.OFFLINE to "آفلاین بدون نت",
                        VoiceEngineMode.ONLINE to "فقط آنلاین"
                    )
                    modes.forEach { (m, label) ->
                        val isSel = voiceEngineMode == m
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSel) CrystalCyan else Color.Transparent)
                                .clickable { onVoiceEngineModeChange(m) }
                                .padding(vertical = 7.dp, horizontal = 4.dp)
                                .testTag("voice_mode_${m.name}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) Color.Black else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Microphone Animated Circle
                Box(contentAlignment = Alignment.Center) {
                    if (isListening) {
                        Box(
                            modifier = Modifier
                                .size(110.dp * waveScale)
                                .clip(CircleShape)
                                .background(CrystalMagenta.copy(alpha = 0.25f))
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    if (isListening) listOf(CrystalMagenta, CrystalCyan)
                                    else listOf(CrystalCyan, CrystalPurple)
                                )
                            )
                            .clickable { onStartListening() }
                            .testTag("dialog_mic_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "میکروفون صوتی",
                            tint = Color.Black,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Listening Status Text
                Text(
                    text = if (isListening) "در حال شنیدن دستور شما... صحبت کنید" else "روی میکروفون ضربه بزنید یا دستور را تایپ کنید",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (isListening) CrystalMagenta else TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                )

                // Live Transcription Box
                if (transcript.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "گفتار شنیده شده: «$transcript»",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrystalCyan,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                // Feedback Result Box
                if (!feedbackMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CrystalGreen.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, CrystalGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = feedbackMessage,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrystalGreen,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Manual Typed Input Box
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("یا دستور را تایپ کنید...", fontSize = 12.sp, color = TextTertiary) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("manual_voice_command_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            if (textInput.isNotBlank()) {
                                onSubmitCommand(textInput)
                                textInput = ""
                            }
                        }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrystalCyan,
                            unfocusedBorderColor = GamingBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                onSubmitCommand(textInput)
                                textInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CrystalCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "ارسال",
                            tint = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Side-by-side Action Buttons: Add Typed Command & Delete Saved Typed Command
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showAddCommandDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("add_custom_command_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "تعریف دستور جدید",
                            color = Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    OutlinedButton(
                        onClick = { showManageCommandsDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, CrystalRed),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrystalRed),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("delete_custom_command_btn")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = CrystalRed, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "مدیریت و حذف دستورات",
                            color = CrystalRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = "دستورات ذخیره شده (فعال در آنلاین و آفلاین):",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (customCommands.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GamingCard,
                        border = BorderStroke(1.dp, GamingBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "هنوز دستوری در حافظه ذخیره نشده است.",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                        )
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(customCommands, key = { "voice_cmd_${it.id}" }) { cmd ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = CrystalPurple.copy(alpha = 0.25f),
                                border = BorderStroke(1.dp, CrystalPurple),
                                modifier = Modifier.clickable {
                                    onSubmitCommand(cmd.commandPhrase)
                                }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = CrystalAmber, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = cmd.commandPhrase,
                                        style = MaterialTheme.typography.labelSmall.copy(color = CrystalAmber),
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddCommandDialog) {
        AddCustomVoiceCommandDialog(
            systems = systems,
            onDismiss = { showAddCommandDialog = false },
            onConfirm = { phrase, sysId, sysName, players, durationMin, mode, amountTomans ->
                onAddCustomCommand(phrase, sysId, sysName, players, durationMin, mode, amountTomans)
                showAddCommandDialog = false
            }
        )
    }

    if (showManageCommandsDialog) {
        ManageCustomVoiceCommandsDialog(
            commands = customCommands,
            onDismiss = { showManageCommandsDialog = false },
            onDeleteSingle = onDeleteCustomCommand,
            onDeleteSelected = { ids ->
                onDeleteCustomCommandsByIds(ids)
            },
            onDeleteAll = {
                onClearAllCustomCommands()
                showManageCommandsDialog = false
            }
        )
    }
}

@Composable
fun AddCustomVoiceCommandDialog(
    systems: List<GameSystemEntity>,
    onDismiss: () -> Unit,
    onConfirm: (
        phrase: String,
        targetSystemId: Int,
        targetSystemName: String,
        players: Int,
        durationMin: Int,
        mode: String,
        amountTomans: Long
    ) -> Unit
) {
    var phrase by remember { mutableStateOf("") }
    var selectedSystem by remember { mutableStateOf(systems.firstOrNull()) }
    var selectedPlayers by remember { mutableIntStateOf(1) }
    var selectedMode by remember { mutableStateOf("TIME") }
    var durationMinutesText by remember { mutableStateOf("60") }
    var amountTomansText by remember { mutableStateOf("100000") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalAmber),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "تعریف و ذخیره دستور صوتی",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = CrystalAmber
                    ),
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "این دستور هم در دستیار آنلاین و هم در موتور آفلاین بدون اینترنت عمل می‌کند.",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = phrase,
                    onValueChange = { phrase = it },
                    label = { Text("عبارت صوتی (مثلاً: فیفا دوستانه)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CrystalAmber,
                        unfocusedBorderColor = GamingBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("انتخاب سیستم هدف:", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    systems.chunked(6).forEach { rowSystems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            rowSystems.forEach { sys ->
                                val isSel = selectedSystem?.id == sys.id
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) CrystalCyan else GamingCard,
                                    border = BorderStroke(1.dp, if (isSel) CrystalCyan else GamingBorder),
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clickable { selectedSystem = sys }
                                        .testTag("add_cmd_sys_cell_${sys.id}")
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(2.dp)
                                    ) {
                                        Text(
                                            text = shortSystemBadgeLabel(sys),
                                            color = if (isSel) Color.Black else TextPrimary,
                                            fontSize = 9.sp,
                                            lineHeight = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 2,
                                            overflow = TextOverflow.Clip
                                        )
                                    }
                                }
                            }
                            repeat(6 - rowSystems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("تعداد نفرات:", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    (1..4).forEach { p ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedPlayers == p) CrystalPurple else GamingCard,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedPlayers = p }
                        ) {
                            Box(modifier = Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    "$p نفر",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("نوع زمان‌بندی دستور:", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(GamingCard),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val modeOptions = listOf(
                        "TIME" to "تایم دلخواه",
                        "AMOUNT" to "مبلغ دلخواه",
                        "OPEN" to "ساعت آزاد"
                    )
                    modeOptions.forEach { (mKey, mLabel) ->
                        val isSel = selectedMode == mKey
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSel) CrystalAmber else Color.Transparent)
                                .clickable { selectedMode = mKey }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mLabel,
                                color = if (isSel) Color.Black else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (selectedMode) {
                    "TIME" -> {
                        OutlinedTextField(
                            value = durationMinutesText,
                            onValueChange = { durationMinutesText = it.filter { c -> c.isDigit() } },
                            label = { Text("مدت زمان بازی (دقیقه)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrystalAmber,
                                unfocusedBorderColor = GamingBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                    "AMOUNT" -> {
                        OutlinedTextField(
                            value = amountTomansText,
                            onValueChange = { amountTomansText = it.filter { c -> c.isDigit() } },
                            label = { Text("مبلغ دلخواه بازی (تومان)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CrystalAmber,
                                unfocusedBorderColor = GamingBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                    "OPEN" -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = GamingCard,
                            border = BorderStroke(1.dp, CrystalGreen.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "این دستور بازی را در حالت ساعت آزاد روی سیستم هدف شروع می‌کند.",
                                style = MaterialTheme.typography.labelSmall.copy(color = CrystalGreen),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("انصراف", maxLines = 1, softWrap = false)
                    }
                    Button(
                        onClick = {
                            val dur = if (selectedMode == "TIME") (durationMinutesText.toIntOrNull() ?: 60) else 0
                            val amt = if (selectedMode == "AMOUNT") (amountTomansText.toLongOrNull() ?: 100000L) else 0L
                            if (phrase.isNotBlank() && selectedSystem != null) {
                                onConfirm(
                                    phrase,
                                    selectedSystem!!.id,
                                    selectedSystem!!.displayName,
                                    selectedPlayers,
                                    dur,
                                    selectedMode,
                                    amt
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ذخیره در حافظه", color = Color.Black, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}

@Composable
fun ManageCustomVoiceCommandsDialog(
    commands: List<CustomVoiceCommandEntity>,
    onDismiss: () -> Unit,
    onDeleteSingle: (CustomVoiceCommandEntity) -> Unit,
    onDeleteSelected: (List<Long>) -> Unit,
    onDeleteAll: () -> Unit
) {
    val selectedIds = remember { mutableStateListOf<Long>() }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = GamingSurface,
            border = BorderStroke(1.5.dp, CrystalRed),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 520.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مدیریت و حذف دستورات ذخیره شده",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = CrystalRed,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "دستورات مورد نظر را انتخاب کرده و حذف نمایید یا کل حافظه دستورات تایپی را پاک کنید.",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (commands.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("هیچ دستور تایپی ذخیره شده‌ای وجود ندارد.", color = TextSecondary)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .heightIn(max = 280.dp)
                    ) {
                        items(commands, key = { "manage_cmd_${it.id}" }) { cmd ->
                            val isChecked = selectedIds.contains(cmd.id)
                            val modeDesc = when (cmd.mode) {
                                "OPEN" -> "ساعت آزاد"
                                "AMOUNT" -> "مبلغ ${String.format(Locale.US, "%,d", cmd.amountTomans)} ت"
                                else -> "${cmd.durationMinutes} دقیقه"
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isChecked) CrystalRed.copy(alpha = 0.12f) else GamingCard,
                                border = BorderStroke(1.dp, if (isChecked) CrystalRed else GamingBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isChecked) selectedIds.remove(cmd.id) else selectedIds.add(cmd.id)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            if (checked) {
                                                if (!selectedIds.contains(cmd.id)) selectedIds.add(cmd.id)
                                            } else {
                                                selectedIds.remove(cmd.id)
                                            }
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = CrystalRed)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "«${cmd.commandPhrase}»",
                                            color = CrystalAmber,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${cmd.targetSystemName} | ${cmd.playerCount} نفره | $modeDesc",
                                            color = TextSecondary,
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            selectedIds.remove(cmd.id)
                                            onDeleteSingle(cmd)
                                        },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف تکی", tint = CrystalRed, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (commands.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (selectedIds.isNotEmpty()) {
                                    onDeleteSelected(selectedIds.toList())
                                    selectedIds.clear()
                                }
                            },
                            enabled = selectedIds.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalAmber),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "حذف انتخابی (${selectedIds.size})",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }

                        Button(
                            onClick = {
                                selectedIds.clear()
                                onDeleteAll()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CrystalRed),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "حذف همه دستورات",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("بستن", maxLines = 1, softWrap = false)
                }
            }
        }
    }
}

private fun shortSystemBadgeLabel(sys: GameSystemEntity): String {
    val shortType = when (sys.systemType.uppercase(Locale.US)) {
        "WHEEL", "CAR" -> "CAR"
        "VR" -> "VR"
        "PC" -> "PC"
        "PS5" -> "PS5"
        "PS4" -> "PS4"
        else -> sys.systemType.uppercase(Locale.US).take(3)
    }
    val tailNum = Regex("([۰-۹0-9]+)$").find(sys.displayName)?.value
    return when {
        shortType == "VR" || shortType == "CAR" -> if (tailNum != null && tailNum.length <= 2) "$shortType\n$tailNum" else shortType
        tailNum != null -> "$shortType $tailNum"
        else -> "$shortType\n${sys.code}"
    }
}
