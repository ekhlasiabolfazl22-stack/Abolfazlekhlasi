package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.*
import java.util.Locale

class AlarmAndTtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var isAlarmActive = false
    private var alarmJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var ringtone: Ringtone? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("AlarmAndTts", "Error init TTS", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val faLocale = Locale.forLanguageTag("fa-IR")
            val result = tts?.setLanguage(faLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.forLanguageTag("fa"))
            }
            tts?.setSpeechRate(0.95f)
            tts?.setPitch(1.0f)
            isTtsReady = true
        }
    }

    fun triggerTimeEndedAlarm(systemDisplayName: String) {
        if (isAlarmActive) return
        isAlarmActive = true

        val persianAnnouncement = "زمان $systemDisplayName به پایان رسید"

        alarmJob?.cancel()
        alarmJob = scope.launch(Dispatchers.Default) {
            var repeatCount = 0
            while (isActive && isAlarmActive && repeatCount < 30) {
                withContext(Dispatchers.Main) {
                    speakPersian(persianAnnouncement)
                }
                playToneBeepSequence()
                vibrateDevice()
                delay(4000)
                repeatCount++
            }
            stopAlarm()
        }
    }

    private fun playToneBeepSequence() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 800)
            Thread.sleep(900)
            toneGen.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 700)
            Thread.sleep(750)
            toneGen.release()
        } catch (e: Exception) {
            try {
                if (ringtone == null) {
                    val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    ringtone = RingtoneManager.getRingtone(context, alertUri)?.apply {
                        audioAttributes = AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    }
                }
                ringtone?.play()
            } catch (ignored: Exception) {}
        }
    }

    private fun vibrateDevice() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(longArrayOf(0, 400, 200, 400), -1)
                }
            }
        } catch (ignored: Exception) {}
    }

    fun speakPersian(text: String) {
        if (!isTtsReady || tts == null) return
        try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "GameNetAlarm_${System.currentTimeMillis()}")
        } catch (e: Exception) {
            Log.e("AlarmAndTts", "Speak failed", e)
        }
    }

    fun stopSpeakingOnly() {
        try {
            tts?.stop()
        } catch (ignored: Exception) {}
    }

    fun stopAlarm() {
        isAlarmActive = false
        alarmJob?.cancel()
        alarmJob = null
        try {
            ringtone?.stop()
        } catch (ignored: Exception) {}
        try {
            tts?.stop()
        } catch (ignored: Exception) {}
    }

    fun isAlarmPlaying(): Boolean = isAlarmActive

    fun release() {
        stopAlarm()
        scope.cancel()
        try {
            tts?.shutdown()
        } catch (ignored: Exception) {}
    }
}
